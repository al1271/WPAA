//
//  StackTrace.h
//  ExceptionTest
//
//  Created by Eric on 6/22/09.
//  eric@startly.com
//  Just wraps around Apple's stuff they added in 10.5.
//  If you use this I would appreciate a mention somewhere in your project.
//  I claim no license on this code and make no guarantee for any use of it.
//  Enjoy!
//

#import <Cocoa/Cocoa.h>

@interface STStackTrace : NSObject {
}

+ (NSString*) currentStackTrace;

// Outputs a trace in nearly the same format as version 6 of Apple's crash reporter.
// Each line of trace has two extra params at the end that could be useful for reversing the dsyms of a stripped application.
+ (NSString*) currentStackTraceForException:(NSException*)exception;

@end
