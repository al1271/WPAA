#import "PCRemoteOperation.h"

// in order to match PCLocalSumSizeOperation, operation result is an NSArray with item 0 being total size and item 1 being total physical size
@interface PCRemoteSumSizeOperation : PCRemoteOperation
{
	BOOL iSumTransferSizes;
}

@property (nonatomic, assign) BOOL sumTransferSizes; // only valid if parent operation is PCRemoteTransferOperation

// helper
- (BOOL)sizeOfNodeContents:(PCNode*)node size:(unsigned long long*)sizeOfContents;

@end
