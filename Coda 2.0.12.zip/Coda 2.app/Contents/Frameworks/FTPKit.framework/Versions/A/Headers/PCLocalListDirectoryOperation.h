#import "PCFSOperation.h"

@class PCFolderNode;

@interface PCLocalListDirectoryOperation : PCFSOperation
{
	PCFolderNode* iNode;
	BOOL iShouldListContents;
	BOOL iFolderContentsDidChange;
}

@property (assign) BOOL folderContentsDidChange;

- (id)initWithFolderNode:(PCFolderNode*)node;

@end


@interface PCLocalListDirectoryOperation (PreventUnnecessaryCasting)

+ (PCLocalListDirectoryOperation*)alloc;

@end
