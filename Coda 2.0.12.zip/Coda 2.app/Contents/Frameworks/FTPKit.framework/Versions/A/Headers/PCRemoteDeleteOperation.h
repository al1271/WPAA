#import "PCRemoteOperation.h"

@interface PCRemoteDeleteOperation : PCRemoteOperation
{
	NSArray				*iPaths;	
	NSMutableSet		*iFailedNodeParents; // nodes' parent folders that couldn't be deleted
	NSDate				*iFlushDate;
}

- (id)initWithPaths:(NSArray*)inPaths;

@end
