#import "PCRemoteOperation.h"

@class AbstractConnection;
@class PCRemoteFolderNode;

@interface PCRemoteListDirectoryOperation : PCRemoteOperation
{
	PCRemoteFolderNode* iNode;
}

// If you pass nil for node it will get the node for the login path of the connection
- (id)initWithFolderNode:(PCRemoteFolderNode*)node;

- (BOOL)getContentsOfNode:(PCRemoteFolderNode*)node error:(FTPKitError**)error;

@end


@interface PCRemoteListDirectoryOperation (PreventUnnecessaryCasting)

+ (PCRemoteListDirectoryOperation*)alloc;

@end
