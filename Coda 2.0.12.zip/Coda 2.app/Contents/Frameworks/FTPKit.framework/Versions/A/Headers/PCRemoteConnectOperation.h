#import "PCRemoteOperation.h"

@class PCRemoteFolderNode;

@interface PCRemoteConnectOperation : PCRemoteOperation
{
	NSString			*iInitialUnicodePath;
	PCRemoteFolderNode	*iInitialNode;
	
    NSString            *iChangeToUnicodeDirectoryPath;
	NSString			*iDownloadPath;
}

@property (readonly, nonatomic, retain) PCRemoteFolderNode* initialNode;
@property(nonatomic, readonly, copy) NSString* downloadPath; // if initial path points to a file, nil otherwise.
@property(copy) NSString *changeToDirectoryPath;

- (id)initWithInitialPath:(NSString*)unicodePath;

@end
