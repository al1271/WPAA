#import "FTPKitConstants.h"
#import <libkern/OSAtomic.h>
#if TARGET_OS_IPHONE
#import <CoreGraphics/CoreGraphics.h>
#endif

@class FilePermissions;
@class PCUUID;
@protocol PCFolderNode;

#if TARGET_OS_IPHONE
@class UIImage;
#endif

@interface PCNode : NSObject <NSCopying>
{
@protected
	OSSpinLock			iPathLock;
	NSString*			iPath;				// Full absolute path to file, including name

@private
	PCUUID*				iUUID;
	NSString*			iDisplayName;		// Localized name, used for display in interface
	NSDate*				iCreationDate;		// When item was created, usually not applicable for remote items
	NSDate*				iModificationDate;	// Date of last modification
	id					iOwner;				// Owner this item belongs to or NSNull if not applicable
	id					iGroup;				// Group the item belongs to or NSNull if not applicable
	NSNumber*			iOwnerAccountID;
	NSNumber*			iGroupAccountID;
	NSString*			iKind;				// Document type
	FilePermissions*	iPermissions;		// Permissions
	NSNumber*			iSize;				// Logical size of file or nil for folders
	NSNumber*			iPhysicalSize;		// Physical size of file or logical size if not applicable
	BOOL				iVisible;

#if TARGET_OS_IPHONE
	BOOL				iIconLoaded;			// If the icon has been loaded or not.
#else
	NSImage*			iIconImage;
	IconRef				iIconRef;
#endif
	
	// cached as needed

	NSMutableDictionary* iUserProperties;
	
	__weak PCNode* iParent; // gcc 4.2 segfaults on "__weak PCNode<PCFolderNode>*", but that's what this really is
}

@property(nonatomic, readonly, retain) PCUUID* uuid;
@property(copy) NSString* path;
@property(copy) NSString* displayName;
@property(retain) NSDate* creationDate;
@property(retain) NSDate* modificationDate;
@property(copy) id owner;
@property(copy) id group;
@property(retain) NSNumber* groupAccountID;
@property(retain) NSNumber* ownerAccountID;
@property(copy) NSString* kind;
@property(retain) FilePermissions* permissions;
@property(retain) NSNumber* size;
@property(retain) NSNumber* physicalSize;
@property(getter=isVisible) BOOL visible;
@property FTPKitConflictMode conflictMode;
@property(nonatomic, assign) PCNode* parent;
@property(readonly) NSDictionary* attributes;

#if TARGET_OS_IPHONE
@property(assign) BOOL iconLoaded;
#else
@property(nonatomic, retain) NSImage* iconImage;
#endif 

// transformer conveniences
@property(readonly) NSString* prettySize; // "1,234,567" or "--" for folders
@property(readonly) NSString* prettyPhysicalSize;
@property(readonly) NSString* prettyOwner;
@property(readonly) NSString* prettyGroup;

- (id)initWithPath:(NSString*)path;

#if TARGET_OS_IPHONE
- (UIImage*)iconWithSize:(PCFileSystemIconSize)iconSize;
#else
- (IconRef)iconRef;
- (void)setIconRef:(IconRef)iconRef;
- (NSImage*)iconWithSize:(PCFileSystemIconSize)iconSize;
#endif

- (id)userPropertyForKey:(NSString*)key;
- (void)setUserProperty:(id)value forKey:(NSString*)key;

+ (NSArray*)sortDescriptorsForSortType:(FTPSortType)sortType ascending:(BOOL)ascending;

// accessors

- (NSString*)uuidString;
- (BOOL)isRemote;

#if !TARGET_OS_IPHONE
- (NSColor*)labelColor;
#endif

- (NSString*)displayPath;
- (PCFileSystemType)type;
- (BOOL)isDescendantOf:(PCNode*)aNode;

- (NSString*)filename;
- (NSString*)unicodeFilename;
- (NSString*)unicodePath;

- (BOOL)canRename;

// for subclasses

- (void)determineVisibility;
- (BOOL)isExpiredAndReloadAttributes:(BOOL)loadDataFlag;
- (void)loadIcon;


// sudo-private
- (void)setKind__:(NSString*)kind;

@end

extern CGSize ImageSizeForIconSize(PCFileSystemIconSize iconSize);

#if !TARGET_OS_IPHONE
@interface PCNode (AppleScript)

- (NSScriptObjectSpecifier*)objectSpecifier;
- (NSString*)uniqueID;

@end
#endif


@interface PCNodePrettySizeTransformer : NSValueTransformer
{}

@end

@interface PCNodePrettyPhysicalSizeTransformer : NSValueTransformer
{}

@end

@interface PCNodePrettyOwnerTransformer : NSValueTransformer
{}

@end

@interface PCNodePrettyGroupTransformer : NSValueTransformer
{}

@end
