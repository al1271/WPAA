#import "PCRemoteTransferOperation.h"

@class AbstractConnection;
@class PCRemoteFolderNode;

@interface PCRemoteCopyOperation : PCRemoteTransferOperation
{
	NSString*	iDestinationPath;
}

- (id)initWithNodes:(NSArray*)inNodes destination:(NSString*)inDestinationPath conflictMode:(FTPKitConflictMode)conflictMode;

@end
