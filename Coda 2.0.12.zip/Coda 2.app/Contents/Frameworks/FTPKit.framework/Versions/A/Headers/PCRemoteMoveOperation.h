#import "PCRemoteOperation.h"

@class AbstractConnection;
@class PCRemoteFolderNode;

@interface PCRemoteMoveOperation : PCRemoteOperation
{
	NSString*			iDestinationPath;
	FTPKitConflictMode	iConflictMode;
	NSArray*			iNewNames;
	NSDate*				iFlushDate;
}

- (id)initWithNodes:(NSArray*)inNodes destination:(NSString*)inDestinationPath conflictMode:(FTPKitConflictMode)conflictMode;
- (id)initWithNodes:(NSArray*)inNodes newNames:(NSArray*)newNames destination:(NSString*)inDestinationPath conflictMode:(FTPKitConflictMode)conflictMode;

@end
