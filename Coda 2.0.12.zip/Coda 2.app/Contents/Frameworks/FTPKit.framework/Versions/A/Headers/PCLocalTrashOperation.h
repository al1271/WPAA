#import "PCFSOperation.h"


@interface PCLocalTrashOperation : PCFSOperation
{
@private
	BOOL iTrash;
	BOOL iUseFinder;
}

- (id)initWithNodes:(NSArray*)nodes toTrash:(BOOL)toTrash;

@end
