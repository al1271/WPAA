#import "PCRemoteOperation.h"

@class AbstractConnection;
@class PCRemoteFolderNode;

@interface PCRemoteNewFileOperation : PCRemoteOperation
{
	PCRemoteFolderNode	*iDestinationNode;
	NSString			*iFilename;
	NSDate				*iCustomModificationDate;
}

@property (nonatomic, copy) NSString *filename;

// pass in nil to get default unique name
- (id)initWithDestination:(PCRemoteFolderNode*)inDestination name:(NSString*)inName;
- (id)initWithDestination:(PCRemoteFolderNode*)inDestination name:(NSString*)inName modificationDate:(NSDate*)aCustomModificationDate;

@end

@interface PCRemoteNewFileOperation (PreventUnnecessaryCasting)

+ (PCRemoteNewFileOperation*)alloc;

@end
