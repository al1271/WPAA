#import "PCRemoteTransferOperation.h"

@interface PCRemoteReversePublishOperation : PCRemoteTransferOperation
{
	NSLock				*curNodeLock;
	NSMutableDictionary	*publishDictionary;
}

- (id)initWithNodes:(NSArray*)someNodes remoteRootPath:(NSString*)remotePath localRootPath:(NSString*)localPath conflictMode:(FTPKitConflictMode)aConflictMode;

@end
