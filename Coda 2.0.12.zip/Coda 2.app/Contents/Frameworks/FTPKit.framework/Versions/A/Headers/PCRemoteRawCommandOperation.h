#import "PCRemoteOperation.h"


@interface PCRemoteRawCommandOperation : PCRemoteOperation
{
	NSString *iRawCommand;
}

@property(copy) NSString* command;

- (id)initWithCommand:(NSString*)inCommand;


@end
