#import "PCRemoteOperation.h"

@interface PCRemoteGetAttributesOperation : PCRemoteOperation
{
	NSMutableSet *iCachedParentNodes;
}

@end
