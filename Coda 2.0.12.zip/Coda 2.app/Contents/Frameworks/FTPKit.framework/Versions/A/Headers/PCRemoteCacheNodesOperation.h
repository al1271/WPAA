#import "PCRemoteTransferOperation.h"

@class AbstractConnection;
@class PCNode;

@interface PCRemoteCacheNodesOperation : PCRemoteTransferOperation 
{
@private
	BOOL iReplaceExistingFiles;
	BOOL iAllowRecache;
	NSArray* iSourcePaths;
}

@property (readwrite) BOOL replaceExistingFiles;

- (id)initWithNodes:(NSArray*)inNodes replaceExistingFiles:(BOOL)replace;
- (id)initWithPaths:(NSArray*)paths replaceExistingFiles:(BOOL)replace;

- (id)initWithNodes:(NSArray*)inNodes allowRecache:(BOOL)recache;

@property (readonly) NSArray* sourcePaths;

@end
