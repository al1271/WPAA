#import "FTPKitConstants.h"
#import "PCNodeStatus.h"
#import "PCOperationStatus.h"
#import <PanicCore/PanicCore.h>
#import <libkern/OSAtomic.h>
#import "PCVirtualFileManager.h"

/* NOTE: Error codes are found in FTPKitConstants.h */

@class PCNode;
@class PCFileNode;
@class PCOperationResult;
@class PCOperationStatus;
@class PCUUID;

@protocol PCFSOperationInterfaceDelegate;
@protocol PCFSOperationFileManagerDelegate;

@interface PCFSOperation : NSObject
{
	BOOL				iShouldContinueAfterError;
	NSConditionLock*	iPauseLock;
		
	PCVirtualFileManager <PCFSOperationFileManagerDelegate> *fileManagerDelegate;
	id <PCFSOperationInterfaceDelegate> interfaceDelegate;
	
	struct {
		BOOL respondsToStatusDidChange;
		BOOL respondsToNodeStatusDidChange;
	} iInterfaceDelegateFlags;
	
@private
	NSConditionLock*	interfaceInteractionLock;
	id					interactionResult;
	
	NSConditionLock*	iChildLock;
@protected
	NSArray*			iNodes;

	NSTimeInterval		iLastStatusUpdate;
	
	PCMapTable*			iNodeToStatusMap;
	
	NSDictionary*		iOperationUserInfo;
	NSString*			key;

	__weak PCFSOperation*	iParentOperation;
	__weak PCFSOperation*	iChildOperation; // running an operation with a parent operation set, will set this ivar NOTE: to not party on this directly
	BOOL				iConcurrent;
	
	PCOperationStatus*	iStatus;
	PCUUID*				iUUID;
	PCOperationResult*	iResult;
	BOOL				iReportsStatus;
	
	PCThreadFuture*		iThreadFuture;
	OSSpinLock			iNodeStatusLock;

#if !TARGET_OS_IPHONE	
	NSScriptCommand*	iScriptCommand;
#endif
	
}

+ (BOOL)canResume;

- (id)initWithNodes:(NSArray*)nodes;

@property BOOL shouldContinueAfterError; // Operations will prompt after encountering an error, allowing the user the choice to continue. Not all operations support this flag.
@property (getter=isPaused) BOOL paused;

@property (retain) id fileManagerDelegate;
@property (nonatomic, retain) id <PCFSOperationInterfaceDelegate> interfaceDelegate;
@property (nonatomic, readonly, retain) PCUUID* uuid;

@property (retain) NSDictionary* userInfo;

#if !TARGET_OS_IPHONE
@property (retain) NSScriptCommand* scriptCommand; // this property is for applescript support to track the script command assocated with this operation
#endif

@property (assign) PCFSOperation *childOperation;
@property (assign) PCFSOperation *parentOperation;
@property (nonatomic, copy) NSArray *nodes;
@property (retain) PCOperationResult *result;
@property (assign) BOOL reportsStatus;
@property (readonly) PCOperationStatus* _status; //direct accessor to the operation's status bypassing the child operation

@property (assign, getter=isConcurrent) BOOL concurrent; // defaults to NO, only applies to child operations. YES, runs children asynchronously from parent

- (void)start;
- (void)main; // required for subclasses

- (BOOL)runSynchronouslyError:(FTPKitError**)error; //NOTE: unless you have a very specific reason, use runChildOperation::: instead.
- (BOOL)runChildOperation:(PCFSOperation*)op error:(FTPKitError**)error;
- (BOOL)runChildOperation:(PCFSOperation*)op reportStatus:(BOOL)statusFlag error:(FTPKitError**)error;
- (void)setThreadName:(NSString*)name;

- (void)cancel;
- (void)waitIfPaused;

- (PCOperationStatus*)status;
- (BOOL)isReady;
- (BOOL)isExecuting;
- (BOOL)isFinished;
- (BOOL)isCancelled;
- (FTPKitError*)error;
- (void)groupErrorTitle:(NSString**)title message:(NSString**)message; // optional for subclasses

- (void)operationMainWillEnd; // bridges from operation thread to main thread
- (void)operationDidEnd; // main thread callbcak

- (PCNode*)currentNode;
- (void)setCurrentNode:(PCNode*)inNode;
- (void)setCurrentNode:(PCNode*)inNode state:(PCOperationState)inState;
- (void)setCurrentNode:(PCNode*)inNode state:(PCOperationState)inState error:(FTPKitError*)inError;


- (PCNodeStatus*)statusForNode:(PCNode*)aNode;
- (PCNodeStatus*)nodeStatus; // returns the status for the current node

- (PCNodeStatus*)statusForNodeIgnoringChildOperation:(PCNode*)aNode;
- (PCNodeStatus*)statusForNodeIgnoringChildOperation:(PCNode*)aNode create:(BOOL)create;
- (PCNodeStatus*)nodeStatusIgnoringChildOperation;
- (PCNodeStatus*)statusForNode:(PCNode*)aNode ignoringChildOperation:(BOOL)ignoreChild create:(BOOL)create;

- (void)setCaption:(NSString*)caption notifyDelegate:(BOOL)flag;

- (double)progress; // progress of the current node as a fraction of 1.0
- (double)operationProgress; // progress of the entire operation as a fraction of 1.0 or negative if indeterminate

// These must be implemented by subclasses

- (NSString*)captionForNode:(PCNode*)aNode; /*optional, but recommend if using setCurrentNode:*/

- (BOOL)isRemote;

- (NSString*)key;
- (PCFileSystemOperationType)operationType;

- (NSDictionary*)userInfoForNode:(PCNode*)node; // used to build callback dictionaries

- (BOOL)canCancel;
- (BOOL)canContinueAfterError;	// defaults to NO.... XXX bad API would like to remove if an alternative can be found
- (BOOL)shouldCancelDuplicateOperations; // defaults to NO

// These methods set the given values on the main thread and post a notification.

- (void)setState:(PCOperationState)newState onNode:(PCNode*)aNode;
- (void)setState:(PCOperationState)newState error:(FTPKitError*)anError onNode:(PCNode*)aNode;
- (void)setState:(PCOperationState)newState error:(FTPKitError*)anError onNodes:(NSSet*)nodes;

- (PCNodeStatus*)statusForNode:(PCNode*)aNode create:(BOOL)create;

// Private
// Convenience methods for status changing, performed on worker threads
- (void)sendOperationStatusDidChangeCallback;
- (void)postDidChangeNodeStatusNotificationIfNeeded:(NSSet*)statuses;
- (void)postOverwriteNotificationForNode:(PCNode*)overwrittenNode replacement:(PCNode*)newNode;

- (void)detachOperationThreadSelector:(SEL)selector withObject:(id)object; // equivalent to +[NSThread detachNewThreadSelector:selector toTarget:self withObject:object] but with autorelease pool

@end

@interface PCFSOperation (IntefaceDelegateInteraction)

// These methods callback to the main thread to the associated interfaceDelegate methods, blocking until the appropriate response method is called.

- (FTPKitConflictMode)resolveConflict:(PCNode*)sourceNode destination:(PCNode*)conflictNode conflictMode:(FTPKitConflictMode*)ioMode;
- (void)interfaceDelegateResolvedFileConflict:(FTPKitConflictMode)conflictMode;

- (BOOL)isWorthyTrust:(PCTrust*)trust; // blocking
- (void)interfaceDelegateEvaluatedTrust:(PCTrust*)trust evaluation:(PCTrustEvaluation)evaluation;

- (NSInteger)runAlert:(PCAlert*)alert;
- (void)intefaceDelegateDidRunAlert:(PCAlert*)alert returnCode:(NSInteger)returnCode;

@end


@class PCRemoteDownloadOperation;
@class PCRemoteFileNode;
@class PCFileNode;

@protocol PCFSOperationInterfaceDelegate <NSObject>

@optional

- (void)operation:(PCRemoteDownloadOperation*)operation didDownloadNode:(PCRemoteFileNode*)remoteNode to:(PCFileNode*)localNode;
- (void)operation:(PCFSOperation*)operation nodeStatusDidChange:(PCNodeStatus*)status; // optionally can be sent on worker thread
- (void)operation:(PCFSOperation*)operation statusDidChange:(PCOperationStatus*)status; // optionally can be sent on worker thread
- (void)operationDidEnd:(PCFSOperation*)operation error:(FTPKitError*)error;
- (void)operationWillStart:(PCFSOperation*)operation;

// These methods are associated with the methods listed in the InterfaceDelegateInteraction category. The operation blocks until the appropriate resolution callback is made.

- (void)operation:(PCFSOperation*)operation evaluateTrust:(PCTrust*)trust;
- (void)operation:(PCFSOperation*)operation requiresFileConflictResolutionForSource:(PCNode*)sourceNode destination:(PCNode*)destinationNode;
- (void)operation:(PCFSOperation*)operation runAlert:(PCAlert*)alert;

@end

@protocol PCFSOperationFileManagerDelegate <NSObject>

@optional

//notifies file manager that a node has been created, deleted, moved or copied. Used for syncing local changes to dropbox remote currently
- (void)operation:(PCFSOperation *)operation fromPath:(NSString *)path toNode:(PCNode *)toNode;

@end

@interface NSObject (PCFSOperationDelegate)

// file manager delegate
- (void)operationDidEnd:(PCFSOperation*)operation;
- (void)operationWillStart:(PCFSOperation*)operation;

@end

@interface PCFSOperation (Private)

- (BOOL)shouldContinueAfterRunningAlertWithError:(FTPKitError*)error;
- (PCNode*)_currentNode; // nonatomic accessor

@end

@interface PCOperationStatus (NonAtomicOperationAccessors)

@property(nonatomic, readonly) PCNodeStatus *readOnlyNodeStatus;
@property(nonatomic, readonly) PCNode *readOnlyDestinationNode;

@end
