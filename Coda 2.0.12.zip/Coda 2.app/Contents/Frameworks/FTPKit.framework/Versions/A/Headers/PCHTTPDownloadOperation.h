#import "PCRemoteOperation.h"

@class PCFolderNode;
@class PCRemoteFileNode;

@interface PCHTTPDownloadOperation : PCRemoteOperation <NSURLDownloadDelegate>
{
	NSURLRequest*		urlRequest;
	NSURLDownload*		downloader;
	
	PCRemoteFileNode*	iSourceNode;
	PCFolderNode*		destinationNode;
	
	NSString*			completeDestinationPath;
}

- (id)initWithURL:(NSURL*)aURL localFolder:(PCFolderNode*)aDestination;
- (id)initWithPendingDownload:(NSURLDownload*)aDownload localFolder:(PCFolderNode*)aDestination;

// protocol methods

- (void)download:(NSURLDownload *)download decideDestinationWithSuggestedFilename:(NSString *)name;
- (void)download:(NSURLDownload*)download didFailWithError:(NSError*)downloadError;
- (void)download:(NSURLDownload *)download didReceiveDataOfLength:(NSUInteger)length;
- (void)download:(NSURLDownload *)download didReceiveResponse:(NSURLResponse *)response;
- (void)downloadDidBegin:(NSURLDownload *)download;
- (void)downloadDidFinish:(NSURLDownload *)download;

@end
