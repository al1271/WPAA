#import "PCFolderNode.h"


@interface PCSmartFolderNode : PCFolderNode
{
	MDQueryRef	query;
	BOOL		iFinished;
}

@property (assign, getter=isFinished) BOOL finished;

- (void)startQuery;
- (void)stopQuery;

@end
