#import "PCRemoteOperation.h"
#import "FTPKitConstants.h"

@class AbstractConnection;

@interface PCRemoteChangeAttributesOperation : PCRemoteOperation 
{
@private
	NSDictionary* iAttributes;
	BOOL iRecursive;
}

@property (readonly, getter=isRecursive) BOOL recursive;

- (id)initWithNodes:(NSArray*)nodes attributes:(NSDictionary*)attributes recursive:(BOOL)recursive;

@end
