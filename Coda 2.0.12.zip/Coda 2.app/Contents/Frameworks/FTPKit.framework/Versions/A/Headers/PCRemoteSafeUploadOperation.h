//
//  PCRemoteSafeUploadOperation.h
//  FTPKit
//
//  Created by Garrett Moon on 4/5/12.
//  Copyright (c) 2012 Panic. All rights reserved.
//

#import "FTPKitConstants.h"
#import "PCRemoteUploadOperation.h"

@class PCFileNode;
@class PCRemoteFolderNode;

@protocol PCFSRemoteSafeUploadInterfaceDelegate;

@interface PCRemoteSafeUploadOperation : PCRemoteUploadOperation
{
@private
	NSArray *iExpectedModifiedDates;
}

- (id)initWithNodes:(NSArray*)someNodes newNames:(NSArray*)customNames expectedModifiedDates:(NSArray *)modifiedDates remotePath:(NSString*)destinationPath conflictMode:(FTPKitConflictMode)conflictMode;

@end