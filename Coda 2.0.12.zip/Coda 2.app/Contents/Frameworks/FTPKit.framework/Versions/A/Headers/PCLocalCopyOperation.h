#import "PCLocalMoveOperation.h"

@interface PCLocalCopyOperation : PCLocalMoveOperation
{
}


@end
