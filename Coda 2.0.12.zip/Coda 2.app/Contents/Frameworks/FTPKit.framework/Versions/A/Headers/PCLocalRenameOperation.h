#import "PCFSOperation.h"

@class PCFileNode;

@interface PCLocalRenameOperation : PCFSOperation
{
@private
	PCFileNode* iNode;
	NSString* iFilename;
	NSString* iOriginalFilename;
}

- (PCLocalRenameOperation*)initWithNode:(PCFileNode*)node name:(NSString*)name;

@property (readonly) NSString* originalFilename;

@end


@interface PCLocalRenameOperation (PreventUnnecessaryCasting)

+ (PCLocalRenameOperation*)alloc;

@end
