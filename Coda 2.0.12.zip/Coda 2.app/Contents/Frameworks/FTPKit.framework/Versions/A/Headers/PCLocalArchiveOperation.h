#import "PCFSOperation.h"

@class PCFolderNode;

@interface PCLocalArchiveOperation : PCFSOperation
{
	PCFolderNode	*iDestinationNode;	

	__weak NSTask* iTask;
}

- (id)initWithNodes:(NSArray*)inNodes destination:(PCFolderNode*)inFolder;

@end
