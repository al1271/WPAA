//
//  PCSlidingAnimation.h
//  DragImageMorphing
//
//  Created by Wade Cosgrove on 4/16/08.
//  Copyright 2008 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class PCSlidingView;

@interface PCSlidingAnimation : NSAnimation
{
    NSMapTable *viewsMap;
    BOOL paused;
}

- (BOOL)setDestinationForView:(NSView*)aView to:(NSRect)targetFrame duration:(NSTimeInterval)duration;
- (void)sendViewToDestination:(NSView*)aView;
- (void)stopView:(NSView*)aView;

- (BOOL)isPaused;
- (void)pause;
- (void)resume;

- (void)showNextFrame;
- (void)updateViewPosition:(PCSlidingView*)aSlider forTime:(NSTimeInterval)currentTime;

@end


@interface NSObject (SlidingAnimationDelegate)

- (void)animation:(PCSlidingAnimation*)animation willBeginSlidingView:(NSView*)aView;
- (void)animation:(PCSlidingAnimation*)animation didFinishSlidingView:(NSView*)aView;

@end


@interface PCSlidingView : NSObject
{
    NSView *view;
    NSRect startFrame;
    NSRect endFrame;
    NSTimeInterval startTime;
    NSTimeInterval duration;
}

@property (nonatomic, retain) NSView *view;
@property (nonatomic, assign) NSRect startFrame;
@property (nonatomic, assign) NSRect endFrame;
@property (nonatomic, assign) NSTimeInterval duration;
@property (nonatomic, assign) NSTimeInterval startTime;

- (id)initWithView:(NSView*)aView duration:(NSTimeInterval)interval;

- (NSRect)frameForTime:(NSTimeInterval)currentTime;

@end
