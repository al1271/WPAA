//
//  NSBezierPath+MCAdditions.h
//
//  Created by Sean Patrick O'Brien on 4/1/08.
//  Copyright 2008 MolokoCacao. All rights reserved.
//

// NOTE: If using this class, credit should be given in the about info.

#import <Cocoa/Cocoa.h>


@interface NSBezierPath (MCAdditions)

+ (NSBezierPath *)mc_bezierPathWithCGPath:(CGPathRef)pathRef;
- (CGPathRef)mc_copyCGPath CF_RETURNS_RETAINED;

- (NSBezierPath *)mc_pathWithStrokeWidth:(CGFloat)strokeWidth;

- (void)mc_fillWithInnerShadow:(NSShadow *)shadow;
- (void)mc_drawBlurWithColor:(NSColor *)color radius:(CGFloat)radius;

- (void)mc_strokeInside;
- (void)mc_strokeInsideWithinRect:(NSRect)clipRect;
- (void)mc_strokeWithShadow:(NSShadow *)shadow;

@end
