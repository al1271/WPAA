//
//  PCFileSizeRowTemplate.h
//  PanicCore
//
//  Created by Wade Cosgrove on 1/8/10.
//  Copyright 2010 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PCFileSizeRowTemplate : NSPredicateEditorRowTemplate {
    NSPopUpButton *unitsPopup;
}

@end
