#import <Cocoa/Cocoa.h>


@interface PCTruncatingDateCell : NSTextFieldCell
{
	BOOL	iUsesRelativeDates;
	NSPoint iOffset;
}

@property (assign) NSPoint offset;

- (NSString*)formattedDateStringIsRelative:(BOOL*)isRelative;

- (BOOL)usesRelativeDates;
- (void)setUsesRelativeDates:(BOOL)usesRelativeDates;

@end
