extern NSString* const PCWindowFirstResponderDidChangeNotification;
extern NSString* const PCOptionKeyPressedNotification;	/* deprecated, bind/observe optionKeyDown instead */
extern NSString* const PCOptionKeyReleasedNotification; /* deprecated, bind/observe optionKeyDown instead */


typedef enum {
	kPCWindowVerticalAlignmentTop = 1,
	kPCWindowVerticalAlignmentCenter = 0
} PCWindowVerticalAlignment;


@interface PCWindow : NSWindow
{
	BOOL postFirstResponderChangedNotifications;
	NSMutableArray* iTitleBarViews;
	BOOL iOptionKeyDown;
}

@property(retain) NSImage* titleBarImage;
@property(assign, getter=isOptionKeyDown) BOOL optionKeyDown;

- (void)addTitleBarView:(NSView*)view alignment:(PCWindowVerticalAlignment)alignment; // at end
- (void)removeTitleBarView:(NSView*)view;
- (NSView*)rightmostTitleBarView; // allows subclassing

- (void)setPostsFirstResponderChangedNotifications:(BOOL)flag;

@end
