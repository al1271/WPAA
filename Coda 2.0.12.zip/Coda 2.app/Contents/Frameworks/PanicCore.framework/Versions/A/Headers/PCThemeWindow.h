#import "PCWindow.h"

@class PCWindowResizeWidget;

@interface PCThemeWindow : PCWindow
{
	NSRect iUserStateFrame; // non-zoomed frame
}

- (NSRect)bottomBarFrame;
- (CGFloat)toolbarHeight;
- (NSRect)toolbarFrame;
- (NSRect)resizeIndicatorFrame;

@end


@interface PCThemeContentView : NSView
{
	NSGradient *iToolbarGradient;
	NSGradient *iInactiveToolbarGradient;
	NSGradient *iBottomBarGradient;
	NSGradient *iInactiveBottomBarGradient;
	NSColor	*iBackgroundColor;
	
	CGFloat iTopCornerRadius;
	CGFloat iBottomCornerRadius;
	
	CGFloat iToolbarHeight;
	CGFloat iBottomBarHeight;
    CGFloat iMaxYCloseButtonOffset;

	BOOL 	iMouseInWidgets;
	NSTrackingArea *iWidgetTrackingArea;
	
	__weak NSButton *iCloseButton;
	__weak NSButton *iZoomButton;
	__weak NSButton *iMinimizeButton;
	__weak NSButton *iTempHighlightButton;
	__weak PCWindowResizeWidget *iResizeWidget;
}

@property (nonatomic, assign) CGFloat maxYCloseButtonOffset;
@property (nonatomic, assign) CGFloat topCornerRadius;
@property (nonatomic, assign) CGFloat bottomCornerRadius;
@property (nonatomic, assign) CGFloat toolbarHeight;
@property (nonatomic, assign) CGFloat bottomBarHeight;
@property (nonatomic, retain) NSGradient *toolbarGradient;
@property (nonatomic, retain) NSGradient *inactiveToolbarGradient;
@property (nonatomic, retain) NSGradient *bottomBarGradient;
@property (nonatomic, retain) NSGradient *inactiveBottomBarGradient;
@property (nonatomic, retain) NSColor *backgroundColor;

- (id)initWithFrame:(NSRect)rect styleMask:(NSUInteger)mask;

- (BOOL)hasVerticalWidgets;
- (void)setVerticalWidgets:(BOOL)flag;

- (NSRect)resizeIndicatorFrame;

- (void)drawBottomBarRect:(NSRect)rect;

@end