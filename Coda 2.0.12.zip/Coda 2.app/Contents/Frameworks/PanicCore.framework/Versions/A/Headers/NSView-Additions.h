#import <Cocoa/Cocoa.h>

@interface NSView (Additions)

- (void)pc_centerHorizontallyInSuperview;
- (BOOL)pc_drawActive;
- (void)pc_logSubviews; // dumps hierarchy using NSLog
- (NSView*)pc_subviewWithDesiredClass:(Class)desired;

@end

