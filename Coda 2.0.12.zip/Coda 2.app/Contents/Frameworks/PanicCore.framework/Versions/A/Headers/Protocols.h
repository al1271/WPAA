//
//  Protocols.h
//  PanicCore
//
//  Created by Wade Cosgrove on 1/18/10.
//  Copyright 2010 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@protocol PCViewDraggingDelegateProtocol <NSObject>

- (NSDragOperation)pc_view:(NSView*)dropView validateDrop:(id <NSDraggingInfo>)sender;
- (BOOL)pc_view:(NSView*)dropView performDragOperation:(id <NSDraggingInfo>)sender;

@optional

- (void)pc_view:(NSView*)dropView draggingExited:(id <NSDraggingInfo>)sender;

@end

// Sent when a controller needs to tell it's parent window controller to calculate the key loop.
// Should only be sent when the first/last key view change, or the controllers view is removed/added to the window.
// Object is window for key loop, user info is not used

#define PCWindowKeyLoopDidChangeNotification	@"PCWindowKeyLoopDidChangeNotification"

@protocol PCKeyLoopProtocol

- (NSView*)firstKeyView;
- (NSView*)lastKeyView;

@optional
- (void)recalculateKeyViewLoop;
- (NSResponder*)initialFirstResponder;

@end


@protocol PCFileViewProtocol

- (NSDragOperation)externalDragOperationMask;
- (CGFloat)scrollPosition;

- (void)setBaseDragImage:(NSImage*)anImage;
- (void)setExternalDragOperationMask:(NSDragOperation)mask;
- (void)setFont:(NSFont*)font;
- (void)setScrollPosition:(CGFloat)position;

@end

