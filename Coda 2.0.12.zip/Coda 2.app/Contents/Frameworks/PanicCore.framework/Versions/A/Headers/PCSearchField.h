/*
 *  PCTruncateSubstitueField.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	Provides a search field subclass that allows the delegate to provide extra functionality.
 *
 *	------------------------------------------------------------------------------
 *
 *
 */

#import <Cocoa/Cocoa.h>

@protocol PCSearchFieldDelegate;

@interface PCSearchField : NSSearchField
{

}

- (id <PCSearchFieldDelegate>)delegate;

@end


@protocol PCSearchFieldDelegate <NSTextFieldDelegate>

@optional
- (BOOL)searchField:(PCSearchField*)field doCommandBySelector:(SEL)aSelector;

@end
