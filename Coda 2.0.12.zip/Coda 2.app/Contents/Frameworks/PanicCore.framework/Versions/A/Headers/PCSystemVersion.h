//
//  PCSystemVersion.h
//  PanicCore
//
//  Created by Logan Collins on 4/16/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


/*!
 * @class PCSystemVersion
 * @abstract Object representation of a system version
 */
@interface PCSystemVersion : NSObject <NSCopying> {
	NSString *_string;
}

+ (PCSystemVersion *)currentSystemVersion;
+ (PCSystemVersion *)systemVersionWithString:(NSString *)aString;

@property (copy, readonly) NSString *string;

- (NSComparisonResult)compare:(PCSystemVersion *)aVersion;

- (BOOL)isEqualToSystemVersion:(PCSystemVersion *)aVersion;
- (BOOL)isLessThanOrEqualToSystemVersion:(PCSystemVersion *)aVersion;
- (BOOL)isLessThanSystemVersion:(PCSystemVersion *)aVersion;
- (BOOL)isGreaterThanOrEqualToSystemVersion:(PCSystemVersion *)aVersion;
- (BOOL)isGreaterThanSystemVersion:(PCSystemVersion *)aVersion;

- (BOOL)isEqualToString:(NSString *)string;
- (BOOL)isLessThanOrEqualToString:(NSString *)string;
- (BOOL)isLessThanString:(NSString *)string;
- (BOOL)isGreaterThanOrEqualToString:(NSString *)string;
- (BOOL)isGreaterThanString:(NSString *)string;

@end
