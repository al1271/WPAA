//
//  PCProgressBar.h
//  PCProgressBar
//
//  Created by Garrett Moon on 2/3/11.
//  Copyright 2011 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@class PCColor;

@interface PCProgressBarLayer : CALayer
{	
	CGFloat iPercentage;
	PCColor *iFillTint;
	PCColor *iBackgroundTint;
	CGMutablePathRef _path;
	
	NSTimer *_animationTimer;
	CGFloat _animationOffset;
}

@property (nonatomic, assign) CGFloat percentage;
@property (nonatomic, retain) PCColor *fillTint;
@property (nonatomic, retain) PCColor *backgroundTint;

@end
