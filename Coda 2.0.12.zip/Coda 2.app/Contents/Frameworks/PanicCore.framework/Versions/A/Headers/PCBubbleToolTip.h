//
//  PCBubbleToolTip.h
//  Studio
//
//  Created by Will Cosgrove on 5/11/06.
//  Copyright 2006 Panic. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class PCBubbleWindow;

@interface PCBubbleToolTip : NSObject 
{
	PCBubbleWindow	*tipWindow;
	NSView			*tipContentView;
	NSTextField		*tipTextField;
}

- (id)initWithTipEdge:(NSRectEdge)edge;

- (PCBubbleWindow*)bubbleWindow;
- (void)displayAtOrigin:(NSPoint)inPoint;
- (void)fadeClose;
- (void)fadeCloseAfterDelay:(NSTimeInterval)seconds;
- (void)setStringValue:(NSString*)inString;

@end
