#import <Foundation/Foundation.h>


@interface PCCertificate : NSObject
{
@private
	__strong SecCertificateRef iRef;

}

@property(nonatomic, readonly) NSString* commonName;

- (id)initWithSecCertificate:(SecCertificateRef)certificate;
- (id)initWithData:(NSData*)data;

- (SecCertificateRef)secCertificate;
- (NSData*)data;

@end
