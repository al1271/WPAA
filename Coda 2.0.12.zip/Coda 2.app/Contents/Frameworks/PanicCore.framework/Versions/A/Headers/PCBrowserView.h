#import <Cocoa/Cocoa.h>
#import "Protocols.h"

@class PCBrowserCell;
@class PCBrowserMatrix;

@protocol PCBrowserViewDelegate;

@interface PCBrowserView : NSBrowser <PCFileViewProtocol>
{
	PCBrowserCell *editingCell;

	PCBrowserCell *dropTargetCell;
	NSInteger dropCellRow;
	NSInteger dropCellColumn;
	NSString *originatingDragPath;
	NSArray *originalSelection;
	NSInteger originatingDragColumn;
	
	NSImage		*baseDragImage;
	
	NSInteger alteredTargetCellRow;
	NSInteger alteredTargetCellColumn;

	int timerFiredCount;
	NSTimer *springTimer;
	BOOL hasSprungFolders;
	BOOL useSpringLoadedFolders;
	NSPoint lastAutoscrollPoint;
	NSDragOperation externalDragOperationMask;
	
	BOOL reloadingColumn;
	NSTimer *activationTimer;
	
	NSFont *iFont; // need to implement ourselves, as NSBrowser does't keep it around
	NSSize iImageSize;
}

@property (nonatomic, retain) NSFont *font;
@property (assign) NSSize imageSize;

// editing

- (void)beginEditingRow:(NSInteger)row inMatrix:(PCBrowserMatrix*)matrix;
- (void)endEditing:(NSText*)fieldEditor fromMatrix:(PCBrowserMatrix*)matrix cancelEditing:(BOOL)flag;
- (void)forceEditingToEnd;
- (PCBrowserCell*)editingCell;

// selection/focus

- (void)deselectAllCellsInColumn:(NSInteger)column;
- (NSInteger)focusedColumn;
- (BOOL)isFocused;

// drag and drop

- (NSImage*)baseDragImage;
- (NSDragOperation)externalDragOperationMask;
- (void)setBaseDragImage:(NSImage*)anImage;
- (void)setDropRow:(NSInteger)newDropRow dropColumn:(NSInteger)newDropColumn;
- (void)setExternalDragOperationMask:(NSDragOperation)mask;
- (void)setOriginatingDragAndDropColumn:(NSInteger)column withSelectedRows:(NSArray*)selectedRows;
- (void)setSpringLoadedFoldersEnabled:(BOOL)flag;
- (BOOL)springLoadedFoldersEnabled;

// scrolling

- (CGFloat)scrollPosition; // position of last column, needed for protocol adherence
- (void)setScrollPosition:(CGFloat)position; // sets position of last column, needed for protocol adherence

- (CGFloat)scrollPositionOfColumn:(NSInteger)column;
- (void)setScrollPosition:(CGFloat)position ofColumn:(NSInteger)column;
- (void)scrollLeftToColumn:(NSInteger)column;

// misc

- (NSInteger)columnAtPoint:(NSPoint)point visibleColumnsOnly:(BOOL)flag;
- (NSRect)imageFrameForRow:(NSInteger)row column:(NSInteger)column;
- (void)setColumnNeedsDisplay:(NSInteger)column;
- (BOOL)setPath:(NSString*)path scrollVisible:(BOOL)flag;


// private

- (void)clearActivationTimer;
- (void)selectionDidChangeInMatrix:(PCBrowserMatrix*)matrix;
- (BOOL)shouldUse106Behavior;

//- (NSInteger)detailColumn;
//- (void)setDetailColumn:(NSInteger)column;

- (id <PCBrowserViewDelegate>)delegate;

@end


@protocol PCBrowserViewDelegate <NSBrowserDelegate>

@optional
- (BOOL)browserView:(PCBrowserView*)browser acceptDrop:(id <NSDraggingInfo>)info inRow:(NSInteger)row ofColumn:(NSInteger)column;
- (BOOL)browserView:(PCBrowserView*)browser keyDown:(NSEvent*)theEvent;
- (BOOL)browserView:(PCBrowserView*)browser swipe:(NSEvent*)theEvent;
- (void)browserView:(PCBrowserView*)browser didEndDragOperation:(NSDragOperation)operation;
- (BOOL)browserView:(PCBrowserView*)browser expandRow:(NSInteger)row inColumn:(NSInteger)column;
- (NSArray*)browserView:(PCBrowserView*)browser namesOfPromisedFilesDroppedAtDestination:(NSURL*)destination fromColumn:(NSInteger)sourceColumn forDraggedRows:(NSArray*)rowIndexes;
- (void)browserView:(PCBrowserView*)browser selectionDidChangeToColumn:(NSInteger)column rows:(NSArray*)rows actionShouldClearSelection:(BOOL)flag;
- (BOOL)browserView:(PCBrowserView*)browser setStringValue:(NSString*)stringValue ofColumn:(NSInteger)column row:(NSInteger)row;
- (BOOL)browserView:(PCBrowserView*)browser shouldEditColumn:(NSInteger)column row:(NSInteger)row;
- (NSDragOperation)browserView:(PCBrowserView*)browser validateDrop:(id <NSDraggingInfo>)info proposedColumn:(NSInteger)proposedColumn proposedRow:(NSInteger)proposedRow;
- (BOOL)browserView:(PCBrowserView*)browser writeRows:(NSArray*)rows fromColumn:(NSInteger)column toPasteboard:(NSPasteboard*)pboard;

@end