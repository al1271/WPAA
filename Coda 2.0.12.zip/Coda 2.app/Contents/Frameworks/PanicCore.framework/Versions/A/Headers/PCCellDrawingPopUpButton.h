// One PopUpButton to rule them all!
// Supports any type of button cell, say goodbye to writing one-off popup buttons. Yay!
//

#import <PanicCore/PCActionPopUpButton.h>

@interface PCCellDrawingPopUpButton : PCActionPopUpButton 
{
	NSTrackingArea *iRolloverTrackingArea;
}

@property (nonatomic, retain) NSButtonCell* drawingCell;

@end


@interface PCCellDrawingPopUpButtonCell : PCActionPopUpButtonCell 
{
    NSSize  iArrowSize;
    NSColor *iTextColor;
    NSColor *iArrowColor;
    NSColor *iArrowShadowColor;

@private
	NSButtonCell *iDrawingCell;
}

@property (nonatomic, copy) NSColor *textColor;
@property (nonatomic, copy) NSColor *arrowColor;
@property (nonatomic, copy) NSColor *arrowShadowColor;
@property (nonatomic, assign) NSSize arrowSize;
@property (nonatomic, retain) NSButtonCell *drawingCell;
@property (nonatomic, getter=isRolloverHighlighted) BOOL rolloverHighlighted;
@property (nonatomic, readonly) BOOL supportsRollover;

@end


@interface NSPopUpButtonCell (ArrowDrawing)

- (void)pc_drawPopUpArrowWithFrame:(NSRect)frame inView:(NSView*)controlView arrowColor:(NSColor*)color shadowColor:(NSColor*)shadowColor;

@end