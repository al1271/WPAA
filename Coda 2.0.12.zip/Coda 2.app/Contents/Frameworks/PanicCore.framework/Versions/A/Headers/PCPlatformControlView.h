#import "PCView.h"

@class PCButtonLayer;
@class PCEvent;
@class PCPlatformShader;

@interface PCPlatformControlView : PCView 
{
	SEL iAction;
	__weak NSObject *iTarget;
	__weak NSObject *iDelegate;
	PCPlatformShader *iShader;
	
#if TARGET_OS_IPHONE
	CALayer *trackingLayer;
#endif
}

+ (Class)layerClass;
+ (void)setLayerClass:(Class)aClass;

@property (assign) __weak NSObject *delegate;
@property (assign) __weak NSObject *target;
@property (assign) SEL action;
@property (retain) PCPlatformShader *shader;

- (CGSize)layerSize:(PCButtonLayer*)layer; // size needed to show the layer contents

#if TARGET_OS_IPHONE
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;
#else

- (void)mouseDown:(NSEvent*)event;
#endif

@end
