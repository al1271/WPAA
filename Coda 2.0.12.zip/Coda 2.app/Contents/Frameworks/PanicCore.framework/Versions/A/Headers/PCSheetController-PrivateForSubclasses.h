#import "PCSheetController.h"

@interface PCSheetController (PrivateForSubclasses)

// optional hook point for additional window configuration before showing
- (void)beginSheetForWindow:(NSWindow*)window;

// required for loading nib based panels, can be nil if window is provided
- (NSString*)nibName;

// Call this when done presenting... calls [self.sheet close] for you
- (void)sheetDidEndWithReturnCode:(NSInteger)returnCode;

// default sheet did end selector, optional for subclasses
- (void)sheetDidEnd:(NSWindow *)sheet returnCode:(NSInteger)returnCode contextInfo:(void *)contextInfo;


@end
