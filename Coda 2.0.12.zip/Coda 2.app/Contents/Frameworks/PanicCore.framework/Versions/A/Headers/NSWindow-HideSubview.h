//
//  NSWindow-HideSubview.h
//  PanicCore
//
//  Created by Ian Cely on 6/21/11.
//  Copyright 2011 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSWindow (PCHideSubview)

- (void)pc_hideSubviewAndResizeVertically:(NSView*)subview;

@end
