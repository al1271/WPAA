//
//  NSTextField-SizeForWidth.h
//  Studio
//
//  Created by Wade Cosgrove on 5/2/06.
//  Copyright 2006 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

extern CGFloat PCHeightForStringDrawing(NSString* string, NSFont* font, CGFloat desiredWidth);
extern CGFloat PCHeightForAttributedStringDrawing(NSAttributedString* attrString, CGFloat desiredWidth);

@interface NSTextField (PCSizeForWidth)

- (void)pc_sizeToFitForMaxWidth:(CGFloat)width;
- (void)pc_sizeToFitForMaxWidth:(CGFloat)width minHeight:(CGFloat)minHeight;
- (void)pc_sizeToFitWithWidth:(CGFloat)width;
- (void)pc_sizeToFitWithWidth:(CGFloat)width minHeight:(CGFloat)minHeight;

@end
