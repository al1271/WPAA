#import <Cocoa/Cocoa.h>


@interface NSGradient (PanicCoreAdditions)

+ (NSGradient*)pc_gradientWithStartingColor:(NSColor*)startColor endingColor:(NSColor*)endColor;
- (void)pc_drawRowSelectionInRect:(NSRect)rect;
- (void)pc_drawWithoutDitheringInRect:(NSRect)rect angle:(CGFloat)angle;

+ (void)pc_setFadingClipMaskInRect:(NSRect)rect fade:(CGFloat)fadeLength; // fade is always on the right
- (void)pc_setClipMaskInRect:(NSRect)rect angle:(CGFloat)angle; // set the clipping mask to the drawn gradient

@end
