#import <Foundation/Foundation.h>

//#if TARGET_OS_IPHONE
//
//// Function for localizing things out of the host app's .strings file
//#define PCLocal(str) NSLocalizedString(str, @"")
//#define PCAppLocal(str) NSLocalizedString(str, @"")
//
//#else

// Function for localizing things out of the PanicCore bundle's .strings file
extern NSString* PCLocal(NSString* key);

// Function for localizing things out of the host app's .strings file
#if defined(DEBUG)
extern NSString* PCAppLocal(NSString* str);
#else
#define PCAppLocal(str) NSLocalizedString(str, @"")
#endif

//#endif