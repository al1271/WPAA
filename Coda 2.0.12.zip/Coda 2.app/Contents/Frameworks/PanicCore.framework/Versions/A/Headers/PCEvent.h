//
//  PCEvent.h
//  PanicCore
//
//  Created by Garrett Moon on 9/22/10.
//  Copyright 2010 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@class PCView;

#if TARGET_OS_IPHONE
@interface PCEvent : UIEvent {
#else
@interface PCEvent : NSEvent {
#endif
	
}
    
@end

#if TARGET_OS_IPHONE
@interface UIEvent (PlateformAdditions)
#else
@interface NSEvent (PlateformAdditions)
#endif
    
- (CGPoint)locationInView:(PCView*)aView;

@end
