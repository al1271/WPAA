#import <Cocoa/Cocoa.h>

@class PCBrowserCell;
@class PCBrowserView;


@interface PCBrowserMatrix : NSMatrix
{
@private
	NSTimer* editTimer;
	__weak PCBrowserView* iBrowser;

	BOOL isHighlightedForDrop;
	NSArray *draggingCellIndices;
		
	int dragEventNumber;
	NSEvent *iFirstMouseEvent;
	BOOL iInSelectAll;
	NSTimer *iEventQueueTimer;
	
	NSObject *iSelectedBranchObject;
}

@property(assign) __weak PCBrowserView* browser;
@property(retain) NSObject *selectedBranchObject; // represented object of the branch cell

- (void)cancelEditTimer;

- (BOOL)beginEditingRow:(NSInteger)row;

- (BOOL)isHighlightedForDrop;
- (void)setHighlightedForDrop:(BOOL)flag;

- (void)setNeedsDisplayForRow:(NSInteger)row;

- (NSInteger)numberOfSelectedCells;
- (NSArray*)selectedRows;

- (void)setNeedsDisplayInVisibleRect;

- (void)deselectRow:(NSInteger)selectedRow;
- (BOOL)isRowSelected:(NSInteger)selectedRow;

- (void)setSelectionFrom:(NSInteger)startPos to:(NSInteger)endPos anchor:(NSInteger)anchorPos highlight:(BOOL)lit moreComing:(BOOL)moreComing;

@end
