//
//  PCGradientDivider.h
//  PanicCore
//
//  Created by Logan Collins on 7/5/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PCGradientDivider : NSView

@end
