//
//  PCGridView.h
//  PCGridView
//
//  Created by Will Cosgrove on 9/7/10.
//  Copyright 2010 Panic Inc. All rights reserved.
//

#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#else
#import <Cocoa/Cocoa.h>
#import <libkern/OSAtomic.h>
#endif

#import <QuartzCore/QuartzCore.h>
#import "PCView.h"
#import "PCGridViewLayerCell.h"

@protocol PCGridViewDelegate;

@class CKGradient, BackgroundLayer, PCButtonLayer, PCGridViewItem, PCGridViewGroupLayerDraw, PCGridViewLayerCell;

#if !TARGET_OS_IPHONE
@class PCTimer;
#endif 

#if TARGET_OS_IPHONE
@interface PCGridView : PCView <PCLayerCellProtocol, UIScrollViewDelegate>
#else
@interface PCGridView : PCView <PCLayerCellProtocol, NSTextFieldDelegate>
#endif
{
	__weak id <PCGridViewDelegate> iDelegate;
	
	CALayer				*iBackingLayer;
	CALayer				*iGroupLayer;
	CALayer				*iGroupLayerTop;
	CALayer				*iGroupLayerBottom;
	CALayer				*iGroupLayerContent;
	CFMutableDictionaryRef iGridViewCache;
	BOOL				iLayoutIsNeeded;
	CFMutableSetRef		iExpandedObjects;
	BOOL				iShouldAnimate;
    
    BOOL                iAllowsSelection;
    BOOL                iAllowsMultipleSelection;
    
	CKGradient			*iBackgroundGradient;
	CALayer				*iTopShadowLayer;
	CKGradient			*iTopShadowGradient;
	CALayer				*iBottomShadowLayer;
	CKGradient			*iBottomShadowGradient;

	CGFloat				iThumbnailSize;
	
	PCGridViewLayerCell	*iCurrentlyTrackingLayer;
	BOOL				touchesBeganOnGridView;
	BOOL				touchesBeganOnGroupBackground;
	BOOL				heldBegan;
	
    NSMutableArray      *iCurrentlyDraggingItems;
    PCGridViewItem      *iCurrentlyDraggingItem;
	BOOL				ignoreDraggingPoint;
	CGPoint				draggingPoint;
	NSInteger			iBlankRow;
	NSInteger			iBlankColumn;
	BOOL				singleRowLayout;
    NSUInteger          iMaxNumberOfGroupChildren;
	CGFloat				iGroupYOffset;	
	BOOL				iDraggingEnabled;

	
#if TARGET_OS_IPHONE
    UITextField         *iEditorField;
	BOOL				editing;
	NSTimer				*holdTimer;
	CGPoint				holdPoint;
#else
    NSTextField         *iEditorField;
    CGPoint             iInitialMouseDownPoint;
    NSMutableArray      *iTrackingAreas;
    PCTimer             *iTrackingRectTimer;
	
	NSPoint				iDragPoint;
#endif

	NSTimer				*delayGridReorderTimer;

    PCGridViewItem      *iCurrentlyEditingItem;
    NSTimer             *iEditTimer;
	NSTimer				*scrollDownTimer;
	NSTimer				*scrollUpTimer;
	CGPoint				iBeforeScrollOffset;
	NSTimer				*dragTimer;
    
	NSTimer				*groupTimer;
	NSTimer				*groupCloseTimer;
	
	PCGridViewItem		*groupingItem;
	PCGridViewGroupLayerDraw *groupDrawDelegate;
    
    __weak id           iTarget;
    SEL                 iDoubleAction;
    BOOL                iEnabled;
	
#if !TARGET_OS_IPHONE
	id					_accessibilityGroupHelper;
#endif
	
@protected
    NSMutableSet        *iSelectedItems;

}

@property (assign) __weak id delegate; 
@property (nonatomic, assign) CGFloat thumbnailSize;
@property (nonatomic, retain) CKGradient *background;
@property (assign) BOOL allowsSelection;
@property (assign) BOOL allowsMultipleSelection;
@property (assign) __weak id target;
@property (assign) SEL doubleAction;
@property (nonatomic, assign, getter = isEnabled) BOOL enabled;
@property (assign) BOOL draggingEnabled;
@property (nonatomic) BOOL singleRowLayout;

#if TARGET_OS_IPHONE
@property (nonatomic, assign) BOOL editing;
#endif

- (void)reloadData;
- (void)reloadItem:(id)item;

- (NSSet *)expandedItems;
- (BOOL)isItemExpanded:(id)item;
- (void)expandItem:(id)item;
- (CGRect)frameOfExpandedArea;
- (void)collapseItem:(id)item;
- (void)collapseAllItems:(BOOL)animate;

- (void)setTopShadow:(CKGradient*)gradient;
- (void)setBottomShadow:(CKGradient*)gradient;

- (PCGridViewLayerCell*)layerForItem:(id)item;
- (id)itemForLayer:(PCGridViewLayerCell*)layer;
- (CGRect)layoutFrameForItem:(id)item;

- (NSArray*)selectedItems;
- (void)selectItems:(NSArray*)items byExtendingSelection:(BOOL)extend;
- (void)deselectAll:(id)sender;

- (void)scrollItemToVisible:(id)item;

- (void)cancelTextEditor;

@end


@interface PCGridViewItem : NSObject
{
	PCGridViewLayerCell	*iLayer;
	id				iRepresentedObject;
	BOOL			iIsExpanded;
	PCGridViewItem	*iParentItem;
}

@property (retain) PCGridViewLayerCell *layer;
@property (retain) id representedObject;
@property (assign) BOOL isExpanded;
@property (retain) PCGridViewItem *parent;

@end


@protocol PCGridViewDelegate <NSObject>

- (id)gridView:(PCGridView*)gridView child:(NSInteger)index ofItem:(id)item;
- (BOOL)gridView:(PCGridView*)gridView isItemExpandable:(id)item;
- (NSInteger)gridView:(PCGridView*)gridView numberOfChildrenOfItem:(id)item;
- (PCGridViewLayerCell *)gridView:(PCGridView*)gridView layerForItem:(id)item;

@optional

- (void)gridView:(PCGridView *)gridView willDisplayLayer:(PCGridViewLayerCell*)layer item:(id)item;
- (void)gridViewSelectionDidChange:(PCGridView*)gridView;
- (void)gridViewBackgroundTapped:(PCGridView *)gridView;

#if TARGET_OS_IPHONE
- (void)gridViewWillBeginEditing:(PCGridView *)gridView;
- (void)gridViewWillEndEditing:(PCGridView *)gridView;
#else
- (BOOL)gridView:(PCGridView *)gridView keyDown:(NSEvent*)keyDown;
#endif

- (void)gridViewWillBeginDragging:(PCGridView*)gridView;
- (void)gridViewWillEndDragging:(PCGridView*)gridView;

- (void)gridView:(PCGridView *)gridView itemClicked:(id)item part:(PCLayerCellPart)part;

//dragging
- (BOOL)gridView:(PCGridView *)gridView shouldAllowDraggingItems:(NSArray*)items;
- (BOOL)gridView:(PCGridView *)gridView canReorderItems:(NSArray*)items fromGroup:(id)fromGroup toGroup:(id)toGroup atIndex:(NSInteger)index;
- (void)gridView:(PCGridView *)gridView didReorderItems:(NSArray*)items fromGroup:(id)fromGroup toGroup:(id)toGroup atIndex:(NSInteger)index;

//deleting
- (CGPoint)gridView:(PCGridView *)gridView deleteButtonPositionForItem:(id)item;
- (BOOL)gridView:(PCGridView *)gridView shouldAllowDeletingItem:(id)item inGroup:(id)group;
- (void)gridView:(PCGridView *)gridView shouldDeleteItem:(id)item inGroup:(id)group;

//rename
- (BOOL)gridView:(PCGridView *)gridView renameItem:(id)item to:(NSString*)name;
- (BOOL)gridView:(PCGridView *)gridView shouldEditItem:(id)item style:(PCLayerEditingStyle)style;

//groups
- (PCGridViewLayerCell*)emptyGroupLayerForGridView:(PCGridView*)gridView;
- (BOOL)gridView:(PCGridView*)gridView shouldAllowItemsToBeGrouped:(NSArray*)items ontoItem:(id)item;
- (CGImageRef)gridView:(PCGridView*)gridView groupTileImageForItem:(id)item;
- (id)gridView:(PCGridView*)gridView createGroupFromItem:(id)item withItems:(NSArray*)items; //return the item (group) created
//- (void)gridView:(PCGridView *)theGridView didRemoveItem:(id)item fromGroup:(id)group;

@end
