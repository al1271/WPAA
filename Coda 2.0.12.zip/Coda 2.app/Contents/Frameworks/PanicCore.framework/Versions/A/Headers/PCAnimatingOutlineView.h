#import <Cocoa/Cocoa.h>

@class PCTimer;
@protocol PCAnimatingOutlineView;

@interface PCAnimatingOutlineView : NSOutlineView
{
	PCTimer			*iAnimationTimer;
	NSMutableSet	*iIndeterminateItems;
	NSInteger		iAnimatingRows[1000];
	NSTimeInterval	iAnimationInterval;
	NSString		*iAnimatingColumnIdentifier;
	SEL				iCellAnimationSelector;
}

@property (retain) NSString *animatingColumnIdentifier;

- (void)setAnimationInterval:(NSTimeInterval)interval;
- (void)setCellAnimationSelector:(SEL)aSelector;
- (void)startAnimationWithItem:(id)item;
- (void)stopAnimationWithItem:(id)item;

- (void)redrawAnimatingItems:(NSTimer*)timer;
- (void)resetAnimatingRows;

- (void)intializeInternals;

- (id <PCAnimatingOutlineView>)delegate;

@end


@protocol PCAnimatingOutlineView <NSOutlineViewDelegate>

@optional
- (void)outlineView:(NSOutlineView*)aOutlineView willAnimateTableColumn:(NSTableColumn*)col item:(id)anItem;

@end