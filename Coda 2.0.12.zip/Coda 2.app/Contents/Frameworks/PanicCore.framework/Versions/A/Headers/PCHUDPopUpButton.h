#import "PCActionPopUpButton.h"

@interface PCHUDPopUpButtonCell : PCActionPopUpButtonCell
{
@private
	NSImage				*arrow;
	NSImage				*arrowDisabled;
		
	float				radius;

}

// private

- (void)configure;
- (void)createArrows;
- (void)setCornerRadius:(CGFloat)inRadius;

@end


@interface PCHUDPopUpButton : PCActionPopUpButton
{

}

- (void)setCornerRadius:(CGFloat)inRadius;

// private

- (void)configure;

@end


@interface NSPopUpButtonCell (PCHUDPopUpButtonPrivateToPublic)

- (NSDictionary*)_textAttributes;

@end
