#import <Foundation/Foundation.h>

#define PC_DECLARE_SHARED_INSTANCE_PTR \
	+ (id*)sharedInstancePtr \
	{ \
		static id sSharedInstancePtr = nil; \
		return &sSharedInstancePtr; \
	}

// inheriting from this class allows for the creation of a singleton accessible via either +sharedInstance or +alloc/-init
@interface PCSharedInstance : NSObject <NSCopying>
{
}

+ (id)sharedInstance;

// SUBCLASSES MUST IMPLEMENT THIS: this method should return a pointer to an id with static storage duration... you can just use the above macro PC_DECLARE_SHARED_INSTANCE_PTR
+ (id*)sharedInstancePtr;

// This is the designator initializer, do not override init
- (void)sharedInstanceInitialize;

- (id)init;

@end
