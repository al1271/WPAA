#import <Cocoa/Cocoa.h>

@interface PCWindowResizeWidget : NSView 
{
	BOOL iShowResizeIndicator;
	NSImage *iResizeIndicator;
	BOOL iResizing;
}

@property (nonatomic, assign) BOOL showsResizeIndicator;
@property (nonatomic, copy) NSImage *resizeIndicator;

+ (PCWindowResizeWidget*)resizeWidget;

- (NSRect)resizeRect;

@end
