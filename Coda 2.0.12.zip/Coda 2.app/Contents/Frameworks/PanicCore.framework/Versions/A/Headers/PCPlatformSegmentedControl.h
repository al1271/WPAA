//
//  PCPlatformSegmentedControl.h
//  PanicCore
//
//  Created by Wade Cosgrove on 10/4/10.
//  Copyright 2010 Panic, Inc. All rights reserved.
//

#import "PCPlatformControlView.h"
#import "PCButtonLayer.h"
#import "PCPlatformShader.h"

@class PCPlatformShaderSegmented;
@class PCColor;
@class PCSegmentedButtonDelegate;
@class PCPlatformSegmentLayer;

@interface PCPlatformSegmentedControl : PCPlatformControlView 
{
	NSMutableArray *iSegmentLayers;
	CALayer *iBackgroundLayer;
	PCSegmentedButtonDelegate *iButtonDelegate;
	
	NSInteger iSelectedSegmentIndex;
	BOOL iMomentary;
	NSInteger iTrackingSegmentIndex;
	
	BOOL iCenterSegments;
	BOOL iShowRightEdge;
	BOOL iShowLeftEdge;
	
	BOOL iButtonsAnimate;
}

@property (nonatomic, getter=isMomentary) BOOL momentary;
@property (nonatomic) NSInteger selectedSegmentIndex;
@property (nonatomic/*, setter=selectSegmentWithTag:*/) NSInteger tagOfSelectedSegment;
@property (nonatomic, readonly) NSUInteger numberOfSegments;
@property (assign) BOOL centerSegments;
@property (assign) BOOL showRightEdge;
@property (assign) BOOL showLeftEdge;
@property (readonly) PCSegmentedButtonDelegate *buttonDelegate;
@property (nonatomic, assign) BOOL buttonsAnimate;

- (CGImageRef)imageForSegmentAtIndex:(NSUInteger)segment;
- (void)setImage:(CGImageRef)image forSegmentAtIndex:(NSUInteger)segment;

- (CGImageRef)alternateImageForSegmentAtIndex:(NSUInteger)segment;
- (void)setAlternateImage:(CGImageRef)image forSegmentAtIndex:(NSUInteger)segment;

- (void)setTitle:(NSString*)string forSegmentAtIndex:(NSUInteger)segment;
- (NSString*)titleForSegmentAtIndex:(NSUInteger)segment;

- (PCPlatformSegmentLayer *)segmentAtIndex:(NSUInteger)segment;

- (void)insertSegmentWithTitle:(NSString*)title image:(CGImageRef)image atIndex:(NSUInteger)segment animated:(BOOL)animated;

- (void)removeSegmentAtIndex:(NSUInteger)segment animated:(BOOL)animated;
- (void)removeAllSegments;

- (void)setWidth:(CGFloat)width forSegmentAtIndex:(NSUInteger)segment;
- (CGFloat)widthForSegmentAtIndex:(NSUInteger)segment;

- (void)setSelectedSegmentIndex:(NSInteger)newIndex animated:(BOOL)animated;

- (void)sizeToFit;

@end


@interface NSObject (PCPlatformSegmentedControlDelegate)
- (CAAnimation*)platformSegmentedControl:(PCPlatformSegmentedControl*)control segmentAnimationForKey:(NSString*)key;
@end


@interface PCPlatformShaderSegmented : PCPlatformShader

- (void)drawButtonInRect:(CGRect)rect bezelEdge:(PlatformEdgeMask)edge;
- (void)drawHighlightedButtonInRect:(CGRect)rect isSelected:(BOOL)flag bezelEdge:(PlatformEdgeMask)edge;
- (void)drawSelectedButtonInRect:(CGRect)rect bezelEdge:(PlatformEdgeMask)edge;
- (CGFloat)intraSegmentOffset;

@end


@interface PCPlatformSegmentLayer : PCButtonLayer
{
	BOOL iSelected;
    NSInteger iTag;
}

@property NSInteger tag;
@property (readonly) CGFloat minimumButtonWidth;
@property (nonatomic, assign, getter=isSelected) BOOL selected;

@end


@interface PCSegmentedButtonDelegate : NSObject
{
	__weak PCPlatformSegmentedControl *iSegmentedControl;
	BOOL iAnimate;
}

@property (readonly) PCPlatformSegmentedControl *segmentedControl;
@property (assign) BOOL animate;

- (id)initWithSegmentedControl:(PCPlatformSegmentedControl*)control;

@end
