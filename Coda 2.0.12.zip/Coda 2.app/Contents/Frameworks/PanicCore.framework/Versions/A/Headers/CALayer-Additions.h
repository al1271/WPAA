//
//  CALayer-Additions.h
//  PanicCore
//
//  Created by Wade Cosgrove on 12/21/10.
//  Copyright 2010 Panic, Inc. All rights reserved.
//

#if TARGET_OS_IPHONE
#import <QuartzCore/QuartzCore.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@class PCShadow;

@interface CALayer (Additions)

- (void)pc_setShadow:(PCShadow*)shadow;
- (void)pc_setContentsScale:(CGFloat)scale;
- (CGFloat)pc_contentsScale;

@end
