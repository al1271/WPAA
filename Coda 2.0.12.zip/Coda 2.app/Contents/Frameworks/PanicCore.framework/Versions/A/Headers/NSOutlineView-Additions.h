
#import <AppKit/AppKit.h>

@interface NSOutlineView (Additions)

- (NSArray *)selectedItems;
- (void)selectItems:(NSArray *)items byExtendingSelection:(BOOL)extendSelection;

@end
