
#import <Cocoa/Cocoa.h>
#import "PCSharedInstance.h"

@protocol PCSheetControllerInterfaceDelegate;
@class PCSheetController;

@interface PCSheetQueue : PCSharedInstance
{
@private
	NSMapTable* iInterfaceDelegateToQueueMap;
}

- (void)addQueuedController:(PCSheetController*)sheetController;

- (void)removeQueuedControllers:(NSArray*)controllers forInterfaceDelegate:(NSObject <PCSheetControllerInterfaceDelegate>*)interfaceDelegate;

// call this on dealloc if your interface delegate is going away
- (void)removeAllQueuedControllersForInterfaceDelegate:(NSObject <PCSheetControllerInterfaceDelegate>*)interfaceDelegate;

- (NSArray*)queuedControllersForInterfaceDelegate:(NSObject <PCSheetControllerInterfaceDelegate>*)interfaceDelegate;

// call this manually if a given interface delegate has suddenly become ready to present a panel (i.e switching tabs)
- (void)showNextSheetForInterfaceDelegate:(NSObject <PCSheetControllerInterfaceDelegate>*)interfaceDelegate;

@end
