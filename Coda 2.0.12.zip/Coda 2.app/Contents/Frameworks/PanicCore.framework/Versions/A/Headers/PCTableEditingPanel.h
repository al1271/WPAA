#import <Cocoa/Cocoa.h>

/*
 *  PCTableEditingPanel.h
 *
 *  DEPRECATED: use PCBaseTableView and PCBaseOutlineView instead
 *
 *	-------------------------------------------------------------------
 *
 *
 */


@interface PCTableEditingPanel : NSPanel
{
}

- (BOOL)endTableEditing __attribute__((deprecated));

@end
