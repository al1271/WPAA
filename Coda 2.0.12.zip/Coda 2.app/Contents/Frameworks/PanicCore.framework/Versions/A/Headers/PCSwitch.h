#import <Cocoa/Cocoa.h>
#import "PCPlatformControlView.h"

@class SwitchAnimation;
@class PCColor;


typedef enum 
{
	kSwitchStyleiOS,
	kSwitchStyleMac
}
PCSwitchStyle;


@interface PCSwitch : PCPlatformControlView <NSAnimationDelegate>
{
	CGRect				iThumbRect;
	CGRect				iThumbStartRect;
	CGRect				iTextClippingRect;
	SwitchAnimation		*iAnimation;
	BOOL				iMouseDown;
	BOOL				iMouseInsideThumb;
	BOOL				iOn;
	BOOL				iEnabled;
	NSAttributedString	*iOnTitle;
	NSAttributedString	*iOffTitle;
	PCColor				*iShadowColor;

	PCSwitchStyle		iSwitchStyle;
}

@property (readonly, getter=isOn) BOOL on;

- (void)setOn:(BOOL)on animated:(BOOL)animated;
- (void)setOnTitle:(NSString*)title;
- (void)setOffTitle:(NSString*)title;
- (BOOL)isEnabled;
- (void)setEnabled:(BOOL)flag;
- (PCColor*)shadowColor;
- (void)setShadowColor:(PCColor*)aColor;

// drawing

@property (assign) CGRect textClippingRect;

- (void)setSwitchStyle:(PCSwitchStyle)style;

- (void)drawTrackInRect:(CGRect)aRect;
- (void)drawThumbInRect:(CGRect)aRect;
- (void)drawBezelInRect:(CGRect)aRect;
- (void)drawTitlesInRect:(CGRect)aRect;

- (void)resetTextClippingRect;
- (CGRect)thumbRect;

@end


@interface SwitchAnimation : NSAnimation
{
	CGRect			iStartFrame;
    CGRect			iEndFrame;
}

@property (assign) CGRect startFrame;
@property (assign) CGRect endFrame;

- (CGRect)frameForTime;
- (void)showNextFrame;

@end