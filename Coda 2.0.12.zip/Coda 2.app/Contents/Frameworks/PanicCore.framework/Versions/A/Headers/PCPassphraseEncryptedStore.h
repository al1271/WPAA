//
//  PCPassphraseEncryptedStore.h
//  PanicCore
//
//  Created by Logan Collins on 8/24/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <PanicCore/PCEncryptedStore.h>


/*!
 * @class PCPassphraseEncryptedStore
 * @abstract An store encrypted by a passphrase
 */
@interface PCPassphraseEncryptedStore : PCEncryptedStore {
@private
	BOOL _locked;
	NSMutableDictionary *_contents;
	NSData *_identity;
	NSString *_passphrase;
}

/*!
 * @method encryptedStoreWithPassphrase:
 * @abstract Creates a new passphrase encrypted store
 * 
 * @param passphrase
 * The passphrase to use. This must be non-nil and of non-zero length.
 * 
 * @result A PCPassphraseEncryptedStore object
 */
+ (PCPassphraseEncryptedStore *)encryptedStoreWithPassphrase:(NSString *)passphrase;

/*!
 * @method initWithPassphrase:
 * @abstract Creates a new passphrase encrypted store
 *
 * @param passphrase
 * The passphrase to use. This must be non-nil and of non-zero length.
 *
 * @result A PCPassphraseEncryptedStore object
 */
- (id)initWithPassphrase:(NSString *)passphrase;


/*!
 * @method unlockWithPassphrase:
 * @abstract Attempts to unlock the store with a given passphrase
 * 
 * @param passphrase
 * The passphrase to use to unlock
 * 
 * @result A BOOL value
 */
- (BOOL)unlockWithPassphrase:(NSString *)passphrase;

/*!
 * @method lock
 * @abstract Locks the store, preventing access and mutation
 */
- (void)lock;

@end
