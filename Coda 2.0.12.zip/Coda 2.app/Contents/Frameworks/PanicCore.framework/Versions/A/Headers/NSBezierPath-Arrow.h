#import <Cocoa/Cocoa.h>



@interface NSBezierPath (Arrow)

+ (NSBezierPath*)arrowInRect:(NSRect)aRect pointEdge:(NSRectEdge)edge;


@end
