/* PCMinimumSizeView */

#import <Cocoa/Cocoa.h>

#define kUnspecifiedSize NSMakeSize(-1.0, -1.0)

@interface PCMinimumSizeView : NSView
{
	NSSize iMinSize;
	NSSize iMaxSize;
}

@property (assign) NSSize maximumSize;
@property (assign) NSSize minimumSize;


@end
