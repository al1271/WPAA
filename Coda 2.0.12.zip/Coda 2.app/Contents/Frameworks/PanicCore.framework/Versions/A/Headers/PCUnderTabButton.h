#import "PCTabBarButton.h"

@class PCUnderTabViewShader;


@interface PCUnderTabButton : PCTabBarButton 
{
	
}

- (BOOL)shouldHideCloseButton;

@end


@interface PCUnderTabButtonCell : NSButtonCell
{
	BOOL					iRolloverHighlighted;
	NSColor					*iTextColor;
	PCUnderTabViewShader	*iShader;
}

@property (nonatomic, getter=isRolloverHighlighted) BOOL rolloverHighlighted;
@property (nonatomic, retain) NSColor *textColor;
@property (readonly, copy) PCUnderTabViewShader *shader;

- (void)setBezelBorderMask:(TabButtonBezelBorderStyle)mask; // needed for default tabbar support

@end
