#import <Foundation/Foundation.h>


@interface PCUUID : NSObject <NSCopying, NSCoding> {
@private
	__strong CFUUIDRef iUUID;
}

+ (PCUUID*)UUID;
+ (PCUUID*)UUIDWithString:(NSString*)string;

- (id)initWithString:(NSString*)string;
- (NSString*)stringValue;

@end
