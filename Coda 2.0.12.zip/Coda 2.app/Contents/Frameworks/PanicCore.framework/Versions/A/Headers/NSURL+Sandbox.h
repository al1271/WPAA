//
//  NSURL+Sandbox.h
//  PanicCore
//
//  Created by Wade Cosgrove on 8/7/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSURL (Sandbox)

+ (NSData*)pc_sandboxedBookmarkDataForPath:(NSString*)path;
+ (NSData*)pc_sandboxedBookmarkDataForPath:(NSString*)path isDirectory:(BOOL)isDirectory;
+ (NSString*)pc_pathByResolvingSandboxedBookmarkData:(NSData*)data;
+ (NSURL*)pc_URLByResolvingSandboxedBookmarkData:(NSData*)data;
+ (NSURL*)pc_URLByResolvingSandboxedBookmarkData:(NSData*)data options:(NSURLBookmarkCreationOptions)options;

- (NSData*)pc_sandboxedBookmarkData;

@end
