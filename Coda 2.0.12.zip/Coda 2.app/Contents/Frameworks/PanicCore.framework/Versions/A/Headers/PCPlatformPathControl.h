#import "PCPlatformSegmentedControl.h"

@class CKBezierPath;

@interface PCPlatformPathControl : PCPlatformSegmentedControl
{
	NSURL *iURL;
	id iPathDelegate;
}

@property (assign) id pathDelegate;
@property (retain) NSURL *URL;

- (void)setSelectedSegmentIndex:(NSInteger)index notify:(BOOL)notify;

@end

@interface NSObject (PCPlatformPathControlDelegate)

- (void)pathControl:(PCPlatformPathControl *)pathControl componentSelectedAtIndex:(NSInteger)index;

@end


@interface PCPlatformShaderPath : PCPlatformShaderSegmented

- (CKBezierPath*)pathForRect:(CGRect)rect edge:(PlatformEdgeMask)edge;

@end
