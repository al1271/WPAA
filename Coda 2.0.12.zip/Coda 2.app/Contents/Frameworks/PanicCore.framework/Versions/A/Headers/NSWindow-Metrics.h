#import <Cocoa/Cocoa.h>

/*
 *  NSWindow-Metrics.h
 *
 *  Requires Mac OS X 10.2 (?) or higher
 *
 *
 *	Returns various information about window attributes.
 *
 *	-------------------------------------------------------------------
 *
 *
 */
 

@interface NSWindow (PCMetrics)

- (CGFloat)pc_toolbarHeight;
- (CGFloat)pc_titleBarHeight;
- (NSPoint)pc_frameTopLeftPoint;
- (void)pc_centerOnScreen;
- (void)pc_centerOnScreenWithMaxWidth:(CGFloat)maxWidth;
- (BOOL)pc_isMaximized;
- (BOOL)pc_isMaximizedVertically;
- (BOOL)pc_isFullScreen;

@end
