//
//  UIFont-Coding.h
//  PanicCore
//
//  Created by Garrett Moon on 4/1/11.
//  Copyright 2011 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIFont (NSCoding)

@end

#endif
