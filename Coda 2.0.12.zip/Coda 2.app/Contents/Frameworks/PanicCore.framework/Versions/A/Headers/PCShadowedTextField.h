#import <Cocoa/Cocoa.h>

/*
 *  PCShadowedTextField.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	Provides a text field with a shadow under the text
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface PCShadowedTextField : NSTextField
{
	NSShadow *shadow;
}

- (NSShadow*)shadow;

- (void)setShadow:(NSShadow*)newShadow;
- (void)setShadowColor:(NSColor*)aColor;
- (void)setShadowOffset:(NSSize)offset;

@end