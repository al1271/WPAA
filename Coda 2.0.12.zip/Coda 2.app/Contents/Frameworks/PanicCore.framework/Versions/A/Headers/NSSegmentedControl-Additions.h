//
//  NSSegmentedControl-Additions.h
//  PanicCore
//
//  Created by Ian Cely on 3/24/11.
//  Copyright 2011 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSSegmentedControl (NSSegmentedControl_Additions)

- (NSInteger)pc_segmentWithTag:(NSInteger)tag;

@end
