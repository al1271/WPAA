#import <Cocoa/Cocoa.h>


@interface PCBaseSegmentedControl : NSSegmentedControl
{}

- (void)sizeAllSegmentsEvenlyToFit;
- (void)sizeTextLabelsToFit;

@end


@interface PCBaseSegmentedCell : NSSegmentedCell
{
@private
	NSColor* 	iTextColor;
	NSColor*	iTextShadowColor;
	
	BOOL		iShowsMenuArrow;
	NSPoint 	iMouseDownPoint;
	
    NSInteger   iBaselineOffset;
}

@property (nonatomic, retain) NSColor*	textColor;
@property (nonatomic, retain) NSColor*	textShadowColor;
@property (nonatomic, assign) BOOL	showsMenuArrow;
@property (assign) NSInteger baselineOffset;

- (NSRect)bezelFrameOfSegment:(NSInteger)segment withInteriorFrame:(NSRect)innerFrame withView:(NSView*)controlView;
- (BOOL)isSegment:(NSInteger)segment highlightedWithFrame:(NSRect)segmentFrame inView:(NSView*)controlView;
- (NSUInteger)segmentAtPoint:(NSPoint)point;

// for subclasses

- (void)drawSegmentBezel:(NSInteger)segment inFrame:(NSRect)frame withView:(NSView*)controlView;
- (void)drawSegmentInterior:(NSInteger)segment inFrame:(NSRect)frame withView:(NSView*)controlView;

@end