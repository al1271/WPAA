#import <Cocoa/Cocoa.h>


@interface NSWorkspace (PathAdditions)

- (OSType)pc_creatorCodeForApplicationAtPath:(NSString*)path;
- (NSString*)pc_pathForApplicationWithCreator:(OSType)creatorCode;
- (void)pc_ejectDiskAtPath:(NSString*)path delegate:(NSObject*)delegate;
- (NSString*)pc_volumeNameForPath:(NSString*)path;

// private callbacks
- (void)pc_didEjectDisk:(NSDictionary*)args;
- (void)pc_ejectDiskInThread:(NSMutableDictionary*)args;


@end

@interface NSObject (NSWorkspaceDiskEjectDelegate)
- (void)workspace:(NSWorkspace*)workspace didEjectDiskAtPath:(NSString*)path error:(NSError*)error;
@end
