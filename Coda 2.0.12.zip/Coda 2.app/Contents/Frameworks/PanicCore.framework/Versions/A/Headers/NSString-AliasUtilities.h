#import <Foundation/Foundation.h>


@interface NSString (PCAliasUtilities)

- (NSString*)pc_resolveAliasFile;

+ (NSData*)pc_aliasDataFromPath:(NSString*)path;
+ (NSString*)pc_pathFromAliasData:(NSData*)aliasData;

@end
