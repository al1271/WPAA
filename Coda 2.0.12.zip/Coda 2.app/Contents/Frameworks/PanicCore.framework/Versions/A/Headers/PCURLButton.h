/*
 *  PCURLButton.h
 *
 *  Requires Mac OS X 10.0 or higher,
 *	NSString-Hyperlink.h
 *
 *
 *	A button that displays a clickable URL.
 *
 *	-------------------------------------------------------------------
 *
 *
 */


@interface PCURLButton : NSButton
{
	NSURL* url;
}

- (void)setURL:(NSURL*)inURL title:(NSString*)title;

@end
