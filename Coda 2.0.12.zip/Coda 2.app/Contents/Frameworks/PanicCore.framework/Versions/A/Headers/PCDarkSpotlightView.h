#import <Cocoa/Cocoa.h>


@interface PCDarkSpotlightView : NSView 
{
	NSGradient *fillGradient;
	NSGradient *lightGradient;
		
    CGLayerRef iRadialGlowLayer;
    
	BOOL	iDrawsTopShadow;
	CGFloat iTopShadowHeight;
}

@property (nonatomic, assign) BOOL drawsTopShadow;
@property (nonatomic, assign) CGFloat topShadowHeight;

- (void)setFillGradient:(NSGradient*)newGradient;
- (void)setLightGradient:(NSGradient*)newGradient;

// private
- (void)updateBackgroundImageWithSize:(NSSize)newSize;

@end
