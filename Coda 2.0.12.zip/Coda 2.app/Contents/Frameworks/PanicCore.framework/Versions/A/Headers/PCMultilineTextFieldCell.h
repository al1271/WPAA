#import <PanicCore/PCIconTextFieldCell.h>

@interface PCMultilineTextFieldCell : PCIconTextFieldCell
{
	NSString			*iStatusString;
	NSMutableDictionary *iStatusTextAttributes;
	NSLineBreakMode		iStatusLineBreakMode;
	NSFont				*iStatusFont;
	NSColor				*iStatusColor;
}

@property (nonatomic, retain) NSFont *statusFont;
@property (retain) NSString *statusString;
@property (retain) NSColor *statusColor;

- (void)setStatusLineBreakMode:(NSLineBreakMode)newMode;

- (void)setStatusFont:(NSFont*)font;
- (NSAttributedString*)statusAttributedStringValue;
- (NSRect)statusRectForBounds:(NSRect)cellFrame;

@end
