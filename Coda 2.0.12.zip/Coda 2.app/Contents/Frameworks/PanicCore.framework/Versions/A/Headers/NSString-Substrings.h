#import <Foundation/Foundation.h>

@interface NSString (PCSubstrings)

- (NSUInteger)pc_numberOfInstancesOfString:(NSString*)string options:(NSStringCompareOptions)options;

- (BOOL)pc_containsString:(NSString*)string;
- (BOOL)pc_containsString:(NSString*)string options:(NSStringCompareOptions)options;

- (NSRange)pc_rangeOfSubstringDelimitedByString:(NSString*)string options:(NSStringCompareOptions)options range:(NSRange)range;

@end
