#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

// use a macro rather than a function to allow analyzer to observe memory management
#define PCAutorelease(obj) (__typeof__(obj))[NSMakeCollectable(obj) autorelease]

CGImageRef PCCGImageRefNamedOfType(NSString* name, NSString* extension);
CGImageRef PCCGImageRefFromPDF(NSString *name, CGSize size);

// states
CGImageRef PCPressedImageRef(CGImageRef sourceImage);

CGContextRef PCGraphicsGetCurrentContext();

void PCRectFill(CGRect rect);
void PCRectFillUsingBlendMode(CGRect rect, CGBlendMode blendMode);
void PCRectFrame(CGRect rect);

CGRect PCCenterSizeInRect(CGSize innerSize, CGRect outerRect);
CGRect PCContstrainRectToRect(CGRect innerRect, CGRect constrainRect);

#if !TARGET_OS_IPHONE

NSRect PCConstrainNSRectToRect(NSRect innerRect, NSRect constrainRect);
NSRect PCCenterSizeInNSRect(NSSize innerSize, NSRect outerRect);
CGRect PCHostRectToCGRect(NSRect rect);
CGSize PCHostSizeToCGSize(NSSize size);
CGPoint PCHostPointToCGPoint(NSPoint point);
NSPoint CGPointToHostPoint(CGPoint point);

#else

#define PCHostRectToCGRect(aRect) (aRect)
#define PCHostSizeToCGSize(aSize) (aSize)
#define PCHostPointToCGPoint(aPoint) (aPoint)
#define CGPointToHostPoint(aPoint) (aPoint)

#endif

BOOL PCLocationInRangeInclusive(NSUInteger index, NSRange range);
CGFloat PCHighestContentsScale();

BOOL PCIsEqualToNilString(NSString *stringOne, NSString *stringTwo);