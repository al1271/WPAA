#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

#import "PCView.h"

@class PCIndeterminateSpinner;
@class PCProgressPieCell;

@interface PCProgressPie : PCView
{
	PCIndeterminateSpinner *spinner;
	PCProgressPieCell *iProgressPieCell;
}

- (PCIndeterminateSpinner*)spinner;
- (PCProgressPieCell*)cell;

- (CGFloat)percentShaded;
- (void)setPercentShaded:(CGFloat)percent;

- (PCIndeterminateSpinner*)spinner;

@end
