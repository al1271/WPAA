#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#import <CoreText/CoreText.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@interface NSAttributedString (platform)

- (CGSize)CGSize;
- (void)drawAtCGPoint:(CGPoint)aPoint;

- (NSRange)pc_rangeOfAttribute:(NSString*)name value:(id)value;
- (NSRange)pc_rangeOfAttribute:(NSString*)name startIndex:(NSUInteger)startIndex value:(id)inValue;

@end
