#ifndef PC_INLINE
#if DEBUG
#define PC_INLINE static __inline__
#else
#define PC_INLINE static __inline__ __attribute__((always_inline))
#endif
#endif

// Define static analyzer annotations <http://clang-analyzer.llvm.org/annotations.html> for when targeting 10.5:

#ifndef __has_feature      // Optional.
#define __has_feature(x) 0 // Compatibility with non-clang compilers.
#endif

#ifndef NS_RETURNS_RETAINED
#if __has_feature(attribute_ns_returns_retained)
#define NS_RETURNS_RETAINED __attribute__((ns_returns_retained))
#else
#define NS_RETURNS_RETAINED
#endif
#endif

#ifndef CF_RETURNS_RETAINED
#if __has_feature(attribute_cf_returns_retained)
#define CF_RETURNS_RETAINED __attribute__((cf_returns_retained))
#else
#define CF_RETURNS_RETAINED
#endif
#endif
