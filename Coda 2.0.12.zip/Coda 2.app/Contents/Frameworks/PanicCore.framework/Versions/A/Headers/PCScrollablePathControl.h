//
//  DCScrollablePathControl.h
//  dietcoda
//
//  Created by Garrett Moon on 1/21/11.
//  Copyright 2011 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <UIKit/UIKit.h>
#import "PCPlatformPathControl.h"

@class PCSegmentedFirstButtonDelegate;
@class PCPlatformFirstSegmentLayer;

@interface PCScrollablePathControl : UIView
{
	id iDelegate;
	PCPlatformPathControl *iPath;
	UIScrollView *iScrollView;
	PCPlatformFirstSegmentLayer *iFirstSegment;
	NSInteger iSelectedSegmentIndex;
	PCSegmentedFirstButtonDelegate *iFirstSegmentDelegate;
	PCPlatformShaderSegmented *iShader;
	BOOL iScrolling;
}

@property (nonatomic, assign) id delegate;
@property (readonly) PCPlatformPathControl *path;
@property (nonatomic, assign) NSInteger selectedSegmentIndex;
@property (readonly) PCPlatformFirstSegmentLayer *firstSegment;
@property (nonatomic, retain) PCPlatformShaderSegmented *shader;
@property (readonly) BOOL scrolling;
@property (nonatomic, readonly) NSUInteger numberOfSegments;
@property (readonly) UIScrollView *scrollView;

- (void)setup;
- (void)updateBounds;

- (void)setURL:(NSURL*)url;
- (NSURL *)URL;
- (void)setTitle:(NSString*)string forSegmentAtIndex:(NSUInteger)segment;
- (void)setImage:(CGImageRef)image forSegmentAtIndex:(NSUInteger)segment;
- (void)insertSegmentWithTitle:(NSString *)title image:(CGImageRef)image atIndex:(NSInteger)index animated:(BOOL)animated;
- (void)setSelectedSegmentIndex:(NSInteger)selectedSegmentIndex notify:(BOOL)notify;
//- (BOOL)isFirstSegmentLayerSelected;
- (PCPlatformSegmentLayer *)segmentAtIndex:(NSUInteger)segment;
- (void)clearSelection;

@end

@interface NSObject (DCScrollablePathControlDelegate)

- (void)scrollablePathWillBeginToScroll:(PCScrollablePathControl *)scrollablePath;
- (void)scrollablePathWillStopScrolling:(PCScrollablePathControl *)scrollablePath;
- (void)scrollablePath:(PCScrollablePathControl *)scrollablePath selectedComponentAtIndex:(NSInteger)index;

- (NSString*)pathControl:(PCScrollablePathControl *)pathControl titleForSegmentAtIndex:(NSInteger)index urlComponent:(NSString*)path;
- (CGImageRef)pathControl:(PCScrollablePathControl *)pathControl imageForSegmentAtIndex:(NSInteger)index urlComponent:(NSString*)path;

@end


@interface PCPlatformFirstSegmentLayer : PCPlatformSegmentLayer

@end


@interface PCSegmentedFirstButtonDelegate : PCSegmentedButtonDelegate
{
	PCScrollablePathControl *iScrollablePathControl;
}

@property (assign) PCScrollablePathControl *scrollablePathControl;

@end

#endif
