#import <Cocoa/Cocoa.h>


@interface PCOffsetTextFieldCell : NSTextFieldCell
{
	NSPoint			iOffset;
}

@property (assign) NSPoint offset;


@end
