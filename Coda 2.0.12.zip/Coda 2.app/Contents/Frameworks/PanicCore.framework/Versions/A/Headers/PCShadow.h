#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import <CoreGraphics/CoreGraphics.h>
#else
#import <ApplicationServices/ApplicationServices.h>
#endif

@class PCColor;

@interface PCShadow : NSObject 
{
	CGFloat iBlurRadius;
	CGSize	iOffset;
	PCColor *iColor;
}

+ (PCShadow*)shadow;
+ (PCShadow*)shadowWithColor:(PCColor*)shadowColor;
+ (PCShadow*)shadowWithColor:(PCColor*)shadowColor offset:(CGSize)offset;
+ (PCShadow*)shadowWithColor:(PCColor*)shadowColor offset:(CGSize)offset radius:(CGFloat)radius;

@property (retain) PCColor *color;
@property (assign) CGSize offset;
@property (assign) CGFloat blurRadius;

- (void)set;

@end
