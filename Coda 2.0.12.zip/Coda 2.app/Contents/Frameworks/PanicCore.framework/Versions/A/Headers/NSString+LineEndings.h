//
//  NSString+LineEndings.h
//  PanicCore
//
//  Created by Garrett Moon on 6/28/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (LineEndings)

#if TARGET_OS_IPHONE
- (NSString *)stringByConvertingLineEndingsTo:(NSString *)newLineEnding;
#endif

@end