#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>

@interface PCViewLayer : CALayer
{
	NSView *iView;
}

+ (id)layerWithView:(NSView*)view;
- (id)initWithView:(NSView*)view;

@property (nonatomic, retain) NSView *view;

@end
