typedef enum 
{
	PCTriangleAlignmentNatural,
	PCTriangleAlignmentStart,
	PCTriangleAlignmentCenter,
	PCTriangleAlignmentEnd
} PCTriangleAlignment;

#if !TARGET_OS_IPHONE
#import <Cocoa/Cocoa.h>

@interface NSBezierPath (PCBubbles)

+ (NSBezierPath*)pc_bubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth edge:(NSRectEdge)edge triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;

// bubble creation for nesting multiple bubbles, inset allows for correct alignment
+ (NSBezierPath*)pc_topBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth inset:(CGFloat)inset triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (NSBezierPath*)pc_topBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth inset:(CGFloat)inset triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;

// direct bubble creation using alignment
+ (NSBezierPath*)pc_topBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (NSBezierPath*)pc_bottomBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (NSBezierPath*)pc_leftBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (NSBezierPath*)pc_rightBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;


// direct bubble creation using specified triangle offset
+ (NSBezierPath*)pc_topBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;
+ (NSBezierPath*)pc_bottomBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;
+ (NSBezierPath*)pc_leftBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;
+ (NSBezierPath*)pc_rightBubbleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;

@end

#endif

#import <PanicCore/CKBezierPath.h>

@interface CKBezierPath (Bubbles)

+ (CKBezierPath*)pc_bottomBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (CKBezierPath*)pc_topBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth inset:(CGFloat)inset triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (CKBezierPath*)pc_leftBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;
+ (CKBezierPath*)pc_rightBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance alignment:(PCTriangleAlignment)alignment;

// direct bubble creation using specified triangle offset
+ (CKBezierPath*)pc_topBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;
+ (CKBezierPath*)pc_bottomBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;
+ (CKBezierPath*)pc_leftBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;
+ (CKBezierPath*)pc_rightBubbleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth triangleDistance:(CGFloat)distance triangleLocation:(CGFloat)location;

@end

