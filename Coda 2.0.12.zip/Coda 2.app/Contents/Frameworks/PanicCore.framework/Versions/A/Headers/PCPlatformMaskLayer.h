//
//  PCPlatformMaskLayer.h
//  PanicCore
//
//  Created by Garrett Moon on 2/1/11.
//  Copyright 2011 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface PCPlatformMaskLayer : CALayer {
	CGPathRef iPath;
}

@property (nonatomic) CGPathRef path;

@end
