#import <Cocoa/Cocoa.h>


@interface PCTransitionTabView : NSTabView
{
	NSString *iAnimationTimingFunction;
	NSString *iTransitionLeft;
	NSString *iTransitionRight;
}

@property (copy) NSString* animationTimingFunction;
@property (copy) NSString* transitionLeft;
@property (copy) NSString* transitionRight;

@end
