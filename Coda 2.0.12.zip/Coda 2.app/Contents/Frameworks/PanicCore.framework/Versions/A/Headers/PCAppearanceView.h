//
//  PCAppearanceView.h
//  Coda
//
//  Created by Will Cosgrove on 10/25/07.
//  Copyright 2007 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef enum
{
	kActiveState,
	kInactiveState,
	/*kDisabledState unsupported currently */
} PCAppearanceViewState; 

@protocol PCAppearanceViewDelegate;

@interface PCAppearanceView : NSView
{
	__weak NSObject<PCAppearanceViewDelegate> *iDelegate;
}

@property (nonatomic, readwrite, assign) NSObject <PCAppearanceViewDelegate>* delegate;

// subclass hook to allow views to change their own appearance
- (void)appearanceStateDidChange:(PCAppearanceViewState)aState;

- (PCAppearanceViewState)appearanceState;
- (PCAppearanceViewState)appearanceStateForWindow:(NSWindow*)window; // utility method

@end

@protocol PCAppearanceViewDelegate

@optional
-(void)appearanceView:(PCAppearanceView*)aView stateDidChange:(PCAppearanceViewState)aState;

@end
