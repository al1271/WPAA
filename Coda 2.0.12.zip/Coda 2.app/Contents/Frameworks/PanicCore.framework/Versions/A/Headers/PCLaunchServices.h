#import <Cocoa/Cocoa.h>

/*
 *  PCLaunchServices.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	Provides convenience methods around the Launch Services framework
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface PCLaunchServices : NSObject
{

}

+ (NSArray*)helperApplicationsForURL:(NSURL*)url;
+ (NSString*)pathOfDefaultHelperForScheme:(NSString*)scheme;
+ (BOOL)setHelperApplication:(NSString*)appPath forScheme:(NSString*)scheme;
+ (BOOL)setHelperApplicationIdentifier:(NSString*)bundleID forScheme:(NSString*)scheme;


@end
