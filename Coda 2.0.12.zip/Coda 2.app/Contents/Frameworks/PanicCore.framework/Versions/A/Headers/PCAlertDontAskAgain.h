//
//  PCAlertDontAskAgain.h
//  PanicCore
//
//  Created by Wade Cosgrove on 12/9/10.
//  Copyright 2010 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PCAlertDontAskAgain : NSAlert 
{
	SEL iDidEndSelector;
	id iModalDelegate;
	NSString *iIdentifier;
	BOOL iIgnoreExistingReturnCode;
}

@property (nonatomic, copy) NSString *identifier;
@property (nonatomic, assign) BOOL ignoreExistingReturnCode;

+ (PCAlertDontAskAgain *)alertWithMessageText:(NSString *)messageTitle identifier:(NSString*)idenfifier defaultButton:(NSString *)defaultButtonTitle alternateButton:(NSString *)alternateButtonTitle otherButton:(NSString *)otherButtonTitle informativeTextWithFormat:(NSString *)informativeText;
+ (PCAlertDontAskAgain *)alertWithError:(NSError *)error identifier:(NSString*)identifier;

- (void)beginSheetModalForWindow:(NSWindow *)window modalDelegate:(id)modalDelegate didEndSelector:(SEL)alertDidEndSelector contextInfo:(void *)contextInfo identifier:(NSString*)identifier;
- (void)beginSheetModalForWindow:(NSWindow *)window modalDelegate:(id)modalDelegate didEndSelector:(SEL)alertDidEndSelector contextInfo:(void *)contextInfo identifier:(NSString*)identifier ignoreExistingReturnCode:(BOOL)ignore;

- (NSInteger)runModalWithIdentifier:(NSString*)identifier;
- (NSInteger)runModalWithIdentifier:(NSString*)identifier ignoreExistingState:(BOOL)ignoreExistingState;


+ (void)clearReturnCodeForIdentifier:(NSString*)identifier;
+ (NSInteger)returnCodeForIdentifier:(NSString*)identifier;
+ (void)setReturnCode:(NSInteger)returnCode forIdentifier:(NSString*)identifier;

+ (void)clearAllPersistentReturnCodes;

@end
