#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@interface PCFont : NSObject <NSCoding>
{
#if TARGET_OS_IPHONE
	UIFont *iFont;
#else
	NSFont *iFont;
#endif

}

+ (Class)platformFontClass;

+ (CGFloat)systemFontSize;
+ (CGFloat)smallSystemFontSize;
+ (PCFont*)systemFontOfSize:(CGFloat)fontSize;
+ (PCFont*)fontWithName:(NSString*)name size:(CGFloat)size;
+ (PCFont*)fontWithCTFont:(CTFontRef)font;
+ (PCFont*)boldSystemFontOfSize:(CGFloat)size;

#if TARGET_OS_IPHONE
@property (readonly) UIFont *platformFont;
#else
@property (readonly) NSFont *platformFont;
#endif

@property (readonly) CGFontRef CGFont;
@property (readonly) CTFontRef CTFont;
@property (readonly) CGFloat pointSize;

@end
