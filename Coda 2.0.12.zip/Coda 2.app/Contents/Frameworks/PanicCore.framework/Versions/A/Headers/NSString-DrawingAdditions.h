#import <Foundation/Foundation.h>


@interface NSString (DrawingAdditions)

- (void)pc_drawFadingTrunctionInRect:(NSRect)rect withAttributes:(NSDictionary *)attrs fade:(CGFloat)fadeLength;

@end


@interface NSAttributedString (DrawingAdditions)

- (void)pc_drawFadingTrunctionInRect:(NSRect)rect fade:(CGFloat)fadeLength;
- (void)pc_drawFadingTrunctionInRect:(NSRect)rect options:(NSStringDrawingOptions)options fade:(CGFloat)fadeLength;

@end
