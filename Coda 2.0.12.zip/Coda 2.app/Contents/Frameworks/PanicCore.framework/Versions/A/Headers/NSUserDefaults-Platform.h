//
//  NSUserDefaults-Platform.h
//  PanicCore
//
//  Created by Garrett Moon on 10/22/10.
//  Copyright 2010 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSUserDefaults (platform)

- (id)unarchivedObjectForKey:(NSString *)key;
- (void)setObjectToBeArchived:(NSObject <NSCoding> *)object forKey:(NSString *)key;

@end
