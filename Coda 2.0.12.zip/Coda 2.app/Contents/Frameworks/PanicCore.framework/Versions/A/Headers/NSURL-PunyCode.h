#import <Foundation/Foundation.h>


@interface NSURL (PCPunyCode)

// returns self if conversion fails or no encoding is needed
- (NSURL*)pc_punyCode;

// returns URLWithString:[str pc_punyCode]
+ (id)pc_URLWithString:(NSString*)str;

@end
