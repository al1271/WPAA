#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>

@interface PCMapTable : NSObject 
{
	CFMutableDictionaryRef iMapTable;
}

+ (PCMapTable*)mapTableWithStrongToStrongObjects;
+ (PCMapTable*)mapTableWithStrongToWeakObjects;

- (id)initMapTableWithStrongToStrongObjects;
- (id)initMapTableWithStrongToWeakObjects;

- (id)objectForKey:(id)aKey;
- (void)setObject:(id)anObject forKey:(id)aKey;
- (void)removeObjectForKey:(id)aKey;
- (void)removeAllObjects;
- (NSArray*)allValues;
- (NSEnumerator*)keyEnumerator;
- (NSEnumerator*)objectEnumerator;

@end
