/* PCImageView */

#import <Cocoa/Cocoa.h>
#import <PanicCore/Protocols.h>

@interface PCImageView : NSImageView
{
	NSImageInterpolation iImageInterpolation;
	CGFloat	iReflection;
	IBOutlet NSObject <PCViewDraggingDelegateProtocol> * iDraggingDelegate;

}

@property (assign, readwrite) NSObject *draggingDelegate;
@property NSImageInterpolation imageInterpolation;
@property CGFloat reflection;

@end


@interface NSImageView (PCCustomImageInit)

- (id)pc_initWithImage:(NSImage*)anImage;

@end
