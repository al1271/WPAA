//
//  NSGraphicsContext-Utilities.h
//  PanicCore
//
//  Created by Ian Cely on 7/21/11.
//  Copyright 2011 Panic. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface NSGraphicsContext (PCUtilities)

- (NSRect)pc_clipRect;

@end
