#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#import <CoreText/CoreText.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@class PCFont;

@interface NSString (Platform)

#if TARGET_OS_IPHONE
- (CGSize)pc_sizeWithFont:(UIFont*)font; // see UIString-sizeWithFont for details
#else
- (CGSize)pc_sizeWithFont:(NSFont*)font;
#endif

- (CGSize)pc_sizeWithCTFont:(CTFontRef)font;

@end
