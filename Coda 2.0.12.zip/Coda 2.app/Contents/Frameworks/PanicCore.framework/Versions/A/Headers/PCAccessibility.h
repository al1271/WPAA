/*
 *  PCAccessiblity.h
 *  PanicCore
 *
 *  Created by Ian Cely on 10/1/09.
 *  Copyright 2009 Panic Inc.. All rights reserved.
 *
 */

#import <Cocoa/Cocoa.h>

@interface NSObject (PCAccessibilitySetIsIgnored)

- (void)pc_accessibilityOverrideIsIgnored:(BOOL)override;

@end

// from ImageMapExampleController.m in ImageMapExample sample
extern void PCSetSegmentDescriptions(NSSegmentedControl* control, NSString* firstDescription, ...);
