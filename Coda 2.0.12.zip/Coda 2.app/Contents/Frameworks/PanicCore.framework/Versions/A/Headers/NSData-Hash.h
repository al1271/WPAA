//
//  NSData-Hash.h
//  PanicCore
//
//  Created by Ian Cely on 12/16/09.
//  Copyright 2009 Panic Inc.. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSData (PCHash)

- (NSData*)pc_SHA1Hash;
- (NSData*)pc_HMACSHA1WithKey:(NSData*)key; // <http://tools.ietf.org/html/rfc2104>
- (NSString*)pc_MD5String;

@end

@interface NSString (PCStringHash)

- (NSString*)pc_MD5String;

@end