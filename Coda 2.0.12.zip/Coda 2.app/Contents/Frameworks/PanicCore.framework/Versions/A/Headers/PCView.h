#if TARGET_OS_IPHONE
	#import <Foundation/Foundation.h>
	#import <UIKit/UIKit.h>
#else
	#import <Cocoa/Cocoa.h>
#endif

#if TARGET_OS_IPHONE
@interface PCView : UIView {
#else
@interface PCView : NSView {
#endif

}

- (id)initWithCGFrame:(CGRect)frame;

#if TARGET_OS_IPHONE
- (void)setNeedsDisplay:(BOOL)flag;
#else
- (void)setNeedsDisplay;	
#endif

- (CGRect)visibleCGRect;
- (void)drawCGRect:(CGRect)rect;

- (CGRect)CGRectBounds;
- (void)setNeedsLayout;
- (void)layoutIfNeeded;
- (BOOL)inLiveResize;

@end
