#import <Foundation/Foundation.h>


@interface NSArray (PCAdditions)

// analogous to -lastObject, can return nil
- (id)pc_firstObject;

// greatest returned value is MIN([self count], [other count])
- (NSUInteger)pc_indexOfFirstMismatchedObjectInArray:(NSArray*)other;

- (NSArray *)pc_coalesceRanges;

- (id)pc_objectPassingTest:(BOOL (^)(id obj, NSUInteger idx, BOOL *stop))predicate;

@end
