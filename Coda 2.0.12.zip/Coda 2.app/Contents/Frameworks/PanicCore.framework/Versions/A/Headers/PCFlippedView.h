#import <Cocoa/Cocoa.h>

/*
 *  PCFlippedView.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *	Is a basic view that returns YES to isFlipped. Has basic nib loading support as well. 
 *
 *	-------------------------------------------------------------------
 *
 *
 */


@interface PCFlippedView : NSView
{
}

@end
