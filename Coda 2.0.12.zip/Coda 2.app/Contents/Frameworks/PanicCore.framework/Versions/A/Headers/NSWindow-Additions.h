//
//  NSWindow-Additions.h
//  PanicCore
//
//  Created by Dan Messing on 5/9/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSWindow (PCAdditions)

- (NSButton *)pc_fullScreenButton;
- (NSRect)pc_convertRectToScreen:(NSRect)aRect;
@end
