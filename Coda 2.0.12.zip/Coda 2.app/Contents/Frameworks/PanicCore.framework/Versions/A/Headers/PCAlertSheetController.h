//
//  PCAlertSheetController.h
//  PanicCore
//
//  Created by Ian Cely on 10/21/10.
//  Copyright 2010 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "PCSheetController.h"

@interface PCAlertSheetController : PCSheetController
{
@private
	NSAlert* iAlert;
}

+ (id)queuedControllerWithAlert:(NSAlert*)alert 
							tag:(NSInteger)tag
					   delegate:(NSObject <PCSheetControllerDelegate>*)delegate
			  interfaceDelegate:(NSObject <PCSheetControllerInterfaceDelegate>*)interfaceDelegate
					contextInfo:(NSDictionary*)contextInfo;

+ (id)queuedControllerWithError:(NSError*)error
							tag:(NSInteger)tag
					   delegate:(NSObject <PCSheetControllerDelegate>*)delegate
			  interfaceDelegate:(NSObject <PCSheetControllerInterfaceDelegate>*)interfaceDelegate
					contextInfo:(NSDictionary*)contextInfo;

@property (nonatomic, retain) NSAlert* alert;

@end
