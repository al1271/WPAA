//
//  PCViewController.h
//  PanicCore
//
//  Created by Logan Collins on 2/27/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PCViewController : NSViewController {
@private
    NSImage *_image;
    NSUndoManager *_undoManager;
}

/*!
 * @method initWithNibName:bundle:
 * @abstract Creates a view controller from a nib/xib
 * 
 * @discussion
 * This is the designated initializer
 * 
 * @result A new PCViewController object
 */
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil; // Designated initializer

/*!
 * @method initWithView:
 * @abstract Creates a view controller from a view
 * 
 * @discussion
 * This method calls -initWithNibName:bundle: with a nil value for both arguments
 * 
 * @result A new PCViewController object
 */
- (id)initWithView:(NSView *)aView;


/*!
 * @property title
 * @abstract Gets the title of the view controller
 * 
 * @result An NSString object
 */
@property (copy) NSString *title;

/*!
 * @property image
 * @abstract Gets the image of the view controller
 * 
 * @result An NSImage object
 */
@property (copy) NSImage *image;

/*!
 * @property undoManager
 * @abstract Gets the undo manager of the view controller
 * 
 * @result An NSUndoManager object
 */
@property (strong) NSUndoManager *undoManager;


/*!
 * @method viewDidLoad
 * @abstract Called after the controller's view is first loaded
 */
- (void)viewDidLoad;

/*!
 * @method viewDidLoad
 * @abstract Called after the controller's view is unloaded
 */
- (void)viewDidUnload; // Not currently invoked

/*!
 * @method viewWillAppear
 * @abstract Called before the controller's view is displayed
 */
- (void)viewWillAppear;

/*!
 * @method viewWillAppear
 * @abstract Called after the controller's view is displayed
 */
- (void)viewDidAppear;

/*!
 * @method viewWillAppear
 * @abstract Called before the controller's view is hidden
 */
- (void)viewWillDisappear;

/*!
 * @method viewWillAppear
 * @abstract Called after the controller's view is hidden
 */
- (void)viewDidDisappear;

@end
