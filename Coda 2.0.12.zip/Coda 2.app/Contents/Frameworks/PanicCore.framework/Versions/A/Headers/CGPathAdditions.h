//
//  CGPathAdditions.h
//  PanicCore
//
//  Created by Garrett Moon on 12/22/10.
//  Copyright 2010 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import <CoreGraphics/CoreGraphics.h>
#endif

CGMutablePathRef PCCreatePathWithRectRadius(CGRect rect, CGFloat radius);
