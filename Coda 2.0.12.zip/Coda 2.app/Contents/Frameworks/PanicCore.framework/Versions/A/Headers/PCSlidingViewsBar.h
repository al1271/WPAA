#import <Cocoa/Cocoa.h>
#import <PanicCore/Protocols.h>

@class DragImageAnimator;
@class PCChevronPopUpButton;
@class PCSlidingAnimation;


@protocol SlidingViewProtocol
- (NSImage*)dragImage;
+ (NSString*)dragReorderPboardType;
@end


@interface PCSlidingViewsBar : NSView <NSAnimationDelegate, PCKeyLoopProtocol>
{
    NSInteger		dragSourceIndex;
    NSInteger		dropIndex;
    CGFloat			draggedItemWidth;
    NSMutableArray	*buttons;
    NSPopUpButton	*clipButton;
	BOOL			needsLayout;
	PCSlidingAnimation	*animation;    
	NSInteger		iFirstVisibleButtonIndex;
	NSInteger		iNumberOfVisibleButtons;
	BOOL			iAlwaysShowSelectedButton; // allows the first visible tab index to be non-zero
    NSArray			*iDraggedViewRegisteredDraggedTypes; // cache off the dragged types to allow for drag-reording with custom drag types

	// delegate
	
	IBOutlet id	delegate;
	BOOL	delegateSupportsViewMoving;		// allows moving a view from one view to another
	BOOL	delegateSupportsViewTearOff;	// allows moving a view to a new window
}

@property (nonatomic, assign) BOOL alwaysShowSelectedButton; 
@property (nonatomic, assign) NSInteger firstVisibleButtonIndex;
@property (nonatomic, readonly) NSInteger numberOfVisibleButtons;
@property (nonatomic, assign) NSInteger dragSourceIndex; // treat as private
@property (nonatomic, assign) BOOL needsLayout;

- (void)insertInButtons:(NSView*)button;
- (void)insertInButtons:(NSView*)button atIndex:(NSInteger)index;
- (void)moveViewFromIndex:(NSInteger)originalIndex toIndex:(NSInteger)targetIndex;
- (void)removeFromButtonsAtIndex:(NSInteger)index;
- (NSView*)buttonAtIndex:(NSInteger)index;
- (NSButton*)buttonWithRepresentedObject:(id)object;
- (NSButton*)buttonWithTag:(NSInteger)tag;

//- (void)replaceInButtons:(NSView*)button atIndex:(NSInteger)index;

- (void)setClipIndicatorButton:(NSPopUpButton*)aButton;
- (void)setClipIndicatorVisible:(BOOL)flag;
- (BOOL)isClipIndicatorVisible;
- (void)updateClippingMenu;

- (id)delegate;
- (void)setDelegate:(id)newDelegate;

- (NSView*)firstKeyView;
- (NSView*)lastKeyView;
- (void)recalculateKeyViewLoop;

// layout

- (CGFloat)minButtonY;
- (CGFloat)minButtonX;
- (CGFloat)paddingBetweenButtons;

- (CGFloat)maxButtonXWithClipIndicator:(BOOL)includingIndicator;
- (CGFloat)maxButtonX;

- (void)layoutButtons;
- (NSRect)frameWithProposedFrame:(NSRect)inFrame forButton:(NSView*)button; // given a proposed frame, returns the actual frame

// internal action

- (void)selectedItemFromClippingMenu:(id)sender;

//- (CGFloat)minSlidingViewX; // the x origin of the first button while dragging is taking place

// drag and drop


- (void)moveDraggedButtonToView:(PCSlidingViewsBar*)targetView atIndex:(NSInteger)targetIndex;
- (BOOL)canMoveButtonsToNewViewViaDrag;
- (BOOL)performNewWindowDragOperation:(NSDragOperation)operation atPoint:(NSPoint)aPoint;

- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender;
- (void)draggingExited:(id <NSDraggingInfo>)sender;
- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender;

- (NSInteger)dropIndexFromDraggingInfo:(id <NSDraggingInfo>)sender; // drop index based on drag image location
- (NSInteger)dropIndexFromLocalPoint:(NSPoint)localPoint; // drop index based on point position
- (void)setDropIndex:(NSInteger)newIndex;

- (CGFloat)slidingWidthForView:(NSView*)aView; // width of view while a drag in progress
- (CGFloat)widthOfDraggingInfo:(id<NSDraggingInfo>)draggingInfo; // width of drag image
- (void)slideButtonsIntoPlace; // begins drag animation, moves buttons to correct location
- (void)mouseDragged:(NSEvent*)dragEvent slidingView:(NSView <SlidingViewProtocol> *)draggedView; // called from button when dragging should start
- (BOOL)slideBackDragImage;

// very much internal, but needed (ignore)
- (void)setDraggingViewPboardType:(NSString*)pboardType;

@end


@interface NSObject (SlidingViewsBarDelegate)

// allows moving a view from one view to another
- (void)slidingViewsBar:(PCSlidingViewsBar*)slidingView movedViewAtIndex:(NSInteger)oldIndex toView:(PCSlidingViewsBar*)sourceBar atIndex:(NSInteger)newIndex;

// reordering views in same view
- (void)slidingViewsBar:(PCSlidingViewsBar*)slidingView movedViewFromIndex:(NSInteger)oldIndex toIndex:(NSInteger)newIndex;

// allows moving a view to a new window
- (NSWindow*)slidingViewsBar:(PCSlidingViewsBar*)slidingView windowForViewAtIndex:(NSInteger)buttonIndex;

// informs delegate to finalize the button moving to the new window
- (BOOL)slidingViewsBar:(PCSlidingViewsBar*)slidingView moveViewAtIndex:(NSInteger)buttonIndex toWindow:(NSWindow*)aWindow;

// allows delegate to add pasteboard data for a button when starting a drag
- (void)slidingViewsBar:(PCSlidingViewsBar*)slidingView writeViewAtIndex:(NSInteger)buttonIndex toPasteboard:(NSPasteboard*)draggingPasteboard;

// drag and drop validation
- (NSDragOperation)slidingViewsBar:(PCSlidingViewsBar *)slidingView validateDrop:(id <NSDraggingInfo>)draggingInfo index:(NSInteger)buttonIndex;

// drag and drop acception
- (BOOL)slidingViewsBar:(PCSlidingViewsBar*)slidingView acceptDrop:(id <NSDraggingInfo>)draggingInfo index:(NSInteger)buttonIndex;

@end