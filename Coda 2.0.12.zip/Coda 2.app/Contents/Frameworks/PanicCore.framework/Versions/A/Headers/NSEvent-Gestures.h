//
//  NSEvent-Gestures.h
//  PanicCore
//
//  Created by Wade Cosgrove on 1/18/10.
//  Copyright 2010 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef enum
{
	PCSwipeEventDirectionUnknown = 0,
	PCSwipeEventDirectionUp,
	PCSwipeEventDirectionDown,
	PCSwipeEventDirectionLeft,
	PCSwipeEventDirectionRight
} PCSwipeEventDirection;


@interface NSEvent (PCGestures)

- (PCSwipeEventDirection)pc_swipeEventDirection;

@end
