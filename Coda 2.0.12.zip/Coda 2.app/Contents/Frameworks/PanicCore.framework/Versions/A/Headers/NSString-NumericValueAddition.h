#import <Foundation/Foundation.h>

@interface NSString (PCNumericValueAdditions)

+ (NSString*)pc_stringWithFloat:(float)aFloat maxFractionalDigits:(short)maxFracDigits;

- (unsigned long long)pc_unsignedLongLongValue;

@end
