//
//  PCDarkScroller.h
//  PanicCore
//
//  Created by Wade Cosgrove on 5/6/09.
//  Copyright 2009 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PCDarkScroller : NSScroller 
{

}

- (BOOL)isVertical;

@end
