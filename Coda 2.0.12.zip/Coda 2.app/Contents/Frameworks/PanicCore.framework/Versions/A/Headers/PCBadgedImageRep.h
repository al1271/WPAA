#import <Cocoa/Cocoa.h>


@interface PCBadgedImageRep : NSImageRep
{
@private
	NSImage* iBaseImage;
	NSImage* iBadgeImage;
}

@property(nonatomic, readonly, copy) NSImage* baseImage;
@property(nonatomic, readonly, copy) NSImage* badgeImage;

- (id)initWithImage:(NSImage*)baseImage badge:(NSImage*)badgeImage;

@end
