#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@class PCColor;
@class CKBezierPath;
#if TARGET_OS_IPHONE
@class PCView;

@interface PCProgressPieCell : NSObject
#else
@interface PCProgressPieCell : NSCell
#endif
{
	CKBezierPath *wedge;
	CKBezierPath *background;
	PCColor *pieColor;
	PCColor *wedgeColor;
	PCColor *selectedPieColor;
	PCColor *selectedWedgeColor;
	CGSize	pieSize;
	
	CGFloat	percentShaded;
	BOOL pieNeedsUpdate;
	BOOL usesWedgeColorForStroke;
	
#if TARGET_OS_IPHONE
	id iControlView;
	BOOL iHighlighted;
#endif
}

@property (nonatomic, assign) CGFloat percentShaded;
@property (nonatomic, retain) PCColor* pieColor;
@property (nonatomic, retain) PCColor* selectedPieColor;
@property (nonatomic, retain) PCColor* wedgeColor;
@property (nonatomic, retain) PCColor* selectedWedgeColor;
@property (nonatomic, assign) BOOL usesWedgeColorForStroke;

#if TARGET_OS_IPHONE
@property (nonatomic, assign, getter = isHighlighted) BOOL highlighted;
@property (nonatomic, assign) id controlView;

- (void)drawWithFrame:(CGRect)cellFrame inView:(PCView *)controlView;
#endif

@end
