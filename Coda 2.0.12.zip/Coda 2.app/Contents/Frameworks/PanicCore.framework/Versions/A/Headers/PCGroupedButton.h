//
//  PCGroupedButton.h
//  PanicCore
//
//  Created by Garrett Moon on 1/28/11.
//  Copyright 2011 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

typedef enum
{
	PCGroupedButtonSegmentTypeSolitary,
	PCGroupedButtonSegmentTypeTop,
	PCGroupedButtonSegmentTypeMiddle,
	PCGroupedButtonSegmentTypeBottom
}PCGroupedButtonSegmentType;

@class PCGroupedButtonConfirmButton;
@class PCTouchCaptureView;

@interface PCGroupedButton : UIControl <UITextFieldDelegate>{
	BOOL iConfirm;
	BOOL iRequiresTextForConfirm;
	BOOL iAnimatesOnConfirm;
	BOOL iDisabled;
	
	UITextField *iInputField;
	
	id iDelegate;
	id iInputDelegate;
	
	NSString *iText;
	CATextLayer *_textLayer;
	CATextLayer *_textShadowLayer;
	
	UIImage *iIcon;
	CALayer *_imageLayer;
	
	NSString *iConfirmText;
	CATextLayer *_confirmTextLayer;
	CATextLayer *_confirmTextShadowLayer;
	
	PCGroupedButtonConfirmButton *_confirmButton;
//	CALayer *_confirmButtonLayer;
//	PCGroupedButtonConfirmButtonDelegate *_confirmButtonLayerDelegate;
	UIColor *iButtonColor;
	UIColor *iConfirmColor;
	PCGroupedButtonSegmentType iSegmentType;
	CGFloat iFontSize;
	
	PCTouchCaptureView *_touchCaptureView;
	
	BOOL _confirming;
	
	CGMutablePathRef path;
}
@property (assign) BOOL confirm;
@property (assign) BOOL requiresTextForConfirm;
@property (assign) BOOL animatesOnConfirm;
@property (assign) BOOL disabled;
@property (assign) id delegate;
@property (assign) id inputDelegate;
//@property (readonly) CGMutablePathRef path;
@property (retain) UITextField *inputField;
@property (retain) NSString *text;
@property (retain) UIImage *icon;
@property (retain) NSString *confirmText;
@property (retain) UIColor *buttonColor;
@property (nonatomic, retain) UIColor *confirmColor;
@property (assign) PCGroupedButtonSegmentType segmentType;
@property (assign) CGFloat fontSize;

@property (assign) BOOL confirming;

@end

@interface NSObject (PCGroupedButtonDelegate)

- (void)buttonConfirmed:(PCGroupedButton *)sender withString:(NSString *)string;

@end

@interface PCGroupedButtonConfirmButton : UIButton
{
	PCGroupedButton *iGroupedButton;
}

@property (assign) PCGroupedButton *groupedButton;

@end

#endif
