#import <Cocoa/Cocoa.h>


@interface NSResponder (Views)

- (BOOL)pc_isSubviewOf:(NSView*)aView;

- (NSData*)pc_stateRestorationData;
- (void)pc_restoreStateWithData:(NSData*)data;

@end


@interface NSView (Key)

- (BOOL)pc_showsKey;

@end