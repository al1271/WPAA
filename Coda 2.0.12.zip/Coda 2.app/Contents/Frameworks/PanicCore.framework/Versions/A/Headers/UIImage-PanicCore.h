//
//  UIImage-Operations.h
//  dietcoda
//
//  Created by Garrett Moon on 7/7/11.
//  Copyright 2011 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIImage (PanicCore)

- (UIImage *)pc_smallImageWithMaxDimension:(CGFloat)maxDimension;
- (UIImage *)pc_croppedImageWithRect:(CGRect)cropRect;

@end

#endif