//
//  PCEncryptedStore.h
//  Coda
//
//  Created by Logan Collins on 8/23/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PanicCore/PanicCoreDefines.h>


/*!
 * @class PCEncryptedStore
 * @abstract A object that automatically encrypts data
 * 
 * @discussion
 * An encrypted store is a dictionary-like object that stores a key-to-value mapping
 * of objects. The store automatically encrypts values when they are stored, and
 * decrypts them when accessed (provided the store is unlocked).
 *
 * PCEncryptedStore is an abstract class. Concrete subclasses should implement
 * the base set of methods (defined in the class interface itself) to conform
 * to whatever encryption standard is desired.
 * 
 * A store has the notion of being "locked" or "unlocked". If a store is locked,
 * it is unable to encrypt or decrypt data. It must be unlocked in order for data to
 * be added, removed or retrieved. The methods which accesses or modify the values
 * in the store will raise a PCEncryptedStoreLockedException if the store is locked.
 * Such a circumstance should always be preempted by the developer using the -isLocked
 * method. A store's keys are always accessible, and should not be considered sensitive.
 * 
 * While PCEncryptedStore conforms to the NSCoding and NSCopying protocols, the base
 * implementation does not encode/decode or copy data. This implementation is left up
 * to concrete subclassers. The base implementation of these methods raise an exception.
 */
@interface PCEncryptedStore : NSObject <NSCoding, NSCopying, NSFastEnumeration>

/*!
 * @property locked
 * @abstract Whether the store is locked to access
 * 
 * @discussion
 * If a store is locked, certain methods raise exceptions when accessed.
 * Clients should always check the this property before accessing data.
 * 
 * @result A BOOL value
 */
@property (readonly, getter=isLocked) BOOL locked;

/*!
 * @property count
 * @abstract The number of items in the store
 * 
 * @result An NSUInteger value
 */
@property (readonly) NSUInteger count;


/*!
 * @method hasObjectForKey:
 * @abstract Determines whether the store contains an object for a specified key
 *
 * @param key
 * The key for which to check
 *
 * @result A BOOL value
 */
- (BOOL)hasObjectForKey:(id)key;

/*!
 * @method objectForKey:
 * @abstract Gets the object for a specified key
 * 
 * @param key
 * The key for which to retrieve an object
 * 
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 * 
 * @result An object, or nil
 */
- (id)objectForKey:(id)key;

/*!
 * @method setObject:forKey:
 * @abstract Sets the object for a specified key
 * 
 * @param obj
 * The object to set
 * 
 * @param key
 * The key for which to set the object
 *
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 */
- (void)setObject:(id <NSCoding>)obj forKey:(id <NSCoding, NSCopying>)key;

/*!
 * @method removeObjectForKey:
 * @abstract Removes the object for a specified key
 * 
 * @param key
 * The key for which to remove the object
 *
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 */
- (void)removeObjectForKey:(id)key;


/*!
 * @property keyEnumerator
 * @abstract Returns an enumerator object for the store's keys
 * 
 * @result An NSEnumerator object
 */
@property (readonly) NSEnumerator *keyEnumerator;

@end


/*!
 * @category PCEncryptedStore(PCExtendedEncryptedStore)
 * @abstract Additions to the base interface methods
 * 
 * @discussion
 * Subclasses need not override these methods unless a specific feature is required.
 * They call into the base methods as part of their implementation.
 */
@interface PCEncryptedStore (PCExtendedEncryptedStore)

/*!
 * @method removeAllObjects
 * @abstract Removes all objects in the store
 *
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 */
- (void)removeAllObjects;

/*!
 * @method removeObjectsForKeys:
 * @abstract Removes the objects for a set of keys
 * 
 * @param keyArray
 * The array of keys to remove
 *
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 */
- (void)removeObjectsForKeys:(NSArray *)keyArray;


/*!
 * @method objectForKeyedSubscript:
 * @abstract Gets the object for a specified key
 *
 * @param key
 * The key for which to retrieve an object
 *
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 *
 * @result An object, or nil
 */
- (id)objectForKeyedSubscript:(id)key;

/*!
 * @method setObject:forKeyedSubscript:
 * @abstract Sets the object for a specified key
 *
 * @param obj
 * The object to set
 *
 * @param key
 * The key for which to set the object
 *
 * @discussion
 * If the store is locked, this method raises a PCEncryptedStoreLockedException.
 */
- (void)setObject:(id <NSCoding>)obj forKeyedSubscript:(id <NSCoding, NSCopying>)key;

@end


/*!
 * @constant PCEncryptedStoreLockedException
 * @abstract Raised when an encrypted store's values are access or mutated while the store is locked
 */
PANICCORE_EXTERN NSString * const PCEncryptedStoreLockedException;

