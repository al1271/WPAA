#import "PCAccessoryWindow.h"
#import "PCView.h"
#import <QuartzCore/QuartzCore.h>

@class PCPopoverView;

@protocol PCPopoverDelegateProtocol;


@interface PCPopover : NSObject <PCAccessoryWindowDelegateProtocol, NSWindowDelegate>
{
#if TARGET_OS_IPHONE
	UIViewController *iContentViewController;
#else
	NSViewController *iContentViewController;
	NSWindow *iWindow;
#endif
	
	NSObject <PCPopoverDelegateProtocol>	*iDelegate;
   	NSRectEdge	iBubbleTriangleEdge; // -1 (not the preferred edge, but rather the inverse
	CGFloat 	iTriangleArrowOffset;
	CGFloat     iContentViewMargin;
    BOOL 		iNeedsLayout;
	BOOL        iClosing;
    
	NSView* contentView;
	NSView* backgroundView;
	PCPopoverView *iBorderView;
    NSColor* iBackgroundColor;
    NSColor* iStrokeColor;
    BOOL iDrawHeader;
	BOOL isAnimatingBackground;
	Class iWindowClass;
	
	NSImage		*iCachedBGImage;
}

+ (CGFloat)headerHeight;

#if TARGET_OS_IPHONE
@property (nonatomic, retain) UIViewController *contentViewController;
#else
@property (nonatomic, retain) NSViewController *contentViewController;
@property (nonatomic, retain) NSImage *cachedBGImage;
#endif
@property (nonatomic, assign) CGSize contentSize;
@property (nonatomic, assign) CGFloat contentViewMargin;
@property (nonatomic, assign) NSObject <PCPopoverDelegateProtocol> *delegate;
@property (readonly) BOOL shown;
@property (readonly, getter = isClosing) BOOL closing;
@property (readonly) CGRect positioningRect; // current rect on screen
@property (nonatomic, retain) NSColor* backgroundColor;
@property (nonatomic, retain) NSColor* strokeColor;
@property BOOL drawHeader;
@property (nonatomic, assign) Class windowClass;
@property (readonly) NSWindow *window; // don't use directly, consider private

#if TARGET_OS_IPHONE
- (id)initWithContentViewController:(UIViewController*)contentViewController;

- (void)showRelativeToRect:(CGRect)rect ofView:(UIView*)view preferredEdge:(CGRectEdge)edge;
#else
- (id)initWithContentViewController:(NSViewController*)contentViewController;

- (void)showRelativeToRect:(CGRect)rect ofView:(NSView*)view preferredEdge:(CGRectEdge)edge;
#endif

- (void)close;
//- (void)performClose:(id)sender; // consults the delegate before closing

- (void)animateBackgroundColor:(CGColorRef)backgroundColor;

@end


@protocol PCPopoverDelegateProtocol
@optional

- (void)popoverDidClose:(PCPopover*)popover;
- (void)popoverDidShow:(PCPopover*)popover;
- (BOOL)popoverShouldClose:(PCPopover*)popover;
- (void)popoverWillClose:(PCPopover*)popover;
- (void)popoverWillShow:(PCPopover*)popover;

@end


@interface PCPopoverView : PCView 
{
	__weak PCPopover *iPopover;
}

@property (nonatomic, assign) PCPopover *popover;

@end