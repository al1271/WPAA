#import <Cocoa/Cocoa.h>


@interface PCSlowMotionAnimation : NSObject
{

}

+ (BOOL)shouldUseSlowMotionAnimation;
+ (BOOL)shouldUseSlowMotionAnimationForEvent:(NSEvent*)anEvent;

// if slow motion should be run, returns the extended duration
+ (CFTimeInterval)CFSlowMotionDuration:(CFTimeInterval)interval;
+ (NSTimeInterval)NSSlowMotionDuration:(NSTimeInterval)interval;

// returns the computed slow motion duration for given interval
+ (NSTimeInterval)timeIntervalForSlowMotion:(NSTimeInterval)interval;

@end
