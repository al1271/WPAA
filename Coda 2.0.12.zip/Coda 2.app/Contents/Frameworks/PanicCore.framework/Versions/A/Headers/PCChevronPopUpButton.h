#import <Cocoa/Cocoa.h>

@interface PCChevronPopUpButton : NSPopUpButton
{
}

@end


@interface PCChevronPopUpButtonCell : NSPopUpButtonCell
{
	NSImage *iChevronImage;			// image, used for normal drawing
	NSImage *iAlternateChevronImage; // alternateImage, used for inactive state
}

@end
