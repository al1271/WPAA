#import <Foundation/Foundation.h>

@interface NSString (Trim)

// remove the given substring if it exists
- (NSString*)pc_stringByTrimmingPrefix:(NSString*)prefix;
- (NSString*)pc_stringByTrimmingSuffix:(NSString*)suffix;
- (NSString*)pc_stringByTrimmingCharactersInSet:(NSCharacterSet*)charSet; // removes the characters in the set from the end of the string only

- (NSString*)pc_stringByReplacingCharactersInSet:(NSCharacterSet*)charSet withString:(NSString*)aString;
- (NSString*)pc_stringByDeletingCharactersInSet:(NSCharacterSet*)charSet;
- (NSString*)pc_substringToIndex:(NSUInteger)anIndex; // does not raise an exception is beyond end of of receiver

@end
