#import <AppKit/AppKit.h>


@interface NSObject (PCAccessibilityFix)

+ (void)pc_installAccessibilityFix;

@end
