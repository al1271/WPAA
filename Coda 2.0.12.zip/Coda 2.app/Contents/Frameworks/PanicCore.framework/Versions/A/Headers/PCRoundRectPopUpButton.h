#import <Cocoa/Cocoa.h>


@interface PCRoundRectPopUpButton : NSPopUpButton 
{

}

- (void)configure;

@end


@interface PCRoundRectPopUpButtonCell : NSPopUpButtonCell
{
	NSImage			*arrow;
	NSImage			*disabledArrow;
	float			arrowWidth;
	//NSButtonCell	*buttonCell;
}

- (void)configureArrows;
- (void)setArrow:(NSImage*)inArrow;

@end