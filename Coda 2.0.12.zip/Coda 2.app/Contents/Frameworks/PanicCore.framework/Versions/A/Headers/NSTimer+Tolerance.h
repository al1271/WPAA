//
//  NSTimer+Tolerance.h
//  PanicCore
//
//  Created by Wade Cosgrove on 10/3/13.
//  Copyright (c) 2013 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSTimer (Tolerance)

+ (NSTimer *)pc_tolerantTimerWithTimeInterval:(NSTimeInterval)ti target:(id)aTarget selector:(SEL)aSelector userInfo:(id)userInfo repeats:(BOOL)yesOrNo;
+ (NSTimer*)pc_scheduledTolerantTimerWithTimeInterval:(NSTimeInterval)seconds target:(id)target selector:(SEL)aSelector userInfo:(id)userInfo repeats:(BOOL)repeats;
- (id)initTolerantWithFireDate:(NSDate *)date interval:(NSTimeInterval)ti target:(id)t selector:(SEL)s userInfo:(id)ui repeats:(BOOL)rep;

- (void)pc_setDefaultTolerance;

@end
