//
//  CKGradient.h
//  CrimsonKit
//
//  Created by Waqar Malik on 2/7/10.
//  © Copyright 2008 Crimson Research, Inc. All rights reserved.
//
//  ** Panic - Modified to use PCColors **
// 
//  $Id: CKGradient.h 96 2010-06-24 22:15:49Z malik $
//

#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import <CoreGraphics/CoreGraphics.h>
#else
#import <ApplicationServices/ApplicationServices.h>
#endif

@class CKBezierPath, PCColor;

@interface CKGradient : NSObject
{
@protected
	NSArray				*mColors;
	CGGradientRef		mCGGradient;
	CGColorSpaceRef		mColorSpace;
	NSUInteger			mNumberOfColorStops;
	CGFloat				*mLocations;
}

@property (nonatomic, readonly, assign) CGColorSpaceRef colorSpace;
@property (nonatomic, readonly, assign) NSUInteger numberOfColorStops;
@property (nonatomic, readonly, assign) CGGradientRef CGGradient;

// Initialization

+ (id)gradientWithStartingColor:(PCColor*)startingColor endingColor:(PCColor*)endingColor;

- (id)initWithStartingColor:(PCColor *)startingColor endingColor:(PCColor *)endingColor;
- (id)initWithColors:(NSArray *)colorArray;

// Color Location Color Location (MUST be nil terminated)

- (id)initWithColorsAndLocations:(PCColor *)firstColor, ... NS_REQUIRES_NIL_TERMINATION;
- (id)initWithColors:(NSArray *)colorArray atLocations:(const CGFloat *)locations colorSpace:(CGColorSpaceRef)colorSpace;

// Primitive Drawing Methods

- (void)drawFromPoint:(CGPoint)startingPoint toPoint:(CGPoint)endingPoint options:(CGGradientDrawingOptions)options;
- (void)drawFromCenter:(CGPoint)startCenter radius:(CGFloat)startRadius toCenter:(CGPoint)endCenter radius:(CGFloat)endRadius options:(CGGradientDrawingOptions)options;

// Drawing Linear Gradients

- (void)drawInRect:(CGRect)rect angle:(CGFloat)angle;
- (void)drawInBezierPath:(CKBezierPath *)path angle:(CGFloat)angle;

// Drawing Radial Gradients
- (void)drawInRect:(CGRect)rect relativeCenterPosition:(CGPoint)relativeCenterPosition;
- (void)drawInBezierPath:(CKBezierPath *)path relativeCenterPosition:(CGPoint)relativeCenterPosition;

- (void)getColor:(PCColor **)color location:(CGFloat *)location atIndex:(NSInteger)colorIndex;

// Assuming that color and locations are always increasing.
- (PCColor *)interpolatedColorAtLocation:(CGFloat)location;
@end
