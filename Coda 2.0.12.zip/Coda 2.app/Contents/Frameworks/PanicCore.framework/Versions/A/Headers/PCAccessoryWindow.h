#import <Cocoa/Cocoa.h>

@class PCAccessoryWindow;

@protocol PCAccessoryWindowDelegateProtocol
@required

- (void)accessoryWindowShouldClose:(PCAccessoryWindow*)window;

@end


@interface PCAccessoryWindow : NSPanel
{
@private
	BOOL iOptionKeyDown;
}

@property(assign, getter=isOptionKeyDown) BOOL optionKeyDown;

- (PCAccessoryWindow*)initWithMainView:(NSView*)aView;
- (PCAccessoryWindow*)initWithFrame:(NSRect)frame;

- (void)sendCloseCallback;

@end
