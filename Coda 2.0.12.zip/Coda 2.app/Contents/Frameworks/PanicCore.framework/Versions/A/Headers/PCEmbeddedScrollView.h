//
//  PCEmbeddedScrollView.m.h
//  PanicCore
//
//  Created by Wade Cosgrove on 5/5/09.
//  Copyright 2009 Panic, Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PCEmbeddedScrollView : NSScrollView
{
	IBOutlet NSView	*iEmbeddedView;
	NSRectEdge	iViewEdge;
}

- (void)setEmbeddedView:(NSView*)view;

- (void)setEmbeddedViewEdge:(NSRectEdge)edge;

- (BOOL)isEmbeddedViewVisible;
- (void)setEmbeddedViewVisible:(BOOL)flag;

@end
