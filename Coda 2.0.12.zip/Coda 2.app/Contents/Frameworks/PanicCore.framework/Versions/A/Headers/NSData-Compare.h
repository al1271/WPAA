/*
 *  NSData-Compare.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *	Provides a category for easily comparing data blobs.
 *
 *	-------------------------------------------------------------------
 *
 *
 */

#import <Foundation/Foundation.h>


@interface NSData (PCCompare)

- (BOOL)pc_hasPrefix:(NSData*)prefix;
- (BOOL)pc_hasSuffix:(NSData*)suffix;

@end
