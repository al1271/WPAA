#import <Cocoa/Cocoa.h>
#import "Protocols.h"

#define kGradientPathControlHeight 24.0

@protocol PCGradientPathControlDelegate;

@protocol PCPathControlProtocol
- (NSPathComponentCell*)clickedPathComponentCell;
- (NSUInteger)indexOfClickedPathComponentCell;
- (NSArray*)pathComponentCells;
@end


@interface PCGradientPathControl : NSPathControl <PCPathControlProtocol>
{
	BOOL	iShowsStar;
	NSImage *iCustomStarImage;
	NSString *iCustomStarTitle;
	
	SEL		iMenuAction;
	BOOL	iSpringOpenEnabled;
	BOOL 	iFocusLastPathCell;
	NSUInteger iFocusCellIndex; // the cell to draw blue to indicate focus - NSNotFound is none
	BOOL	iDrawsInactive; // defaults to NO
	NSTimer	*iSpringTimer;
	BOOL	iDrawsEndCap;
	BOOL	iCanClickLastComponentCell;
	BOOL	iClickingLastComponentCell;
	BOOL	iPullsDown;
	
	NSString *iTruncatedPathPrefix;
	NSObject <PCViewDraggingDelegateProtocol> * iDraggingDelegate;
}

@property (nonatomic, assign, readwrite) NSObject *draggingDelegate;
@property (nonatomic, assign) BOOL showsStar;
@property (nonatomic, assign) SEL menuAction;
@property (nonatomic, assign) BOOL springOpenEnabled;
@property (nonatomic, assign) BOOL focusLastPathCell;
@property (nonatomic, assign) NSUInteger focusCellIndex;
@property (nonatomic, assign) BOOL drawsEndCap;
@property (nonatomic, assign) BOOL canClickLastComponentCell;
@property (nonatomic, copy) NSImage *customStarImage;
@property (nonatomic, copy) NSString *customStarTitle;
@property (nonatomic, assign) BOOL pullsDown;
@property (nonatomic, assign) BOOL drawsInactive;

- (void)setPath:(NSString*)path;
- (void)setPath:(NSString*)path lastComponentIcon:(NSImage*)image;

- (NSString*)clickedPath;
- (NSUInteger)indexOfClickedPathComponentCell;

- (void)controlTintDidChange:(NSNotification*)notification;

- (id <PCGradientPathControlDelegate>)delegate;

@end


@interface PCGradientPathCell : NSPathCell
{}



+ (Class)pathComponentCellClass;
- (void)drawBackgroundWithFrame:(NSRect)cellFrame inView:(NSView*)view;

@end


@interface PCGradientPathComponentCell : NSPathComponentCell
{
	BOOL iDrawHighlighted;
}

+ (void)buildControlImages;
+ (void)buildColorControlImages:(BOOL)inactive;
+ (void)resetControlImages;

+ (NSImage*)backgroundFill; // needed for split button background
+ (NSColor*)bezelColor; // needed for coda web preview controls
+ (NSImage*)selectedBackgroundFill;
+ (NSImage*)endCap;

- (NSImage*)selectedBackgroundFill;

- (BOOL)isFirstComponent;
- (BOOL)isLastComponent;

- (NSRect)arrowRectForBounds:(NSRect)cellFrame;
- (void)drawBarBackgroundWithFrame:(NSRect)cellFrame inView:(NSView*)controlView;
- (void)drawEndCapWithFrame:(NSRect)cellFrame inView:(NSView*)controlView;
- (BOOL)drawHighlighted;

- (CGFloat)minWidthForArrow;

@end


@interface NSEvent (ModifyLocation)

- (NSEvent*)eventWithMouseLocation:(NSPoint)point;

@end


@protocol PCGradientPathControlDelegate <NSPathControlDelegate>

@optional
- (void)gradientPathControl:(PCGradientPathControl*)control springOpenComponentAtIndex:(NSInteger)index;
- (NSMenuItem*)gradientPathControl:(PCGradientPathControl*)control willPopUpMenu:(NSMenu*)menu;
- (NSMenu*)gradientPathControl:(PCGradientPathControl*)control menuForComponentAtIndex:(NSInteger)index;

@end
