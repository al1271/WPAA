#import <Cocoa/Cocoa.h>


@interface NSCell (Additions)

- (void)pc_setFieldEditorFrame:(NSRect)frame;
- (void)pc_drawPopUpArrowWithFrame:(NSRect)frame pullsDown:(BOOL)pullsDown inView:(NSView*)controlView arrowColor:(NSColor*)arrowColor shadowColor:(NSColor*)shadowColor;

@end
