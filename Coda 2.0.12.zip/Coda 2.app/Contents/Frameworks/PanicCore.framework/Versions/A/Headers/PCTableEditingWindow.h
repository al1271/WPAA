#import <Cocoa/Cocoa.h>

/*
 *  PCTableEditingWindow.h
 *
 *  DEPRECATED: use PCBaseTableView and PCBaseOutlineView instead
 *
 *	-------------------------------------------------------------------
 *
 *
 */


@interface PCTableEditingWindow : NSWindow
{
}

- (BOOL)endTableEditing __attribute__((deprecated));

@end
