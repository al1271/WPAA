#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>


@class PCEvent, PCView, PCFont;
@protocol PCLayerCellProtocol;

typedef enum
{
    kPCLayerCellAllPart = -1,
    kPCLayerCellDeletePart = -2,
}
PCLayerCellPart;


typedef enum
{
    kPCLayerCellEditingStyleNone = 1 << 0,
    kPCLayerCellEditingStyleDelete = 1 << 1,
    kPCLayerCellEditingStyleTitle = 1 << 2,
	kPCLayerCellEditingStyleWiggle = 1 << 3,
	kPCLayerCellEditingStyleDisabled = 1 << 4,
}
PCLayerEditingStyle;


@interface PCGridViewLayerCell : CALayer 
{
    __weak PCView <PCLayerCellProtocol> *iContainerView;
    
    PCLayerEditingStyle iEditingStyle;
    BOOL iSelected;
    BOOL iHighlighted;
    BOOL iEditing;
	BOOL iEnabled;
	BOOL iHoveredOver;
	BOOL iShowsFirstResponder;
    
    //grouping
    BOOL iGroup;
    CFMutableArrayRef iGroupImages;
}


@property (assign) __weak PCView *containerView;
@property (assign) PCLayerEditingStyle editingStyle;
@property (nonatomic, assign, getter = isSelected) BOOL selected;
@property (nonatomic, readonly, getter = isHighlighted) BOOL highlighted;
@property (assign, getter = isEditing) BOOL editing;
@property (assign, getter = isGroup) BOOL group;
@property (assign, getter = isEnabled) BOOL enabled;
@property (nonatomic, assign, getter = isHoveredOver) BOOL hoveredOver;
@property (nonatomic, assign) BOOL showsFirstResponder;

- (void)startTracking:(PCEvent*)event inView:(PCView*)eventView;
- (void)continueTracking:(PCEvent*)event inView:(PCView*)eventView;
- (void)endTracking:(PCEvent*)event inView:(PCView*)eventView;
- (void)cancelTracking:(PCEvent*)event inView:(PCView*)eventView;

- (void)addEditingStyle:(PCLayerEditingStyle)editingStyle;
- (void)removeEditingStyle:(PCLayerEditingStyle)editingStyle;

- (CGImageRef)newImageFromLayer;

- (void)setTitle:(NSString*)title;
- (NSString*)title;
- (CGRect)titleRect;
- (PCFont*)titleFont;

//tracking 
#if !TARGET_OS_IPHONE
- (NSArray*)trackingAreasInView:(NSView*)view;
#endif

//group drawing
- (void)removeAllGroupTiles;
- (void)setGroupTileImage:(CGImageRef)image atIndex:(NSInteger)index;
- (CGRect)tileRectForItemAtIndex:(NSInteger)index;
- (NSUInteger)numberOfGroupTiles;

- (void)restartAnimation;	// for sublcasses to override - should restart any layer animations the subclass has

@end


@protocol PCLayerCellProtocol <NSObject>

- (void)layerCell:(PCGridViewLayerCell*)cellLayer highlighted:(BOOL)highlighted part:(PCLayerCellPart)part;
- (BOOL)layerCell:(PCGridViewLayerCell*)cellLayer upEvent:(PCEvent*)event part:(PCLayerCellPart)part;

@end


