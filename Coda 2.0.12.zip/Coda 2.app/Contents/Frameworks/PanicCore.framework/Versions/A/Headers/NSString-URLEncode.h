#include <Foundation/Foundation.h>

@interface NSString (PCURLEncode)

+ (NSString*)pc_stringByDecodingURL:(NSString*)inStr withEncoding:(NSStringEncoding)encoding;
+ (NSString*)pc_stringByDecodingURL:(NSString*)inStr;
+ (NSString*)pc_stringByEncodingURL:(NSString*)inStr withEncoding:(NSStringEncoding)encoding;
+ (NSString*)pc_stringByEncodingURL:(NSString*)inStr;

- (NSString*)pc_stringByDecodingURLUsingEncoding:(NSStringEncoding)encoding;
- (NSString*)pc_stringByDecodingURL;
- (NSString*)pc_stringByEncodingURLUsingEncoding:(NSStringEncoding)encoding;
- (NSString*)pc_stringByEncodingURL;

// Encodes characters that would otherwise be read as GET arguments: ?, +, &, =
+ (NSString*)pc_stringByEncodingPathURL:(NSString*)inStr;

@end
