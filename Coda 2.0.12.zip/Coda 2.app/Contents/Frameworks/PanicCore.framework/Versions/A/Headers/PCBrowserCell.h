#import <Cocoa/Cocoa.h>

@interface PCBrowserCell : NSBrowserCell 
{
	IconRef		iIconRef;
    NSImage*	iImage;
	NSColor*	iLabelColor;
	NSSize		iImageSize;
	NSColor*	iTextColor;
	
	BOOL iHighlightedForDrop;
	BOOL iSelectExtensionWhenEditing;
}

@property(nonatomic, retain) NSImage* icon;
@property(nonatomic, retain) NSColor* labelColor;
@property(getter=isHighlightedForDrop) BOOL highlightedForDrop;
@property BOOL selectExtensionWhenEditing;
@property NSSize imageSize;
@property(nonatomic, retain) NSColor* textColor;

- (void)beginEditingInRect:(NSRect)aRect withEditor:(NSText*)fieldEditor inView:(NSView*)controlView;
- (void)endEditing:(NSText*)fieldEditor;

- (NSSize)cellSize;
- (void)drawInteriorWithFrame:(NSRect)cellFrame inView:(NSView*)controlView isDragging:(BOOL)isDragging;
- (NSRect)usedTextFrameForBounds:(NSRect)aRect;

- (void)setIconRef:(IconRef)aRef;

// private

- (void)titleRect:(NSRect*)outTitleRect usedRect:(NSRect*)outUsedRect forBounds:(NSRect)aRect;

@end


@interface NSBrowserCell (PrivateDeclarations)

- (void)_drawHighlightWithFrame:(NSRect)cellFrame inView:(NSView*)controlView;

@end
