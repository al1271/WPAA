//
//  PCDocumentInformation.h
//  PanicCore
//
//  Created by Garrett Moon on 12/22/10.
//  Copyright 2010 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PCDocumentInformation : NSObject
{
	NSMutableDictionary *typeInfo;
	NSMutableDictionary *overriddenIcons;
}

+ (void)addIcons:(NSArray *)iconArray forExtension:(NSString *)extension;
+ (NSString *)utiForExtension:(NSString *)extension;
+ (BOOL)isSupportedImageForExtension:(NSString *)extension;
+ (NSArray *)iconsForExtension:(NSString *)extension;
+ (NSString *)createDocumentForExtension:(NSString *)extension;

@end

#endif