//
//  PCBundle.h
//  PanicCore
//
//  Created by Logan Collins on 5/10/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


/*!
 * @class PCBundle
 * @abstract A thread-safe wrapper around CFBundleRef
 */
@interface PCBundle : NSObject {
	CFBundleRef _bundle;
}

/*!
 * @method allBundles
 * @abstract Gets the main bundle and all bundles that have been dynamically loaded
 * 
 * @result An NSArray of PCBundle objects
 */
+ (NSArray *)allBundles;

/*!
 * @method mainBundle
 * @abstract Gets the bundle representing the current application
 * 
 * @result A PCBundle object
 */
+ (PCBundle *)mainBundle;

/*!
 * @method bundleWithIdentifier:
 * @abstract Gets the bundle with a specified identifier
 * 
 * @param identifier
 * The identifier of the bundle
 * 
 * @discussion
 * The bundle must have previously been loaded by URL or path
 * 
 * @result A PCBundle object, or nil
 */
+ (PCBundle *)bundleWithIdentifier:(NSString *)identifier;

/*!
 * @method bundleWithURL:
 * @abstract Gets the bundle at a specified URL
 * 
 * @param aURL
 * The URL of the bundle
 * 
 * @discussion
 * If no loadable bundle exists at aURL, this method returns nil.
 * 
 * If the bundle has already been created for aURL, that instance is
 * returned.
 * 
 * @result A PCBundle object, or nil
 */
+ (PCBundle *)bundleWithURL:(NSURL *)aURL;

/*!
 * @method bundleWithPath:
 * @abstract Gets the bundle at a specified path
 * 
 * @param aPath
 * The path of the bundle
 * 
 * @discussion
 * If no loadable bundle exists at aPath, this method returns nil.
 * 
 * If the bundle has already been created for aPath, that instance is
 * returned.
 * 
 * @result A PCBundle object, or nil
 */
+ (PCBundle *)bundleWithPath:(NSString *)aPath;

/*!
 * @method initWithURL:
 * @abstract Gets the bundle at a specified URL
 * 
 * @param aURL
 * The URL of the bundle
 * 
 * @discussion
 * If no loadable bundle exists at aURL, this method returns nil.
 * 
 * If the bundle has already been created for aURL, that instance is
 * returned.
 * 
 * @result A PCBundle object, or nil
 */
- (id)initWithURL:(NSURL *)aURL;

/*!
 * @method initWithPath:
 * @abstract Gets the bundle at a specified path
 * 
 * @param aPath
 * The path of the bundle
 * 
 * @discussion
 * If no loadable bundle exists at aPath, this method returns nil.
 * 
 * If the bundle has already been created for aPath, that instance is
 * returned.
 * 
 * @result A PCBundle object, or nil
 */
- (id)initWithPath:(NSString *)aPath;


/*!
 * @property bundleIdentifier
 * @abstract The unique identifier for the bundle
 * 
 * @result An NSString object
 */
@property (copy, readonly) NSString *bundleIdentifier;

/*!
 * @property bundleURL
 * @abstract The URL of the bundle on disk
 * 
 * @result An NSURL object
 */
@property (copy, readonly) NSURL *bundleURL;

/*!
 * @property bundlePath
 * @abstract The path of the bundle on disk
 * 
 * @result An NSString object
 */
@property (copy, readonly) NSString *bundlePath;


/*!
 * @property principalClass
 * @abstract The principal class of the bundle
 * 
 * @discussion
 * The principal class is determined by the value of the NSPrincipalClass key
 * in the bundle's info dictionary.
 * 
 * @result A Class object, or Nil
 */
@property (readonly) Class principalClass;


/*!
 * @property infoDictionary
 * @abstract The (unlocalized) info dictionary
 * 
 * @result An NSDictionary object
 */
@property (copy, readonly) NSDictionary *infoDictionary;

/*!
 * @property localizedInfoDictionary
 * @abstract The localized info dictionary
 * 
 * @result An NSDictionary object
 */
@property (copy, readonly) NSDictionary *localizedInfoDictionary;

/*!
 * @method objectForInfoDictionaryKey:
 * @abstract Gets the (localized, when possible) value of an info dictionary key
 * 
 * @param key
 * The info dictionary key for which to search
 * 
 * @result An object, or nil
 */
- (id)objectForInfoDictionaryKey:(NSString *)key;


/*!
 * @property loaded
 * @abstract Whether the bundle's code has been dynamically loaded
 * 
 * @result A BOOL value
 */
@property (readonly, getter=isLoaded) BOOL loaded;

/*!
 * @method preflightAndReturnError:
 * @abstract Whether the bundle's code could be loaded successfully
 * 
 * @param outError
 * On output, a pointer to an NSError object generated if the code could not be loaded
 * 
 * @discussion
 * This method does not actually load the bundle’s executable code.
 * 
 * @result A BOOL value
 */
- (BOOL)preflightAndReturnError:(NSError **)outError;

/*!
 * @method load
 * @abstract Attempts to load the bundle's code
 * 
 * @result A BOOL value
 */
- (BOOL)load;

/*!
 * @method load
 * @abstract Attempts to load the bundle's code
 * 
 * @param outError
 * On output, a pointer to an NSError object generated if the code could not be loaded
 * 
 * @result A BOOL value
 */
- (BOOL)loadAndReturnError:(NSError **)outError;

/*!
 * @method unload
 * @abstract Attempts to unload the bundle's code
 * 
 * @result A BOOL value
 */
- (BOOL)unload;


/*!
 * @property executableURL
 * @abstract The URL of the bundle's executable file
 * 
 * @result An NSURL object, or nil
 */
@property (copy, readonly) NSURL *executableURL;

/*!
 * @property executablePath
 * @abstract The path of the bundle's executable file
 * 
 * @result An NSString object, or nil
 */
@property (copy, readonly) NSString *executablePath;

/*!
 * @property executableArchitectures
 * @abstract An array of numbers indicating the architecture types supported by the bundle’s executable
 * 
 * @result An NSArray of NSNumber objects, or nil
 */
@property (copy, readonly) NSArray *executableArchitectures;

/*!
 * @method URLForAxuiliaryExecutable:
 * @abstract Gets the URL for an auxiliary executable in the bundle
 * 
 * @param executableName
 * The name of the executable
 * 
 * @result An NSURL object
 */
- (NSURL *)URLForAuxiliaryExecutable:(NSString *)executableName;

/*!
 * @method pathForAxuiliaryExecutable:
 * @abstract Gets the path for an auxiliary executable in the bundle
 * 
 * @param executableName
 * The name of the executable
 * 
 * @result An NSString object
 */
- (NSString *)pathForAuxiliaryExecutable:(NSString *)executableName;


/*!
 * @property resourceURL
 * @abstract The URL of the bundle's resource directory
 * 
 * @result An NSURL object
 */
@property (copy, readonly) NSURL *resourceURL;

/*!
 * @property resourcePath
 * @abstract The path of the bundle's resource directory
 * 
 * @result An NSString object
 */
@property (copy, readonly) NSString *resourcePath;

/*!
 * @method URLForResource:withExtension:
 * @abstract Gets the URL for a bundle resource
 * 
 * @param name
 * The name of the resource
 * 
 * @param extension
 * The file extension of the resource
 * 
 * @result An NSURL object
 */
- (NSURL *)URLForResource:(NSString *)name withExtension:(NSString *)extension;

/*!
 * @method URLForResource:withExtension:subdirectory:
 * @abstract Gets the URL for a bundle resource located within a bundle subdirectory
 * 
 * @param name
 * The name of the resource
 * 
 * @param extension
 * The file extension of the resource
 * 
 * @param subdirectory
 * The bundle subdirectory to search
 * 
 * @result An NSURL object
 */
- (NSURL *)URLForResource:(NSString *)name withExtension:(NSString *)extension subdirectory:(NSString *)subpath;

/*!
 * @method URLForResource:withExtension:subdirectory:localization:
 * @abstract Gets the URL for a bundle resource located within a bundle subdirectory and localization
 * 
 * @param name
 * The name of the resource
 * 
 * @param extension
 * The file extension of the resource
 * 
 * @param subdirectory
 * The bundle subdirectory to search
 * 
 * @param localization
 * The bundle localization to search
 * 
 * @result An NSURL object
 */
- (NSURL *)URLForResource:(NSString *)name withExtension:(NSString *)extension subdirectory:(NSString *)subpath localization:(NSString *)localizationName;

/*!
 * @method pathForResource:ofType:
 * @abstract Gets the URL for a bundle resource
 * 
 * @param name
 * The name of the resource
 * 
 * @param extension
 * The file extension of the resource
 * 
 * @result An NSString object
 */
- (NSString *)pathForResource:(NSString *)name ofType:(NSString *)extension;

/*!
 * @method pathForResource:ofType:inDirectory:
 * @abstract Gets the URL for a bundle resource located within a bundle subdirectory
 * 
 * @param name
 * The name of the resource
 * 
 * @param extension
 * The file extension of the resource
 * 
 * @param subdirectory
 * The bundle subdirectory to search
 * 
 * @result An NSString object
 */
- (NSString *)pathForResource:(NSString *)name ofType:(NSString *)extension inDirectory:(NSString *)subpath;

/*!
 * @method pathForResource:ofType:inDirectory:forLocalization:
 * @abstract Gets the URL for a bundle resource located within a bundle subdirectory and localization
 * 
 * @param name
 * The name of the resource
 * 
 * @param extension
 * The file extension of the resource
 * 
 * @param subdirectory
 * The bundle subdirectory to search
 * 
 * @param localization
 * The bundle localization to search
 * 
 * @result An NSString object
 */
- (NSString *)pathForResource:(NSString *)name ofType:(NSString *)extension inDirectory:(NSString *)subpath forLocalization:(NSString *)localizationName;


/*!
 * @property localizations
 * @abstract A list of all the localizations contained within the receiver's bundle
 * 
 * @result An NSArray of NSString objects
 */
@property (copy, readonly) NSArray *localizations;

/*!
 * @property preferredLocalizations
 * @abstract A list of the preferred localizations contained within the receiver's bundle
 * 
 * @result An NSArray of NSString objects
 */
@property (copy, readonly) NSArray *preferredLocalizations;

/*!
 * @property developmentLocalization
 * @abstract The localization used to create the bundle
 * 
 * @discussion
 * The localization corresponds to the value of the CFBundleDevelopmentRegion key in the bundle's info dictionary.
 * 
 * @result An NSString object, or nil
 */
@property (copy, readonly) NSArray *developmentLocalization;

/*!
 * @method localizedStringForKey:value:table:
 * @abstract Gets the localized string for a given key, value and table
 * 
 * @param key
 * The localization key
 * 
 * @param value
 * The value of the localized key
 * 
 * @param tableName
 * The localization table to search
 * 
 * @result An NSString object
 */
- (NSString *)localizedStringForKey:(NSString *)key value:(NSString *)value table:(NSString *)tableName;

@end
