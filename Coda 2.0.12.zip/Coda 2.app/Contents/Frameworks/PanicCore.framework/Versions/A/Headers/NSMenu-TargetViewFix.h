#import <Cocoa/Cocoa.h>


@interface NSMenu (PCTargetViewFix)

+ (void)pc_installTargetViewFix;

@end


@interface PCPopUpMenuFixListener : NSObject
{
	NSMenu *iMenu;
	NSView *iView;
}

@property (nonatomic, retain) NSMenu *menu;
@property (nonatomic, retain) NSView *view;

- (void)menuDidEndTrackingNotification:(NSNotification*)notification;

@end