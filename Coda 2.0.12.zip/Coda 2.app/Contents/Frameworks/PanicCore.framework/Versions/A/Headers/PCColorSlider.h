//
//  PCColorSlider.h
//  ColorSlider
//
//  Created by Wade Cosgrove on 8/12/10.
//  Copyright 2010 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef enum
{
	kColorDisplayModeGeneric = 0,
	kColorDisplayModeRed,
	kColorDisplayModeGreen,
	kColorDisplayModeBlue,
	kColorDisplayModeHue,
	kColorDisplayModeSaturation,
	kColorDisplayModeBrightness,
} PCColorSliderDisplayMode;


@interface PCColorSlider : NSSlider 
{
}

@property (readwrite, retain) NSColor *color;
@property (assign) PCColorSliderDisplayMode displayMode;

@end


@interface PCColorSliderCell : NSSliderCell 
{
	PCColorSliderDisplayMode iDisplayMode;
	NSGradient *iTrackGradient;
	NSColor *iColor;
	NSString *iColorSpaceName;
}

@property (readwrite, retain) NSColor *color;
@property (nonatomic, assign) PCColorSliderDisplayMode displayMode;
@property (readwrite, retain) NSString *colorSpaceName;

- (void)setGenericStartColor:(NSColor*)startColor endColor:(NSColor*)endColor;
- (void)setColor:(NSColor*)color updateValue:(BOOL)flag;

@end


@interface PCColorStorage : NSObject
{
	CGFloat iComponent1; //r-h
	CGFloat iComponent2; //g-s
	CGFloat iComponent3; //b-b
	CGFloat iAlpha;
	
	BOOL 	isRGB; // NO is HSB
	BOOL 	iCalibratedColor;
}

- (id)initWithColor:(NSColor*)color isRGB:(BOOL)isRGB;

@property (readwrite, assign, getter=isCalibratedColor) BOOL calibratedColor;
@property (readwrite, assign) BOOL isRGB;
@property (readwrite, assign) NSColor* color;
@property (nonatomic, readwrite, assign) CGFloat component1;
@property (nonatomic, readwrite, assign) CGFloat component2;
@property (nonatomic, readwrite, assign) CGFloat component3;
@property (nonatomic, readwrite, assign) CGFloat alpha;

@end

void ConfigureBindingsForColorStorage(PCColorStorage* storage, NSColorWell *colorWell, PCColorSlider *slider1 /*r-h*/, PCColorSlider *slider2 /*g-s*/, PCColorSlider *slider3 /*b-b*/);
