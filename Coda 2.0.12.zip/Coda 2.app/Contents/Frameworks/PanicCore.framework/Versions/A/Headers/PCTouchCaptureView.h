//
//  PCTouchCaptureView.h
//  PanicCore
//
//  Created by Garrett Moon on 1/28/11.
//  Copyright 2011 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PCTouchCaptureView : UIControl {
	UIView *iPassThroughView;
	id delegate;
	BOOL iShouldPassOutsideEventThrough;
}

@property (nonatomic, assign) UIView *passThroughView;
@property (assign) id delegate;

+ (id)sharedTouchCaptureView;

@end

@interface NSObject (PCTouchCaptureViewDelegate)

- (BOOL)touchCaptureViewTapped:(PCTouchCaptureView *)touchCaptureView; //return YES to block passthrough

@end

#endif
