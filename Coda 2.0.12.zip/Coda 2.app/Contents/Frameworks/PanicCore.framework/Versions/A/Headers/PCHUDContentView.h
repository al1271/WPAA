#import <Cocoa/Cocoa.h>


@interface PCHUDContentView : NSView
{
	CGFloat			iFooterHeight;
	NSSize			iCachedContentSize;
	NSBezierPath	*iContentPath;

	NSColor			*iContentColor;	
}

@property (nonatomic, retain) NSColor* contentColor;

@end
