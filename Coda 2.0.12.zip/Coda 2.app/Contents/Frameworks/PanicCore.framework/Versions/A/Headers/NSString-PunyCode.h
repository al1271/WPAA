#import <Foundation/Foundation.h>


@interface NSString (PCPunyCode)

// returns self if conversion fails or no encoding is needed
- (NSString*)pc_punyCode;

@end
