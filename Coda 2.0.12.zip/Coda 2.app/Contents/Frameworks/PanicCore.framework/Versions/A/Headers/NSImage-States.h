#import <AppKit/AppKit.h>


@interface NSImage (PCStates)

- (NSImage*)pc_disabledImage;
- (NSImage*)pc_pressedImage;
- (NSImage*)pc_selectedImage;
- (NSImage*)pc_selectedImageLighter;

- (NSImage*)pc_darkenImageWithAlpha:(CGFloat)alpha;
- (NSImage*)pc_lightenImageWithAlpha:(CGFloat)alpha;

@end
