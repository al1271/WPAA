#import <Cocoa/Cocoa.h>


@interface NSEvent (PCWindowForwarding)

- (NSEvent*)pc_convertMouseEventToWindow:(NSWindow*)aWindow;
- (NSPoint)pc_convertMouseEventLocationToWindow:(NSWindow*)window;

@end
