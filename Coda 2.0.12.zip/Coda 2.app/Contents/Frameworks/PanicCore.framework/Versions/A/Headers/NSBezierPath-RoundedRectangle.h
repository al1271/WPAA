
#if !TARGET_OS_IPHONE
#import <Cocoa/Cocoa.h>

@interface NSBezierPath (RoundedRectangle)

+ (id)pc_roundedRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its top corners rounded, bottom are square
+ (id)pc_roundedTopRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its bottom corners rounded, top are square
+ (id)pc_roundedBottomRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its left corners rounded, top are square
+ (id)pc_roundedLeftRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its right corners rounded, top are square
+ (id)pc_roundedRightRectangleWithRect:(NSRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

+ (id)pc_roundedCapOnEdge:(CGRectEdge)edge withRect:(NSRect)rect lineWidth:(CGFloat)lineWidth;

// draws rounded ends with radius half of rect's height
+ (id)pc_capsuleWithRect:(NSRect)rect lineWidth:(CGFloat)lineWidth;

@end

#endif

#import <PanicCore/CKBezierPath.h>

@interface CKBezierPath (CKRoundedRectangle)

+ (id)pc_roundedRectangleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its top corners rounded, bottom are square
+ (id)pc_roundedTopRectangleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

// a rectangle with its bottom corners rounded, top are square
+ (id)pc_roundedBottomRectangleWithRect:(CGRect)aRect cornerRadius:(CGFloat)cornerRadius lineWidth:(CGFloat)lineWidth;

@end