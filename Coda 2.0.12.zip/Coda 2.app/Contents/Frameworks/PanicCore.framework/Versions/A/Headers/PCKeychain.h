/*
 *  PCKeychain
 *
 *  Requires Mac OS X 10.2 or higher and linking to Security.framework.
 *
 *	-------------------------------------------------------------------
 */

#import <Foundation/Foundation.h>
#import <Security/Security.h>

@class PCPrivateKey;
@class PCTrust;

extern NSString* const kPasswordInKeychain;

//  PCKeychain* matching keys
extern NSString* const kPCKeychainService;  // NSString
extern NSString* const kPCKeychainUsername; // NSString
extern NSString* const kPCKeychainServer;   // NSString
extern NSString* const kPCKeychainPort;     // NSNumber (unsigned int)		
extern NSString* const kPCKeychainProtocol; // NSNumber (SecProtocolType, which is a FourCharCode which is an unsigned int)


@interface PCKeychain : NSObject
{
	__strong CFTypeRef iRef;
}

+ (PCKeychain*)defaultKeychain; // actually the user's default keychain search list

- (id)initWithKeychainOrArray:(CFTypeRef)keychainOrArray;

// Supply a dictionary with the PCKeychain* matching keys you wish to match against. Returns NSArray of PCKeychainItem.
#if ! TARGET_OS_IPHONE

- (NSArray*)internetPasswordItemsMatchingAttributes:(NSDictionary*)matchingAttributes;

- (NSArray*)privateKeys; // NSArray of PCPrivateKey

- (BOOL)savePassword:(NSString*)password forAccountName:(NSString*)accountName service:(NSString*)service error:(NSError**)outError;

- (PCPrivateKey*)importPrivateKey:(NSData*)externalRepresentation withUsername:(NSString*)username serverAddress:(NSString*)serverAddress secProtocol:(SecProtocolType)protocol error:(NSError**)outError;
- (NSData*)exportPrivateKeyWithUsername:(NSString*)username serverAddress:(NSString*)serverAddress secProtocol:(SecProtocolType)protocol error:(NSError**)outError;

- (BOOL)addCertificate:(CFTypeRef)certificate error:(NSError**)outError; // accepts a SecCertificate or a PCCertificate

#endif

- (NSString*)passwordForAccountName:(NSString*)accountName service:(NSString*)service error:(NSError**)outError;

#if TARGET_OS_IPHONE
- (NSString*)passwordForUsername:(NSString*)username serverAddress:(NSString*)serverAddress secProtocol:(CFTypeRef)protocol error:(NSError**)outError;
#else
- (NSString*)passwordForUsername:(NSString*)username serverAddress:(NSString*)serverAddress secProtocol:(SecProtocolType)protocol error:(NSError**)outError;
#endif

#if TARGET_OS_IPHONE
- (BOOL)savePassword:(NSString*)password forUsername:(NSString*)username serverAddress:(NSString*)serverAddress secProtocol:(CFTypeRef)protocol error:(NSError**)outError;
#else
- (BOOL)savePassword:(NSString*)password forUsername:(NSString*)username serverAddress:(NSString*)serverAddress secProtocol:(SecProtocolType)protocol error:(NSError**)outError;
#endif

@end

#if ! TARGET_OS_IPHONE
@interface PCKeychainItem : NSObject
{
@private
	__strong SecKeychainItemRef iRef;
}

@property(nonatomic, copy) NSData* itemData;
@property(nonatomic, copy) NSString* address;
@property(nonatomic, copy) NSString* username;
@property(nonatomic, copy) NSString* password; // itemData interpreted as UTF-8
@property(nonatomic, retain) NSNumber* port;
@property(nonatomic) SecProtocolType secProtocol;

- (id)initWithSecKeychainItem:(SecKeychainItemRef)item;

- (NSString*)description;

- (SecKeychainItemRef)secKeychainItem;

- (BOOL)setPassword:(NSString*)password error:(NSError**)outError;

@end


@interface PCPrivateKey : PCKeychainItem
{
}

@property(nonatomic, copy) NSString* comments; // kSecKeyApplicationTag
@property(nonatomic, copy) NSString* name; // kSecKeyPrintName

- (id)initWithSecKey:(SecKeyRef)key;
- (id)initWithKeyData:(NSData*)data forKeychain:(PCKeychain*)keychain alertPrompt:(NSString*)alertPrompt error:(NSError**)outError;

- (NSData*)keyData:(NSError**)outError;

- (SecKeyRef)secKey;

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"

- (const CSSM_KEY*)cssmKey;

#pragma GCC diagnostic pop

- (CSSM_CSP_HANDLE)cspHandle;
- (CSSM_KEYATTR_FLAGS)keyAttributes;
- (NSData*)keyDigest; // NSData of CSSM_APPLECSP_KEYDIGEST

@end

#endif
