//
//  PCAppearance.h
//  PanicCore
//
//  Created by Logan Collins on 3/23/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PanicCore/PanicCoreDefines.h>


#if TARGET_OS_IPHONE

#import <UIKit/UIGeometry.h>

typedef UIEdgeInsets PCEdgeInsets;

#elif TARGET_OS_MAC

typedef struct PCEdgeInsets {
    CGFloat top, left, bottom, right;
} PCEdgeInsets;

#endif


PANICCORE_INLINE PCEdgeInsets PCEdgeInsetsMake(CGFloat top, CGFloat left, CGFloat bottom, CGFloat right) {
#if TARGET_OS_IPHONE
    return UIEdgeInsetsMake(top, left, bottom, right);
#elif TARGET_OS_MAC
    PCEdgeInsets insets = {top, left, bottom, right};
    return insets;
#endif
}


PANICCORE_INLINE BOOL PCEdgeInsetsEqualToEdgeInsets(PCEdgeInsets insets1, PCEdgeInsets insets2) {
#if TARGET_OS_IPHONE
    return UIEdgeInsetsEqualToEdgeInsets((UIEdgeInsets)insets1, (UIEdgeInsets)insets2);
#elif TARGET_OS_MAC
    return (insets1.top == insets2.top) && (insets1.left == insets2.left) && (insets1.bottom == insets2.bottom) && (insets1.right == insets2.right);
#endif
}


PANICCORE_EXTERN const PCEdgeInsets PCEdgeInsetsZero;
