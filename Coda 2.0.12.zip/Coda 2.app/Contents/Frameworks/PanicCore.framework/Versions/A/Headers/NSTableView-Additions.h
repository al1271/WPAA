#import <Cocoa/Cocoa.h>


@interface NSTableView (Additions)

+ (NSGradient*)sourceListBackgroundGradient;
+ (NSGradient*)sourceListBackgroundInactiveGradient;
+ (NSGradient*)sourceListHighlightedRowGradient;
+ (NSGradient*)sourceListHighlightedInactiveRowGradient;

+ (NSGradient*)appearanceListHighlightedRowGradient;
+ (NSGradient*)appearanceListHighlightedNonKeyRowGradient;
+ (NSGradient*)appearanceListHighlightedInactiveRowGradient;

- (NSGradient*)pc_SelectedRowGradient;
- (BOOL)pc_isBackgroundBlue;

+ (NSColor*)sourceListBackgroundStartColor;
+ (NSColor*)sourceListBackgroundEndColor;
+ (NSColor*)sourceListBackgroundInactiveStartColor;
+ (NSColor*)sourceListBackgroundInactiveEndColor;

@end


@interface NSView (SourceListSelectionDrawing)

- (void)pc_drawSourceListHighlightInRect:(NSRect)rect;
- (void)pc_drawSourceListRoundedHightlightInRect:(NSRect)rect cornerRadius:(CGFloat)radius;

- (NSGradient*)pc_SelectedRowGradientWithHighlightStyle:(NSTableViewSelectionHighlightStyle)selectionStyle;

@end