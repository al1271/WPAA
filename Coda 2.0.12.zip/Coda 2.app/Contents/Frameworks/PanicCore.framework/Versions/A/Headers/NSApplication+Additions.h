//
//  NSApplication+Additions.h
//  PanicCore
//
//  Created by Wade Cosgrove on 11/27/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSApplication (Additions)

+ (BOOL)pc_isSandboxed;

@end
