#import <Cocoa/Cocoa.h>


@interface NSBitmapImageRep (ImageRefAddition)

// returns an autoreleased CGImage that can live longer than the NSBitmapImageRep, unlike -[NSBitmapImageRep CGImage]
- (CGImageRef)pc_CGImage;

+ (NSBitmapImageRep*)bitmapImageRepWithPixelSize:(NSSize)pixelSize;

@end


@interface NSView (ImageRefAddition)

- (CGImageRef)pc_CGImage;
- (CGImageRef)pc_CGImageFromRect:(NSRect)viewRect;

@end


@interface CIImage (ImageRefAddition)

- (CGImageRef)pc_CGImage;

@end
