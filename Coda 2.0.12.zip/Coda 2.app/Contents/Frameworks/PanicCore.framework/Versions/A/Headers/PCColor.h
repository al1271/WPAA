#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@interface PCColor : NSObject 
{
#if TARGET_OS_IPHONE
	UIColor *iColor;
#else
	NSColor *iColor;
#endif
}

#if TARGET_OS_IPHONE
@property (readonly) UIColor *platformColor;
#else
@property (readonly) NSColor *platformColor;
#endif

@property (nonatomic, readonly) CGFloat hue;
@property (nonatomic, readonly) CGFloat saturation;
@property (nonatomic, readonly) CGFloat brightness;
@property (nonatomic, readonly) CGFloat red;
@property (nonatomic, readonly) CGFloat green;
@property (nonatomic, readonly) CGFloat blue;

+ (PCColor*)colorWithHue:(CGFloat)hue saturation:(CGFloat)saturation brightness:(CGFloat)brightness alpha:(CGFloat)alpha;
+ (PCColor*)colorWithRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue alpha:(CGFloat)alpha;
+ (PCColor*)colorWithWhite:(CGFloat)white alpha:(CGFloat)alpha;
+ (PCColor*)colorWithCGColor:(CGColorRef)colorRef;
+ (PCColor*)whiteColor;
+ (PCColor*)blackColor;
+ (PCColor*)clearColor;

- (CGColorRef)CGColor;
- (CGColorRef)CGColorWithAlphaComponent:(CGFloat)newAlpha;
- (CGFloat)alpha;
- (CGFloat)hue;
- (CGFloat)saturation;
- (CGFloat)brightness;
- (CGFloat)red;
- (CGFloat)green;
- (CGFloat)blue;

- (void)set;

@end
