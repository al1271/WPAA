#import <Cocoa/Cocoa.h>

@interface PCGlossButtonCell : NSButtonCell
{
@private
	NSImage *backgroundImage;
	NSImage *backgroundImagePressed;
}

- (void)updateBackgroundForSize:(NSSize)size;	

@end


@interface PCGlossButton : NSButton
{
}


+ (PCGlossButton*)addButton;
+ (PCGlossButton*)minusButton;

- (void)configure;
- (void)setToggles:(BOOL)flag;

- (void)setTemplateImage:(NSImage*)anImage;
- (void)setTemplateImage:(NSImage*)anImage toggle:(BOOL)flag;

@end
