//
//  XPIconImageRep.h
//  Copyright (c) 2004 The Iconfactory. All rights reserved.
//
//  Based on DRXPIconImageRep.h by David Remahl
//  Copyright (c) 2001 Infinity-to-the-Power-of-Infinity. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define XPIconImageDepth @"XPIconImageDepth"

@interface XPIconImageRep : NSCustomImageRep
{

}

@end
