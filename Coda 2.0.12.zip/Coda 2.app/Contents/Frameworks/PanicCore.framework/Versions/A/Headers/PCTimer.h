#import <Foundation/Foundation.h>

@interface PCTimer : NSObject
{
@private
	CFRunLoopTimerRef iTimer;
	NSInvocation* iTargetInvocation;
	id iUserInfo;
	
	NSTimeInterval iDeferThreshhold;
	NSDate*	iDeferStartDate;
}

@property(readonly, retain) id userInfo;
@property(assign) NSTimeInterval deferThreshold;

// Note: This timer does not retain its target

- (void)addTimerToRunLoop;
- (void)addTimerToRunLoopForMode:(CFStringRef)mode; // Uses CFRunLoopModes
- (void)addTimerToRunLoop:(NSRunLoop*)runLoop forMode:(CFStringRef)mode;

+ (PCTimer*)scheduledTimerWithTimeInterval:(NSTimeInterval)seconds invocation:(NSInvocation *)invocation repeats:(BOOL)repeats;
+ (PCTimer*)scheduledTimerWithTimeInterval:(NSTimeInterval)seconds target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats;
+ (PCTimer*)scheduledTolerantTimerWithTimeInterval:(NSTimeInterval)seconds target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats;
+ (PCTimer*)timerWithTimeInterval:(NSTimeInterval)seconds invocation:(NSInvocation *)invocation repeats:(BOOL)repeats;
+ (PCTimer*)timerWithTimeInterval:(NSTimeInterval)seconds target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats;

- (id)initWithFireDate:(NSDate *)date interval:(NSTimeInterval)seconds target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats;
- (id)initTolerantWithFireDate:(NSDate *)date interval:(NSTimeInterval)seconds target:(id)target selector:(SEL)selector userInfo:(id)userInfo repeats:(BOOL)repeats;

- (BOOL)isValid;
- (void)invalidate;

- (void)fire;
- (NSDate*)fireDate;
- (void)setFireDate:(NSDate*)date;

- (NSTimeInterval)timeInterval;

- (void)setDefaultTolerance;
- (void)setTolerance:(NSTimeInterval)tolerance;
- (NSTimeInterval)tolerance;

@end
