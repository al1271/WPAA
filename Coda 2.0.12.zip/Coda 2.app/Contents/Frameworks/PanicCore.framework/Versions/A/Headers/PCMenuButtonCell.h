//
//  PCMenuButtonCell.h
//  PanicCore
//
//  Created by Logan Collins on 3/12/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PCMenuButtonCell : NSButtonCell

@end
