//
//  NSObject-InterfaceValidationDispatch.h
//  PanicCore
//
//  Created by Ian Cely on 12/2/10.
//  Copyright 2010 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSObject (InterfaceValidationDispatch)

// This method calls back on - (BOOL)[self validateMenuItem[SelectorName]:(NSMenuItem*)menuItem]
- (BOOL)pc_dispatchValidationForMenuItem:(NSMenuItem*)menuItem;

@end
