#import <PanicCore/PCSlidingViewsBar.h>

#define PCTabBarDidChangeNotification		@"TabBarDidChangeNotification"

@protocol TabBarButtonProtocol
- (NSButton*)closeButton;
- (BOOL)isEdited;
- (void)setEdited:(BOOL)flag;
- (void)setSliding:(BOOL)flag;
- (BOOL)shouldHideCloseButton;
@end

@class PCColorView;
@class PCTabToolTip;


@interface PCTabBar : PCSlidingViewsBar
{
@private
	Class buttonClass;
	BOOL canCloseOnlyTab;
	BOOL autoHide;
	__weak NSView *contextualMenuButtonTarget;
	
	NSGradient *iBackgroundGradient;
	NSInteger iSelectedTabIndex;
	BOOL iShowsBaselineSeparator;
	
	// bubble tooltip
	
	PCTabToolTip *bubbleToolTip;
	NSInteger bubbleToolTipIndex;
	NSTimer *bubbleToolTipTimer;
	BOOL showBubbleToolTips;
	
	__weak NSToolbar *iObservingToolbar;
}

@property (retain) NSGradient* backgroundGradient;
@property NSInteger selectedTabIndex;
@property (nonatomic, assign) BOOL autoHides;
@property (assign) Class buttonClass;

- (void)addTabWithTitle:(NSString*)title;
- (void)addTabWithTitle:(NSString*)title atIndex:(NSInteger)tabIndex;
- (void)closeAllTabsExcludingTabAtIndex:(NSInteger)tabIndex;
- (void)moveTabFromIndex:(NSInteger)originalIndex toIndex:(NSInteger)targetIndex;
- (BOOL)closeTabAtIndex:(NSInteger)index; // will ask if closing is OK
- (void)removeTabAtIndex:(NSInteger)index; // removes tab immediately, without asking
- (void)selectTabAtIndex:(NSInteger)index;

- (NSInteger)numberOfTabs;
- (NSInteger)selectedTabIndex;

- (BOOL)isEditedForTabAtIndex:(NSInteger)index;

- (BOOL)canCloseOnlyTab;
- (void)setCanCloseOnlyTab:(BOOL)flag;

- (BOOL)isVisible;
- (void)setVisible:(BOOL)flag;

- (void)setShowsBaselineSeparator:(BOOL)flag;

- (void)reloadData;

- (NSRect)windowAutosaveFrame;
- (NSRect)usedRect; // frame plus the divider frame

- (void)setShowsBubbleToolTip:(BOOL)flag;

// layout

- (CGFloat)maxButtonWidth;
- (CGFloat)minButtonWidth;
- (CGFloat)minSelectedButtonWidth;

- (CGFloat)slidingWidthForView:(NSView*)aView;

// subclass hooks

- (void)configureTabButton:(NSButton*)aButton;
- (void)drawBackgroundInRect:(NSRect)aRect;
- (void)drawBaselineSeparatorInRect:(NSRect)aRect;

// private

- (void)closeBubbleToolTip;

@end


@protocol PCTabBarDelegate

@required
- (NSInteger)numberOfTabsInTabBar:(PCTabBar *)tabBar;
- (NSString*)tabBar:(PCTabBar *)bar titleForTabAtIndex:(NSInteger)index;

@optional
- (void)createNewTabForTabBar:(PCTabBar*)bar;
- (NSDragOperation)tabBar:(PCTabBar*)bar validateDrop:(id <NSDraggingInfo>)draggingInfo tabAtIndex:(NSInteger)index;
- (BOOL)tabBar:(PCTabBar*)bar acceptDrop:(id <NSDraggingInfo>)draggingInfo tabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar duplicateTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar closeOthersExceptTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar didCloseTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar didSwitchToTabAtIndex:(NSInteger)index;
- (BOOL)tabBar:(PCTabBar*)bar shouldCloseTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar willAddTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar willCloseTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar willSwitchToTabAtIndex:(NSInteger)index;
- (void)tabBar:(PCTabBar*)bar willLayoutTabButton:(NSButton*)aButton atIndex:(NSInteger)index;

- (NSMenu*)tabBar:(PCTabBar*)bar contextualMenuForTabAtIndex:(NSInteger)tabIndex defaultMenu:(NSMenu*)defaultMenu;
- (NSMenu*)tabBar:(PCTabBar*)bar popupMenuForTabAtIndex:(NSInteger)tabIndex;
- (void)tabBar:(PCTabBar*)bar willDisplayTabToolTip:(PCTabToolTip*)toolTip forTabAtIndex:(NSInteger)tabIndex;
- (BOOL)tabBar:(PCTabBar*)bar shouldDisplayTabToolTipAtIndex:(NSInteger)tabIndex;

@end

@interface PCTabBar (TabButtonSupport)

- (BOOL)acceptDrop:(id <NSDraggingInfo>)draggingInfo onTabButton:(id)sender;
- (void)selectTabButton:(id)sender;
- (void)closeTabButton:(id)sender;
- (NSMenu*)menuForTabButton:(id)sender;
- (void)mouseEnteredOrExited:(BOOL)didEnter tabButton:(id)sender;

@end

@interface PCTabBar (ContextualMenuSupport)

- (IBAction)duplicateTabContextualAction:(id)sender;
- (IBAction)closeTabContextualAction:(id)sender;
- (IBAction)closeOtherTabsContextualAction:(id)sender;
- (IBAction)newTabContextualAction:(id)sender;
- (IBAction)openTabInNewWindowContextualAction:(id)sender;

@end
