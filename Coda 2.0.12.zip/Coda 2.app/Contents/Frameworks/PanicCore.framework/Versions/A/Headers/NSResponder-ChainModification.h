#import <Cocoa/Cocoa.h>


@interface NSResponder (ChainModification)

- (void)pc_insertResponderChainIntoCurrentResponderChain:(NSResponder*)firstResponderOfNewChain;
- (NSString*)pc_responderChainDescription;

@end

#if defined(DEBUG)
@interface NSWindow (ResponderChainDebugging)

- (NSString*)pc_responderChainDescription;

@end
#endif
