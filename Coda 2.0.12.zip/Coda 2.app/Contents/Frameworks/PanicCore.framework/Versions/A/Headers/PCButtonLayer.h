#if TARGET_OS_IPHONE
	#import <Foundation/Foundation.h>
#else
	#import <Cocoa/Cocoa.h>
#endif
#import <QuartzCore/QuartzCore.h>

@class PCView;
@class PCEvent;
@class PCShadow;
@class PCFont;

@interface PCButtonLayer : CALayer
{
	CATextLayer *iTextLayer;
	CALayer 	*iImageLayer;
	
	CGImageRef 	iImage;
	CGImageRef	iAlternateImage;
		
#if TARGET_OS_IPHONE
	NSTimer		*iHoldTimer;
	BOOL		trackingTouches;
	BOOL		shouldCancelMouseUp;
#endif

	BOOL		iRolloverHighlighted;
	BOOL		iHighlighted;
	BOOL		iDropHighlighted;
	__weak NSObject	*iEventDelegate;
	NSObject 	*iRepresentedObject;
}

@property (nonatomic, assign, getter=isHighlighted) BOOL highlighted;
@property (nonatomic, assign, getter=isDropHighlighted) BOOL dropHighlighted;
@property (nonatomic, assign, getter=isRolloverHighlighted) BOOL rolloverHighlighted;
@property (nonatomic, assign) __weak NSObject *eventDelegate;
@property (retain) NSObject *representedObject;
@property (readonly) CGSize imageSize;
@property (readonly) CATextLayer *textLayer;
@property (readonly) CALayer *imageLayer;

- (void)setDisplayImage:(CGImageRef)image;

- (CGImageRef)alternateImage;
- (void)setAlternateImage:(CGImageRef)altImage;

- (CGImageRef)image;
- (void)setImage:(CGImageRef)image;

- (NSString*)title;
- (void)setTitle:(NSString*)title;

- (void)setTextShadow:(PCShadow*)shadow;
- (void)setFont:(PCFont*)font;

- (CGSize)layerSize; // minimum size to display the layer content (see NSCell cellSize)

- (void)setTruncationEnabled:(BOOL)flag;

#if TARGET_OS_IPHONE

- (void)touchesBegan:(NSSet *)touches withEvent:(PCEvent *)event inView:(PCView *)eventView;
- (void)touchesCancelled:(NSSet *)touches withEvent:(PCEvent *)event inView:(PCView *)eventView;
- (void)touchesMoved:(NSSet *)touches withEvent:(PCEvent *)event inView:(PCView *)eventView;
- (void)touchesEnded:(NSSet *)touches withEvent:(PCEvent *)event inView:(PCView *)eventView;

#else

- (void)trackMouseDownEvent:(NSEvent *)event inView:(PCView *)eventView;

- (void)addTrackingAreasForView:(PCView*)aView;
- (void)mouseEntered:(NSEvent*)event;
- (void)mouseExited:(NSEvent*)event;

#endif

- (void)titleRect:(CGRect*)titleRect imageRect:(CGRect*)imageRect forBounds:(CGRect)bounds;
- (CGFloat)bezelSpacing; // size between text/image and edge of button (default is 4.0)

@end


@interface NSObject (PCButtonLayerDelegate)

- (BOOL)buttonLayer:(PCButtonLayer*)layer mouseDragged:(PCEvent*)event; // return yes to begin drag
- (BOOL)buttonLayer:(PCButtonLayer*)layer mouseUp:(PCEvent*)event; // return YES to keep button highlighted
- (BOOL)mouseHeldInButtonLayer:(PCButtonLayer*)layer;
- (void)buttonLayer:(PCButtonLayer *)buttonLayer highlighted:(BOOL)highlighted;
- (void)buttonLayer:(PCButtonLayer *)buttonLayer dropHighlighted:(BOOL)highlighted;
#if !TARGET_OS_IPHONE
- (void)buttonLayer:(PCButtonLayer *)buttonLayer rolloverHighlighted:(BOOL)highlighted;
#endif
@end
