//
//  PCURLAuthenticator.h
//  PanicCore
//
//  Created by Garrett Moon on 8/26/11.
//  Copyright 2011 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>

@class PCAlert;

#if ! TARGET_OS_IPHONE
@interface PCURLAuthenticator : NSObject <NSAlertDelegate>
#else
@interface PCURLAuthenticator : NSObject
#endif
{
	id delegate;
	NSURLConnection *iConnection;
	NSURLAuthenticationChallenge *iChallenge;
	NSURL *iURL;
	PCAlert *iAlert;
}

@property (assign) id delegate;

- (void)authenticateURL:(NSURL *)url;
- (void)cancel;

@end

@interface NSObject (PCURLAuthenticatorDelegate)

- (void)authenticatedURL:(NSURL *)url;
- (void)authenticationFailedForURL:(NSURL *)url;

@end