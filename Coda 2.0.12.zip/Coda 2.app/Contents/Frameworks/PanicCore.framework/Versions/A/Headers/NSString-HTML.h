#import <Cocoa/Cocoa.h>


@interface NSString (HTML)

- (NSString*)pc_unicodeAsEntities;

- (NSString*)pc_absolutePathToRelativePath:(NSString*)relativePath;
- (NSString*)pc_relativePathToPath:(NSString*)targetPath;
- (BOOL)pc_isWebCompatibleImage;

@end
