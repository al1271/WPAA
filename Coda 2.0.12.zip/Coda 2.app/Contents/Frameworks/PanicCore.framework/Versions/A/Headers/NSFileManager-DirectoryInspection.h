#import <Foundation/Foundation.h>


@interface NSFileManager (PCDirectoryInspection)

- (unsigned long long)pc_sizeOfFolderContentsAtPath:(NSString*)path physicalSize:(unsigned long long*)outPhysicalSize;

#if !TARGET_OS_IPHONE

- (NSUInteger)pc_numberOfFilesAtPath:(NSString*)path;

- (NSArray*)pc_deepDirectoryContentsAtPath:(NSString*)path; // Calls pc_deepDirectoryContentsAtPath:path includeHidden:NO includeDirectories:YES conformsToUTI:nil

- (NSArray*)pc_deepDirectoryContentsAtPath:(NSString*)path 
						  includeHidden:(BOOL)includeHidden 		
					 includeDirectories:(BOOL)includeDirectories 	// If NO, then directories are not included in the ouput array
						  conformsToUTI:(NSString*)inUTI;

- (NSArray*)pc_deepDirectoryContentsAtPath:(NSString*)path 
						  includeHidden:(BOOL)includeHidden 		
					 includeDirectories:(BOOL)includeDirectories 	// If NO, then directories are not included in the ouput array
						  conformsToUTI:(NSString*)inUTI 			// Pass in nil to not filter based on file UTI
						  excludesFiles:(NSArray*)excludedFiles;

- (NSArray*)pc_deepDirectoryContentsAtPath:(NSString*)path
						  includeHidden:(BOOL)includeHidden 
					 includeDirectories:(BOOL)includeDirectories	// If NO, then directories are not included in the ouput array 
						  excludingUTIs:(NSArray*)inUTIs;			// Pass in nil to not filter based on file UTI

- (NSArray*)pc_deepDirectoryContentsAtPath:(NSString*)path
						  includeHidden:(BOOL)includeHidden 
					 includeDirectories:(BOOL)includeDirectories	
						  excludingUTIs:(NSArray*)inUTIs			
						  excludesFiles:(NSArray*)excludedFiles;

- (NSArray*)pc_deepDirectoryContentsAtPath:(NSString*)path 
                             includeHidden:(BOOL)includeHidden 
                        includeDirectories:(BOOL)includeDirectories // If NO, then directories are not included in the ouput array 
                             excludingUTIs:(NSArray*)excludedUTIs // Pass in nil to not filter based on file UTI
                             excludesFiles:(NSArray*)excludedFiles 
                             includingUTIs:(NSArray*)includedUTIs; //Force a UTI to be included in search results


- (BOOL)pc_removeDirectoryContentsAtPath:(NSString*)path error:(NSError**)error;

#endif

@end
