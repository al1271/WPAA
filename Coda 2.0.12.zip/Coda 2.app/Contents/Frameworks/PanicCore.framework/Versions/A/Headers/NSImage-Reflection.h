/*
 *  NSImage-Reflection.h
 *
 *  Requires Mac OS X 10.5 or higher
 *
 *	Provides a reflected image of the provided image.
 *
 *	-------------------------------------------------------------------
 *
 *
 */

#import <Cocoa/Cocoa.h>


@interface NSImage (Reflection)

- (NSImage*)pc_reflectedImage;
- (NSImage*)pc_reflectedImageWithLength:(CGFloat)reflectionLength;

@end
