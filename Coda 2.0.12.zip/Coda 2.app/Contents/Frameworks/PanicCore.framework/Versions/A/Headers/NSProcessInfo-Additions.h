#import <Foundation/Foundation.h>

@interface NSProcessInfo (PCAdditions)

- (void)pc_enableSuddenTermination;
- (void)pc_disableSuddenTermination;

- (void)pc_disableAutomaticTermination;
- (void)pc_disableAutomaticTermination:(NSString *)reason;
- (void)pc_enableAutomaticTermination;
- (void)pc_enableAutomaticTermination:(NSString *)reason;

- (NSString*)pc_architectureString; // eg: "x86_64"

@end
