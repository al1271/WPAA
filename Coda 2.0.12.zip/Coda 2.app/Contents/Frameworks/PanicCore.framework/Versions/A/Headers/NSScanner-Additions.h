#import <Foundation/Foundation.h>


@interface NSScanner (Additions)

// to do: add ignored character support

- (BOOL)scanNextCharacterFromSet:(NSCharacterSet *)scanSet intoString:(NSString **)stringValue;
- (BOOL)scanNextString:(NSString *)scanString intoString:(NSString **)stringValue;

- (BOOL)scanBackwardUpToCharactersFromSet:(NSCharacterSet *)scanSet intoString:(NSString **)stringValue;
- (BOOL)scanBackwardUpToString:(NSString *)scanString intoString:(NSString **)stringValue;
- (BOOL)scanBackwardCharactersFromSet:(NSCharacterSet *)scanSet intoString:(NSString **)stringValue;
- (BOOL)scanBackwardNextCharacterFromSet:(NSCharacterSet *)scanSet intoString:(NSString **)stringValue;
@end
