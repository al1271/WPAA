//
//  DCListEncodingController.h
//  dietcoda
//
//  Created by Garrett Moon on 12/6/10.
//  Copyright 2010 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <UIKit/UIKit.h>

@interface PCItemSelectionTableController : UITableViewController {
	id delegate;
	NSArray *items;
	NSIndexPath *selectedIndex;
}

@property (nonatomic, assign) id delegate;
@property (nonatomic, retain) NSArray *items;
@property (nonatomic, retain) NSIndexPath *selectedIndex;

@end

@interface NSObject (DCListEncodingControllerDelegate)

- (void)itemSelection:(PCItemSelectionTableController *)selectionController itemSelected:(id)item atIndexPath:(NSIndexPath *)indexPath;

@end

#endif
