//
//  PCDelegateLayoutView.h
//  PanicCore
//
//  Created by Garrett Moon on 12/14/10.
//  Copyright 2010 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <UIKit/UIKit.h>


@interface PCDelegateLayoutView : UIView {
	id delegate;
}

@property (nonatomic, assign) id delegate;

@end

@interface NSObject (PCDelegateLayoutViewDelegate)

- (void)layoutSubviewsOfView:(PCDelegateLayoutView *)viewToLayout;

@end

#endif