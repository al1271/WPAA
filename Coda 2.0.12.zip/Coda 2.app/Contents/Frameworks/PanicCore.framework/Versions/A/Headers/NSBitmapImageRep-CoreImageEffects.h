/*
 *  NSBitmapImageRep-CoreImageEffects.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	Provides a handy wrapper for core image filters.
 *
 *	-------------------------------------------------------------------
 *
 *
 */


#import <QuartzCore/QuartzCore.h>


@interface NSBitmapImageRep (CoreImageEffects)

// interface convenience methods
- (NSImage*)pressedImage;
- (NSImage*)graphiteImage;

- (NSImage*)adjustBrightness:(float)brightness;
- (NSImage*)adjustSaturation:(float)brightness;


// sudo-private internal method
- (NSImage*)applyFilters:(NSArray*)filters;

@end
