//
//  PCPlatformShaderGradient.h
//  PanicCore
//
//  Created by Wade Cosgrove on 10/11/10.
//  Copyright 2010 Panic, Inc. All rights reserved.
//

#import "PCPlatformShader.h"

@class CKGradient;
@class PCColor;

@interface PCPlatformShaderGradient : PCPlatformShader
{
	CKGradient	*iDisabledGradient;
	CKGradient	*iGradient;
	CKGradient	*iHighlightedGradient;
	CKGradient 	*iRolloverHighlightedGradient;
	CKGradient	*iSelectedGradient;
	PCColor		*iBezelColor;
	CGFloat		iCornerRadius;
}

@property (assign, readwrite) CGFloat cornerRadius;
@property (retain, readwrite) PCColor *bezelColor;
@property (retain, readwrite) CKGradient *gradient;
@property (retain, readwrite) CKGradient *highlightedGradient;
@property (retain, readwrite) CKGradient *disabledGradient;
@property (retain, readwrite) CKGradient *selectedGradient;
@property (retain, readwrite) CKGradient *rolloverHighlightedGradient;

@end
