//
//  PCLayerWithSetableContainsPoint.h
//  dietcoda
//
//  Created by Garrett Moon on 10/20/10.
//  Copyright 2010 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface PCLayerWithSetableContainsPointRegion : CALayer {
	CGPathRef hitPath;
}

@property (nonatomic) CGPathRef hitPath;//Path will be retained

@end
