//
//  PCSheetController.h
//  PanicCore
//
//  Created by Ian Cely on 10/21/10.
//  Copyright 2010 Panic Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol PCSheetControllerDelegate;
@protocol PCSheetControllerInterfaceDelegate;

@interface PCSheetController : NSWindowController
{
@private
	NSInteger iTag;
	NSMutableDictionary* iContextInfo;
	id <PCSheetControllerDelegate> iDelegate;
	id <PCSheetControllerInterfaceDelegate> iInterfaceDelegate;
}

+ (id)queuedSheetControllerWithTag:(NSInteger)tag
						  delegate:(id <PCSheetControllerDelegate>)delegate
				 interfaceDelegate:(id <PCSheetControllerInterfaceDelegate>)interfaceDelegate
					   contextInfo:(NSDictionary*)contextInfo;

// Abstract base class... do not instantiate one of these directly
- (id)initWithTag:(NSInteger)tag
		 delegate:(id <PCSheetControllerDelegate>)delegate
interfaceDelegate:(id <PCSheetControllerInterfaceDelegate>)interfaceDelegate
	  contextInfo:(NSDictionary*)contextInfo;

@property (nonatomic, readonly) NSInteger tag;
@property (nonatomic, readonly) NSMutableDictionary* contextInfo;
@property (nonatomic, retain) id <PCSheetControllerDelegate> delegate;
@property (nonatomic, retain) id <PCSheetControllerInterfaceDelegate> interfaceDelegate;

- (IBAction)endSheetWithReturnCodeFromSenderTag:(id)sender; // convenience method... sender must respond to 'tag'

@end


@protocol PCSheetControllerDelegate <NSObject>

@optional
- (void)sheetControllerDidEnd:(PCSheetController*)sheetController returnCode:(NSInteger)returnCode contextInfo:(NSDictionary*)contextInfo;

@end


@protocol PCSheetControllerInterfaceDelegate <NSObject>

- (NSWindow*)windowForSheetController:(PCSheetController*)sheetController;

@optional

- (BOOL)isReadyToPresentSheetController:(PCSheetController*)sheetController; // assumes YES if unimplemented

@end
