#import <SystemConfiguration/SCNetworkReachability.h>

/*
 *  PCNetworkReachability.h
 *
 *  Requires Mac OS X 10.4 or higher
 *
 *	Provides a nice interface for determining if a machine is online
 *
 *	-------------------------------------------------------------------
 *
 *
 */
 
extern NSString* const PCNetworkStateChangedNotification;
extern NSString* const PCNetworkStateIsOnline;
#if TARGET_OS_IPHONE
extern NSString* const PCNetworkStateIsCellular;
#endif

@interface PCNetworkReachability : NSObject
{
	BOOL isOnline;
#if TARGET_OS_IPHONE
	BOOL isCellular;
#endif
	SCNetworkReachabilityRef reachabilityRef;
	NSURL* url;
}

+ (id)sharedInstance;

+ (BOOL)isOnline;
+ (BOOL)isURLReachable:(NSURL*)aURL;

- (id)initWithURL:(NSURL*)aURL;

- (BOOL)isOnline;
#if TARGET_OS_IPHONE
- (BOOL)isCellular;
#endif
- (NSURL*)url;

@end
