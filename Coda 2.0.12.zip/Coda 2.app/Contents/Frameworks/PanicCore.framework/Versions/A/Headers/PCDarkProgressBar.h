#import <PanicCore/PCAppearanceView.h>

@class PCDarkProgressLayer;
@class CALayer, CATiledLayer;

@interface PCDarkProgressBar : PCAppearanceView
{
	PCDarkProgressLayer *iProgressLayer;
	BOOL iEnabled;
    BOOL iDisplayedWhenStopped;
}

@property (readonly) PCDarkProgressLayer *progressLayer;
@property (nonatomic, assign, getter=isEnabled) BOOL enabled;

- (void)setDoubleValue:(double)value;
- (void)setMinValue:(double)value;
- (void)setMaxValue:(double)value;
- (void)incrementBy:(double)value;
- (double)doubleValue;
- (double)maxValue;
- (double)minValue;

- (void)setBackgroundDoubleValue:(double)value;
- (void)setBackgroundMinValue:(double)value;
- (void)setBackgroundMaxValue:(double)value;
- (void)backgroundIncrementBy:(double)value;
- (double)backgroundDoubleValue;
- (double)backgroundMinValue;
- (double)backgroundMaxValue;

- (void)setControlSize:(NSControlSize)aControlSize;
- (void)setIndeterminate:(BOOL)flag;
- (void)setShadowColor:(CGColorRef)aColor;

+ (CGFloat)heightForControlSize:(NSControlSize)size;

- (void)setDisplayedWhenStopped:(BOOL)isDisplayed;
- (BOOL)isDisplayedWhenStopped;
- (BOOL)isIndeterminate;

@end


@interface PCDarkProgressLayer : CALayer
{
	CALayer *trackLeftCap;
	CALayer *trackRightCap;
	CALayer *trackFill;
	CALayer *foregroundLeftCap;
	CALayer *foregroundRightCap;
	CALayer *foregroundFill;
	CALayer *backgroundLeftCap;
	CALayer *backgroundRightCap;
	CALayer *backgroundFill;
	CATiledLayer *indeterminateFill;
	
	double	iBackgroundDoubleValue;
	double	iBackgroundMinValue;
	double	iBackgroundMaxValue;
	
	double	iDoubleValue;
	double	iMinValue;
	double	iMaxValue;
	
	BOOL	iDrawsShadow;
	BOOL	iIndeterminate;
	
	CGFloat iHeight;
	CGFloat iBlur;
	CGFloat iOffset;
	CGFloat iWidth;
	
	NSControlSize iControlSize;
	
		
}

@property (nonatomic) NSControlSize controlSize;
@property (nonatomic) double backgroundDoubleValue;
@property (nonatomic) double backgroundMinValue;
@property (nonatomic) double backgroundMaxValue;

@property (nonatomic) double doubleValue;
@property (nonatomic) double minValue;
@property (nonatomic) double maxValue;

@property (nonatomic, getter=isIndeterminate) BOOL indeterminate;

- (id)initWithFrame:(NSRect)aRect;

- (void)incrementBy:(double)amount;
- (void)backgroundIncrementBy:(double)amount;

- (void)createTrackLayersWithCGRect:(CGRect)aRect;
- (void)createForegroundLayersWithCGRect:(CGRect)aRect;
- (void)createBackgroundLayersWithCGRect:(CGRect)aRect;
- (void)createIndeterminateLayer;

- (void)configure;
- (CGRect)updateBackground;
- (void)updateForegroundWithBackgroundRect:(CGRect)aRect;

- (void)trackImagesLeftCap:(CGImageRef*)lcap rightCap:(CGImageRef*)rcap fill:(CGImageRef*)fill;
- (void)foregroundImagesLeftCap:(CGImageRef*)lcap rightCap:(CGImageRef*)rcap fill:(CGImageRef*)fill;
- (void)backgroundImagesLeftCap:(CGImageRef*)lcap rightCap:(CGImageRef*)rcap fill:(CGImageRef*)fill;

//- (NSSize)cellSizeWithShadow;
+ (CGFloat)heightForControlSize:(NSControlSize)controlSize;

@end

