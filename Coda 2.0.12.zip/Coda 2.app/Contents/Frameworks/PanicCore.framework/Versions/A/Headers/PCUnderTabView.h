#import "PCTabBar.h"

@class PCRecessedRolloverButton;
@class PCUnderTabViewShader;

@interface PCUnderTabView : PCTabBar 
{
	__weak PCRecessedRolloverButton	*iAddTabButton;
	PCUnderTabViewShader	*iShader;
}

@end
