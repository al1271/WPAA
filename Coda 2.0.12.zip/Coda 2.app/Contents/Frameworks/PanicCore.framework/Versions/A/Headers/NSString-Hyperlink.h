/*
 *  NSString-Hyperlink.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *
 *	Creates an attributed string URL suitable for displaying as a link
 *
 *	-------------------------------------------------------------------
 *
 *
 */
 
@interface NSString (Hyperlink)

- (NSAttributedString*)hyperlink;
- (NSAttributedString*)hyperlinkWithURL:(NSString *)aURL;

@end
