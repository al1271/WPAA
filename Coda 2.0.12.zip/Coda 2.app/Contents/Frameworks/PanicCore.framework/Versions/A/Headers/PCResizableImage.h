//
//  PCResizableImage.h
//  PanicCore
//
//  Created by Logan Collins on 3/23/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <PanicCore/PCGeometry.h>

#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#elif TARGET_OS_MAC
#import <Cocoa/Cocoa.h>
#endif


@interface PCResizableImage : NSObject {
#if TARGET_OS_IPHONE
    UIImage *_image;
#elif TARGET_OS_MAC
    NSImage *_image;
#endif
    PCEdgeInsets _capInsets;
}

+ (PCResizableImage *)resizableImageNamed:(NSString *)imageName;
+ (PCResizableImage *)resizableImageNamed:(NSString *)imageName capInsets:(PCEdgeInsets)capInsets;


#if TARGET_OS_IPHONE

+ (PCResizableImage *)resizableImageWithImage:(UIImage *)image;
+ (PCResizableImage *)resizableImageWithImage:(UIImage *)image capInsets:(PCEdgeInsets)capInsets;

@property (retain, readonly) UIImage *image;

#elif TARGET_OS_MAC

+ (PCResizableImage *)resizableImageWithImage:(NSImage *)image;
+ (PCResizableImage *)resizableImageWithImage:(NSImage *)image capInsets:(PCEdgeInsets)capInsets;

@property (retain, readonly) NSImage *image;

#endif


@property (assign, readonly) PCEdgeInsets capInsets;


- (void)drawInRect:(CGRect)rect;
- (void)drawInRect:(CGRect)rect blendMode:(CGBlendMode)blendMode alpha:(CGFloat)alpha;

@end
