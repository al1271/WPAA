#import "PCBaseSegmentedControl.h"


@interface PCGradientSegmentedControl : PCBaseSegmentedControl
{}
@end


@interface PCGradientSegmentedCell : PCBaseSegmentedCell
{
@private
	NSGradient* iFillGradient;
	NSGradient* iHighlightFillGradient;
	NSGradient* iSelectedFillGradient; // can be customized, isn't necessary for standard configuration
    NSGradient* iInnerBezelGradient;
    NSGradient* iDividerGradient;
	NSColor*	iBezelColor;
	NSGradient* iBezelGradient; // used instead of bezel color if non-nil
	NSColor*	iShadowColor; // if set, draws a shadow below the control
	CGFloat		iCornerRadius;
    BOOL        iDrawsMiniDivider;
}

@property (nonatomic, retain) NSGradient* fillGradient;
@property (nonatomic, retain) NSGradient* highlightedFillGradient;
@property (nonatomic, retain) NSGradient* selectedFillGradient;
@property (nonatomic, retain) NSColor*	bezelColor;
@property (nonatomic, retain) NSGradient* bezelGradient;
@property (nonatomic, retain) NSGradient* innerBezelGradient;
@property (nonatomic, retain) NSColor*	shadowColor;
@property (nonatomic, assign) CGFloat	cornerRadius;
@property (nonatomic, assign) BOOL drawsMiniDivider;
@property (nonatomic, retain) NSGradient* dividerGradient;

@end