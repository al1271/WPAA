

#import <Foundation/Foundation.h>
#import "PCBaseOutlineView.h"

@interface PCColoredRowsOutlineView : PCBaseOutlineView {
@private
    NSArray *_alternatingRowBackgroundColors;
}

@property (nonatomic, copy) NSArray *alternatingRowBackgroundColors;


@end
