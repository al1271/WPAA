/*

 We're using some code from:
 
 EGOTextFieldAlertView is available under the MIT license:
 
 Copyright © 2009 enormego
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the “Software”), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 
*/

#include <Foundation/Foundation.h>

#if TARGET_OS_IPHONE
#include <UIKit/UIKit.h>
#endif

typedef enum {
	PCAlertDefaultButtonReturn	= 1000,
	PCAlertCancelButtonReturn	= 1001,
	PCAlertOtherButtonReturn	= 1002,
	PCAlertErrorButtonReturn	= 1003
}PCAlertButtonReturn;


#if TARGET_OS_IPHONE

// XXX - here's what the docs say about this:
// "The UIAlertView class is intended to be used as-is and does not support subclassing. The view hierarchy for this class is private and must not be modified."


@interface PCAlert : UIAlertView <UITextFieldDelegate>
{
	id iContextInfo;
	NSUInteger iTag;
	NSMutableArray* __textFields; // Single underscore is used in UIAlertView
	BOOL overrodeHeight;
	CGFloat textFieldHeightOffset;
}

#else

@interface PCAlert : NSAlert 
{
	id iContextInfo;
	NSUInteger iTag;
}

#endif

@property (copy) id contextInfo;
@property (assign) NSUInteger tag;

+ (PCAlert*)pc_alertWithError:(NSError*)anError;

+ (PCAlert*)alertWithTitle:(NSString*)title message:(NSString*)message defaultButton:(NSString*)defaultButtonTitle
		   alternateButton:(NSString*)alternateButtonTitle otherButton:(NSString*)otherButtonTitle;

- (BOOL)showsSuppressionButton;
- (void)setShowsSuppressionButton:(BOOL)flag;
- (BOOL)isSuppressionButtonOn;
- (void)setSuppressionButtonTitle:(NSString*)caption;

#if TARGET_OS_IPHONE

- (void)addTextField:(UITextField*)textField;
- (UITextField*)addTextFieldWithLabel:(NSString*)label;
- (UITextField*)addTextFieldWithLabel:(NSString*)label value:(NSString*)value;

- (UITextField*)textFieldForIndex:(NSInteger)index;
+ (PCAlertButtonReturn)buttonReturnForUIAlertButtonIndex:(NSInteger)buttonIndex;

@property(nonatomic,readonly) NSInteger numberOfTextFields;
@property(nonatomic,readonly) UITextField* firstTextField;

#endif

@end
