#import <Cocoa/Cocoa.h>
#import <Carbon/Carbon.h>


@interface NSMenu (PCUtilities)

#if !defined(MACAPPSTORE)
- (MenuRef)pc_carbonMenu DEPRECATED_ATTRIBUTE;
#endif

- (NSMenuItem*)pc_itemWithRepresentedObject:(id)anObject;
- (void)pc_setActionForMenuItems:(SEL)action target:(id)target;
- (void)pc_setTargetForAllItems:(id)target;
- (NSMenuItem*)pc_selectedItem;

- (NSMenuItem*)pc_checkedItem;
- (void)pc_checkItemWithTag:(NSInteger)tag byExtendingSelection:(BOOL)flag;
- (void)pc_checkMenuItem:(NSMenuItem*)item byExtendingSelection:(BOOL)flag;
- (void)pc_uncheckAll;

- (void)pc_addTextEncodingItemsWithSelector:(SEL)action includeAutomatic:(BOOL)flag;

@end


@interface NSMenu (PCItemEnumerator)

- (NSEnumerator*)pc_itemEnumerator;
- (NSEnumerator*)pc_recursiveItemEnumerator;

@end
