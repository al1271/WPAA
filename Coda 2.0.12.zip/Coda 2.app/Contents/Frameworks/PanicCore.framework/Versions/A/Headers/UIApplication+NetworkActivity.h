//
//  UIApplication+NetworkActivity.h
//  PanicCore
//
//  Created by Garrett Moon on 1/31/12.
//  Copyright (c) 2012 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <UIKit/UIKit.h>

@interface UIApplication (NetworkActivity)

+ (void)addNetworkActivity;
+ (void)removeNetworkActivity;

@end

#endif