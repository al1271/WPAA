#import <PanicCore/PCBorderedView.h>


@interface PCGradientView : PCBorderedView
{
@private
	NSGradient* iGradient;
	CGFloat iAngle;
}

@property (nonatomic, retain) NSGradient* gradient;
@property (nonatomic, assign) CGFloat angle;

- (void)setStartColor:(NSColor*)inStartColor endColor:(NSColor*)inEndColor;

@end
