/*
 *  PCActionPopUpButton.h
 *
 *  Requires Mac OS X 10.5 or higher and NSMenu-ContextualMenuValidation category
 *
 *	Provides a button that has a dynamically validated popup menu
 *
 *	-------------------------------------------------------------------
 *
 *
 */
 
#import <Cocoa/Cocoa.h>


@interface PCActionPopUpButton : NSPopUpButton
{
}

- (NSMenu*)contextSensitiveMenu;
- (void)setContextSensitiveMenu:(NSMenu*)aMenu;

@end


@interface PCActionPopUpButtonCell : NSPopUpButtonCell
{
	NSMenu		*defaultMenu;
	NSMenuItem	*buttonMenuItem;
	
	BOOL iAutovalidateEnabled;
}

@property (nonatomic, assign) BOOL autovalidateEnabled;

- (NSMenu*)contextSensitiveMenu;
- (void)setContextSensitiveMenu:(NSMenu*)aMenu;

- (void)setTemplateImage:(NSImage*)anImage;

@end
