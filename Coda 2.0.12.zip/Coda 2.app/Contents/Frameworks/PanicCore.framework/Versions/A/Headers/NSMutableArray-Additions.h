//
//  NSMutableArray-Additions.h
//  PanicCore
//
//  Created by Garrett Moon on 1/17/11.
//  Copyright 2011 Panic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (PCAdditions)

- (void)pc_removeObjectsFromIndex:(NSUInteger)index;

- (void)pc_removeObjectsToIndex:(NSUInteger)index;

@end
