#import <Foundation/Foundation.h>

#define kPCMaxErrorMessageLen 600

@interface NSError (PCAdditions)

- (NSError*)pc_errorByTruncatingMessage; // may return [[self retain] autorelease]

- (NSString*)pc_title;
- (NSString*)pc_message;

+ (NSError*)pc_errorWithTitle:(NSString*)title message:(NSString*)message domain:(NSString*)domain code:(NSInteger)code;
+ (NSError*)pc_errorWithTitle:(NSString*)title message:(NSString*)message domain:(NSString*)domain code:(NSInteger)code userInfo:(NSDictionary*)userInfo; // title and message parameters preferred over contents of userInfo

- (NSError*)pc_errorByAddingUserInfoEntriesFromDictionary:(NSDictionary*)dictionary; // existing title and message parameters preferred over contents of dictionary

- (NSURL*)pc_failingURL;

@end
