//
//  PCPreferencesController.h
//  PanicCore
//
//  Created by Logan Collins on 2/27/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@class PCPreferencePane;


/*!
 * @class PCPreferencesController
 * @abstract A preferences window controller
 * 
 * @discussion
 * The controller manages a series of panes that are displayed as a preferences window.
 */
@interface PCPreferencesController : NSWindowController {
@private
	NSMutableArray *preferencePaneIdentifiers;
	NSMutableDictionary *preferencePanes;
	NSMutableDictionary *toolbarItems;
	
	PCPreferencePane *currentPane;
	
	NSToolbar *toolbar;
    NSString *autosaveIdentifier;
}

/*!
 * @method sharedController
 * @abstract The shared instance
 * 
 * @result A global PCPreferencesController object
 */
+ (PCPreferencesController *)sharedController;

/*!
 * @method init
 * @abstract Create a new instance
 * 
 * @result A new PCPreferencesController object
 */
- (id)init;

/*!
 * @property autosaveIdentifier
 * @abstract Gets the autosave identifier.
 * 
 * @result An NSString object
 */
@property (copy) NSString *autosaveIdentifier;

/*!
 * @property preferencePanes
 * @abstract Gets the array of preference panes.
 * 
 * @discussion
 * Observable via KVO.
 * 
 * @result An NSArray of PCPreferencePane objects
 */
@property (strong, readonly) NSArray *preferencePanes;

/*!
 * @property currentPreferencePane
 * @abstract Gets the current preference pane.
 * 
 * @discussion
 * Observable via KVO.
 * 
 * @result A PCPreferencePane object
 */
@property (strong, readonly) PCPreferencePane *currentPreferencePane;

/*!
 * @method preferencePaneWithIdentifier:
 * @abstract Gets the preference pane with a specific identifier (or nil if none exists)
 * 
 * @param identifier
 * The identifier of the preference pane to get
 * 
 * @result A PCPreferencePane object
 */
- (PCPreferencePane *)preferencePaneWithIdentifier:(NSString *)identifier;

/*!
 * @method preferencePaneAtIndex:
 * @abstract Gets the preference pane at a specific index
 * 
 * @param index
 * The index of the preference pane to get
 * 
 * @result A PCPreferencePane object
 */
- (PCPreferencePane *)preferencePaneAtIndex:(NSUInteger)index;

/*!
 * @method addPreferencePane:
 * @abstract Append a preference pane to the receiver
 * 
 * @param preferencePane
 * The preference pane to add
 */
- (void)addPreferencePane:(PCPreferencePane *)preferencePane;

/*!
 * @method insertPreferencePane:atIndex:
 * @abstract Append a preference pane to the receiver
 * 
 * @param preferencePane
 * The preference pane to insert
 * 
 * @param index
 * The index at which to insert the preference pane
 */
- (void)insertPreferencePane:(PCPreferencePane *)preferencePane atIndex:(NSUInteger)index;

/*!
 * @method removePreferencePaneAtIndex:
 * @abstract Removes the preference pane at a specified index from the receiver
 * 
 * @param index
 * The index of the preference pane to remove
 */
- (void)removePreferencePaneAtIndex:(NSUInteger)index;

/*!
 * @method removePreferencePane:
 * @abstract Removes a specified preference pane from the receiver
 * 
 * @param preferencePane
 * The preference pane to remove
 */
- (void)removePreferencePane:(PCPreferencePane *)preferencePane;

/*!
 * @method showPreferencePaneWithIdentifier:
 * @abstract Switch to the preference pane with a specified identifier
 * 
 * @param identifier
 * The identifier of the pane to which to switch
 */
- (void)showPreferencePaneWithIdentifier:(NSString *)identifier;

@end
