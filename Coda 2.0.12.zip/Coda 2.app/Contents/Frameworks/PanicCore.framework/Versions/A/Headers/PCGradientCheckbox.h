@interface PCGradientCheckbox : NSButton
{
}

@end


@interface PCGradientCheckboxCell: NSButtonCell
{
	NSImage* 	checkboxImage;
	
	NSGradient* iFillGradient;
	NSGradient* iHighlightedFillGradient;
    NSGradient* iInnerBezelGradient;
	NSColor*	iBezelColor;
	NSGradient* iBezelGradient; // used instead of bezel color if non-nil
	NSColor*	iShadowColor; // if set, shadow color below checkmark and around button shape and inner shadow if enabled
	BOOL 		iDrawsInteriorShadows;
}

@property (retain) NSGradient* fillGradient;
@property (retain) NSGradient* highlightedFillGradient;
@property (retain) NSGradient* innerBezelGradient;
@property (retain) NSColor*	bezelColor;
@property (retain) NSGradient* bezelGradient;
@property (retain) NSColor*	shadowColor;
@property (assign) BOOL	drawsInteriorShadows;

@end