#import <Foundation/Foundation.h>

#if !TARGET_OS_IPHONE
#import <SecurityInterface/SFCertificateTrustPanel.h>
#endif

@class PCCertificate;

enum {
	TrustEvaluationNeedsUserFeedback = -1,
	TrustEvaluationUntrusted = 0,
	TrustEvaluationTrusted = 1
};
typedef NSInteger PCTrustEvaluation;


@interface PCTrust : NSObject
{

@private
	__strong SecTrustRef iRef;
	PCCertificate* iCertificate;
	NSString* iHost;
#if !TARGET_OS_IPHONE
	NSPanel* iSheet;
#endif
}


// since there's no way to recover the "input certificate" for a chain, the certificates used to create the trust must also be supplied
- (id)initWithSecTrust:(SecTrustRef)trust secCertificates:(CFArrayRef)secCertificates host:(NSString*)host;

- (id)initWithCertificateOrArray:(CFTypeRef)certificateOrArray host:(NSString*)host; // accepts a SecCertificate or a PCCertificate (or a homogeneous array thereof)
- (id)initWithCertificateOrArray:(CFTypeRef)certificateOrArray host:(NSString*)host secPolicies:(CFTypeRef)secPolicies;

- (SecTrustRef)secTrust;
- (NSString*)host;

- (PCTrustEvaluation)evaluate;

#if TARGET_OS_IPHONE
- (void)beginEvaluationAlertWithTitle:(NSString *)title delegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(id)contextInfo;
#else

@property (nonatomic, readonly, retain) NSPanel* sheet;

- (void)beginCertificateSheetForWindow:(NSWindow*)window modalDelegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void*)contextInfo showGroup:(BOOL)showGroup;
- (void)beginEvaluationSheetForWindow:(NSWindow*)window modalDelegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void*)contextInfo message:(NSString*)message;
#endif

@end


#if !TARGET_OS_IPHONE

@interface NSError (PCTrust)

- (PCTrust*)pc_failingURLPeerTrust;

@end


@interface SFCertificatePanel  (PCSplitViewFix)

+ (void)pc_installCertificatePanelSplitViewFix;

@end

#endif
