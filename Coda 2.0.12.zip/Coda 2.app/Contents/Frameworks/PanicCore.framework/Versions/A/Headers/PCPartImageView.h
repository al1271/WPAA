#import <Cocoa/Cocoa.h>


@interface PCPartImageView : NSView
{
	NSArray *iImageParts;
	NSImage	*iSourceImage;
	BOOL	iDrawThreeParts; // if YES, draws 3 parts, else 9
}

@property (nonatomic, copy) NSArray *imageParts;

- (void)setNinePartImage:(NSImage*)sourceImage;
- (void)setThreePartImage:(NSImage*)sourceImage;

- (void)drawPartsInRect:(NSRect)rect;

@end
