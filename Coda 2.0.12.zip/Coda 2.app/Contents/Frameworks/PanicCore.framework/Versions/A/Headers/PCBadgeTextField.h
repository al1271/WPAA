//
//  PCBadgeTextField.h
//  PanicCore
//
//  Created by Wade Cosgrove on 4/2/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PCBadgeTextField : NSTextField

@end


@interface PCBadgeTextFieldCell : NSTextFieldCell
{
	NSColor *iBadgeStrokeColor;
	NSGradient *iBadgeGradient;
}

@property (retain) NSColor *badgeStrokeColor;
@property (retain) NSGradient *badgeGradient;

- (void)drawBadgeBackgroundWithFrame:(NSRect)cellFrame inView:(NSView*)controlView;

@end
