//
//  PCPreferencePane.h
//  PanicCore
//
//  Created by Logan Collins on 2/27/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <PanicCore/PCViewController.h>


/*!
 * @class PCPreferencePane
 * @abstract An individual preference pane
 * 
 * @discussion
 * PCPreferencePane is a subclass of PCViewController that defines a pane
 * managed by a preferences controller.
 */
@interface PCPreferencePane : PCViewController
#if MAC_OS_X_VERSION_MIN_REQUIRED > MAC_OS_X_VERSION_10_6
<NSUserInterfaceItemIdentification>
#endif
{
@private
    NSString *_identifier;
	BOOL _shouldUpdateCredentials;
}

/*!
 * @property identifier
 * @abstract The unique identifier of the preference pane
 * 
 * @discussion
 * The identifier must be unique within the context of a preference pane controller.
 * 
 * @result An NSString object
 */
@property (copy) NSString *identifier;

/*!
 * @property shouldUpdateCredentials
 * @abstract Gets whether the preferences controller should sync credentials when closing the pane
 * 
 * @result A BOOL value;
 */
@property BOOL shouldUpdateCredentials;

@end
