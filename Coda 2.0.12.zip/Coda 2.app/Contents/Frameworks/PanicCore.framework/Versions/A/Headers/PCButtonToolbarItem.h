#import <Cocoa/Cocoa.h>

#define kDefaultToolbarButtonWidth 40.0f
#define kDefaultToolbarButtonHeight 25.0f

@interface PCButtonToolbarItem : NSToolbarItem
{
	NSButton *iButton;
	NSControl *iControl;
}

@property (assign) NSButton *button;
@property (assign) NSControl *control;

- (id)initWithItemIdentifier:(NSString*)itemIdentifier;
- (id)initWithItemIdentifier:(NSString*)itemIdentifier image:(NSImage*)itemImage; // designated initializer

@end