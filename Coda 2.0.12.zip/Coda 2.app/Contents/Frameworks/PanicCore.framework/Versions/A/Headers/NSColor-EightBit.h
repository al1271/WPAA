#import <Cocoa/Cocoa.h>


@interface NSColor (PC8Bit)

+ (NSColor*)pc_colorWith8BitCyan:(uint8_t)cyan magenta:(uint8_t)magenta yellow:(uint8_t)yellow black:(uint8_t)black alpha:(CGFloat)alpha;
+ (NSColor*)pc_colorWith8BitRed:(uint8_t)red green:(uint8_t)green blue:(uint8_t)blue alpha:(CGFloat)alpha;
+ (NSColor*)pc_colorWith8BitWhite:(uint8_t)white alpha:(CGFloat)alpha;

@end
