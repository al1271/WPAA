#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#else
#import <Cocoa/Cocoa.h>
#endif

#import <QuartzCore/QuartzCore.h>

@class PCColor;
@class PCShadow;
@class PCButtonLayer;
@class PCFont;

typedef enum
{
  kPCPlatformLeftEdge	= 1U << 0,
  kPCPlatformRightEdge	= 1U << 1,
  kPCPlatformBottomEdge	= 1U << 2,
  kPCPlatformTopEdge	= 1U << 3,
} PlatformEdgeMask;


@interface PCPlatformShader : NSObject 
{
	PCShadow* 	iTextShadow;
	PCFont* 	iFont;
}

@property (retain) PCFont *font;
@property (retain) PCShadow *textShadow;

- (void)prepareContext:(CGContextRef)ctx translateRect:(CGRect)rect;
- (void)restoreContext:(CGContextRef)context;

- (void)configureButtonLayer:(PCButtonLayer*)layer;

- (void)drawBackgroundInRect:(CGRect)rect; 	// control background
- (void)drawButtonInRect:(CGRect)rect;		// default enabled button style
- (void)drawHighlightedButtonInRect:(CGRect)rect isSelected:(BOOL)flag; // highlighted button style
- (void)drawRolloverHighlightedButtonInRect:(CGRect)rect; // rollover style, only called if supported
- (void)drawDisabledButtonInRect:(CGRect)rect; // disabled button style
- (void)drawSelectedButtonInRect:(CGRect)rect; // selected (on) button style

- (BOOL)isOpaque;
- (BOOL)supportsRollover;

- (PCColor*)textColor;
- (PCShadow*)textShadow;

- (PCColor*)selectedTextColor;

@end
