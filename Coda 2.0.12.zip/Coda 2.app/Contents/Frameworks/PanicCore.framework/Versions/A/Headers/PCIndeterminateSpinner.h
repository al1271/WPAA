
#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#else
#import <Cocoa/Cocoa.h>
#endif

@class PCSpinPartLayerDelegate;
@class PCIndeterminateSpinnerLayer;

#if TARGET_OS_IPHONE
@interface PCIndeterminateSpinner : UIView
#else
@interface PCIndeterminateSpinner : NSView
#endif
{
@private
	PCIndeterminateSpinnerLayer *spinnerLayer;
}

@property (readonly) PCIndeterminateSpinnerLayer *spinnerLayer;

- (void)setUsesWhiteSpinner:(BOOL)flag;

- (void)startAnimation:(id)sender;
- (void)stopAnimation:(id)sender;
- (BOOL)isAnimating;

// hi-dpi
- (void)setContentsScale:(CGFloat)contentsScale;

@end


@interface PCIndeterminateSpinnerLayer : CALayer
{
@private
	NSMutableArray *spinnerLayers;
	
	NSInteger numLines;				// even values look better
	CGFloat lineWidth;				// range of 0.0 to 1.0 rather than a pixel size for better scaling
	CGFloat centerRadius;			// range of 0.0 to 1.0
	NSTimeInterval rotationSpeed;	// time in seconds for one full rotation
	CGFloat trail;					// range of 0.0 to 1.0, smaller is a shorter
	CGColorRef color;
	
	BOOL animating;

	PCSpinPartLayerDelegate *layerDelegate;
}


@property (assign) NSInteger numLines;
@property (assign) CGFloat lineWidth;
@property (assign) CGFloat centerRadius;	
@property (assign) NSTimeInterval rotationSpeed;
@property (assign) CGFloat trail;
@property (assign) CGColorRef color;

@property (readonly, getter = isAnimating) BOOL animating;

- (void)setUsesWhiteSpinner:(BOOL)flag;

- (void)startAnimation:(id)sender;
- (void)stopAnimation:(id)sender;

// hi-dpi
- (void)setContentsScale:(CGFloat)contentsScale;

@end


// since on iOS we're a UIView and can't set the delegate of the spinner "spoke" layers to ourselves, we have this delegate class
@interface PCSpinPartLayerDelegate : NSObject
{
	PCIndeterminateSpinnerLayer *spinner;
}

@property (assign) PCIndeterminateSpinnerLayer *spinner;

@end