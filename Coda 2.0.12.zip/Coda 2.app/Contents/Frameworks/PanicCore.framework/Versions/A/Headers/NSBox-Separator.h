#import <Cocoa/Cocoa.h>

/*
 *  NSBox-Separator.h
 *
 *  Requires Mac OS X 10.0 or higher
 *
 *	Provides a category for creating a separator line easily
 *
 *	-------------------------------------------------------------------
 *
 *
 */

@interface NSBox (PCSeparator)

+ (NSBox*)pc_separatorWithWidth:(CGFloat)width;

@end
