//
//  PCProgressBar.h
//  PanicCore
//
//  Created by Garrett Moon on 2/22/11.
//  Copyright 2011 Panic. All rights reserved.
//

#if TARGET_OS_IPHONE

#import <UIKit/UIKit.h>

@class PCColor;

@interface PCProgressBar : UIView
{

}

@property (retain) PCColor *backgroundTint;
@property (retain) PCColor *fillTint;
@property (assign) CGFloat percentage;

@end

#endif
