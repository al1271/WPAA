#import <Cocoa/Cocoa.h>

@protocol PCControllerViewProtocol
@optional
- (void)viewDidEndLiveResize:(NSView*)view;
- (void)view:(NSView*)view didMoveToWindow:(NSWindow*)window;
- (void)view:(NSView*)view willMoveToWindow:(NSWindow*)window;
- (void)view:(NSView*)view didMoveToSuperview:(NSView*)superview;
- (void)view:(NSView*)view willMoveToSuperview:(NSView*)superview;
- (void)view:(NSView*)view setNextResponder:(NSResponder*)responder;
@end


@interface PCControllerView : NSView 
{
	__weak IBOutlet NSViewController <PCControllerViewProtocol>* iViewController;
}

@property (assign, readwrite) __weak NSViewController <PCControllerViewProtocol>*viewController;

@end