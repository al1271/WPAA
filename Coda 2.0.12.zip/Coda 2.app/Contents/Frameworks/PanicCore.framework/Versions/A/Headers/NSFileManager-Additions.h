#import <Foundation/Foundation.h>
#import <AvailabilityMacros.h>

#import <sys/types.h>
#import <pwd.h>
#import <grp.h>

#if !TARGET_OS_IPHONE
FSVolumeRefNum GetBootVolumeRefNum();
#endif

@interface NSFileManager (PCAdditions)

// The default manager is not safe to simultaneously access from multiple threads; this method instantiates a new instance to avoid such contention (requires 10.5 or later).
+ (NSFileManager *)threadSafeManager;

- (BOOL)pc_itemAtPath:(NSString *)lhs isOnSameVolumeAsItemAtPath:(NSString *)rhs;

- (BOOL)pc_directoryExistsAtPath:(NSString *)path;
- (NSString *)pc_MIMETypeForFilename:(NSString *)filename;

- (BOOL)pc_quarantineItemAtPath:(NSString *)path quaratineType:(NSString *)quarantineType url:(NSURL *)dataURL error:(NSError **)error;
- (BOOL)pc_dequaratineItemAtPath:(NSString *)path error:(NSError **)error;

- (NSArray *)pc_userNames;
- (NSArray *)pc_groupNames;

- (NSString *)pc_userNameForUID:(uid_t)uid;
- (NSString *)pc_groupNameForGID:(gid_t)gid;

+ (NSString *)pc_bootDiskDisplayName; // eg: "Macintosh HD"
+ (NSString *)pc_bootDiskPath; // eg: "/Volumes/Macintosh HD"
+ (void)pc_resetBootDiskValues;
+ (NSString *)pc_computerName;

//- (BOOL)pc_isiCloudSupported;

@end


@interface NSFileManager (PCFolders)

// supported folder types are in Folders.h
#if !TARGET_OS_IPHONE

// NOTE: use NSSearchPathForDirectoriesInDomains() if possible for iOS campatibility

- (NSString *)pc_findFolderWithType:(OSType)folderType; // kUserDomain, create if nonexistant
- (NSString *)pc_findFolderWithType:(OSType)folderType inDomain:(OSType)domain; // create if nonexistant
- (NSString *)pc_findFolderWithType:(OSType)folderType inDomain:(OSType)domain creating:(BOOL)creating; // returns nil if creating == NO and folder does not exist

- (NSString *)pc_applicationSupportFolderForBundle:(NSBundle *)bundle; // creates "Library/Application Support/<bundle app name>"
- (NSURL *)pc_applicationSupportURLForBundle:(NSBundle *)bundle; // creates "Library/Application Support/<bundle app name>"

#endif

// Paths
- (NSString *)pc_applicationSupportFolder; // creates "Library/Application Support/<app name>"

- (NSString *)pc_temporaryItemsFolderCreate:(BOOL)flag; // "Library/Caches/TemporaryItems/<app name>"
- (NSString *)pc_chewableItemsFolderCreate:(BOOL)flag; // "Library/Caches/Cleanup At Startup/<app name>"
- (NSString *)pc_cachesFolderCreate:(BOOL)flag; // "Library/Caches/<app name>"

- (NSString *)pc_applicationSupportSubFolder:(NSString *)folderName; // creates "Library/Application Support/<app name>/<folderName>"
- (NSString *)pc_applicationSupportSubFolder:(NSString *)folderName attributes:(NSDictionary *)attributes; // creates "Library/Application Support/<app name>/<folderName>" with attributes
- (NSString *)pc_applicationSupportSubFolder:(NSString *)folderName attributes:(NSDictionary *)attributes bundle:(NSBundle *)bundle; // creates "Library/Application Support/<bundle app name>/<folderName>" with attributes


// URLs
- (NSURL *)pc_applicationSupportURL; // creates "Library/Application Support/<app name>"

- (NSURL *)pc_temporaryItemsURLCreate:(BOOL)flag; // "Library/Caches/TemporaryItems/<app name>"
- (NSURL *)pc_chewableItemsURLCreate:(BOOL)flag; // "Library/Caches/Cleanup At Startup/<app name>"
- (NSURL *)pc_cachesURLCreate:(BOOL)flag; // "Library/Caches/<app name>"

- (NSURL *)pc_applicationSupportSubURL:(NSString *)folderName; // creates "Library/Application Support/<app name>/<folderName>"
- (NSURL *)pc_applicationSupportSubURL:(NSString *)folderName attributes:(NSDictionary *)attributes; // creates "Library/Application Support/<app name>/<folderName>" with attributes
- (NSURL *)pc_applicationSupportSubURL:(NSString *)folderName attributes:(NSDictionary *)attributes bundle:(NSBundle *)bundle; // creates "Library/Application Support/<bundle app name>/<folderName>" with attributes

@end
