#import <Cocoa/Cocoa.h>


@interface NSBezierPath (Fill)

- (void)fillWithInnerShadow:(NSShadow *)shadow;
- (void)pc_fillFlipped;
- (void)pc_fillAtPoint:(NSPoint)origin;
- (void)pc_fillFlippedAtPoint:(NSPoint)origin;

@end
