//
//  PCOverlayView.h
//  PanicCore
//
//  Created by Ian Cely on 11/10/09.
//  Copyright 2009 Panic Inc.. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@class PCOverlayContainer;

@interface PCOverlayView : NSView
{
@private
	PCOverlayContainer* iOverlayContainer;
}

@property (nonatomic, retain) IBOutlet NSView* overlay;
@property (nonatomic) BOOL centerOverlay; // defaults to YES
@property (nonatomic, getter=isOverlaid) BOOL overlaid;

- (void)setContainerWantsLayer:(BOOL)flag;
- (void)setOverlayBackground:(id)background; // (NSColor, NSGradient, or NSView)

@end
