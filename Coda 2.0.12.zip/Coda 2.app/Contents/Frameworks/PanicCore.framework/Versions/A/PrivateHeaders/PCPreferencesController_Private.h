//
//  PCPreferencesController_Private.h
//  PanicCore
//
//  Created by Logan Collins on 2/27/12.
//  Copyright (c) 2012 Panic, Inc. All rights reserved.
//

#import "PCPreferencesController.h"


@interface PCPreferencesController () <NSWindowDelegate, NSToolbarDelegate>

- (void)toggleActivePreferenceView:(NSToolbarItem *)item;
- (void)showPreferencePaneWithIdentifier:(NSString *)identifier animate:(BOOL)shouldAnimate;
- (void)confirmedShowPreferencePaneWithIdentifier:(NSString *)identifier animate:(BOOL)shouldAnimate;
- (NSRect)frameForView:(NSView *)view;

@end
